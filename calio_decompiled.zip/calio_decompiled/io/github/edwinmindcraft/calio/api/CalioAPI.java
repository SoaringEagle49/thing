/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.RegistryAccess
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.server.MinecraftServer
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.level.CommonLevelAccessor
 *  net.minecraftforge.common.capabilities.Capability
 *  net.minecraftforge.common.capabilities.CapabilityManager
 *  net.minecraftforge.common.capabilities.CapabilityToken
 *  net.minecraftforge.common.util.LazyOptional
 *  net.minecraftforge.server.ServerLifecycleHooks
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 *  org.jetbrains.annotations.Contract
 *  org.jetbrains.annotations.Nullable
 */
package io.github.edwinmindcraft.calio.api;

import io.github.edwinmindcraft.calio.api.ability.IAbilityHolder;
import io.github.edwinmindcraft.calio.api.registry.ICalioDynamicRegistryManager;
import io.github.edwinmindcraft.calio.client.util.ClientHelper;
import io.github.edwinmindcraft.calio.common.registry.CalioDynamicRegistryManager;
import io.github.edwinmindcraft.calio.common.util.SideUtil;
import net.minecraft.core.RegistryAccess;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.CommonLevelAccessor;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.server.ServerLifecycleHooks;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.Nullable;

public class CalioAPI {
    public static final Logger LOGGER = LogManager.getLogger((String)"Calio");
    public static final String MODID = "calio";
    public static Capability<IAbilityHolder> ABILITY_HOLDER = CapabilityManager.get((CapabilityToken)new CapabilityToken<IAbilityHolder>(){});

    @Contract(pure=true)
    public static ResourceLocation resource(String path) {
        return new ResourceLocation(MODID, path);
    }

    @Contract(pure=true)
    public static MinecraftServer getServer() {
        return ServerLifecycleHooks.getCurrentServer();
    }

    @Contract(pure=true)
    public static ICalioDynamicRegistryManager getDynamicRegistries() {
        return CalioAPI.getDynamicRegistries(CalioAPI.getSidedRegistryAccess());
    }

    @Contract(pure=true)
    private static RegistryAccess getSidedRegistryAccess() {
        if (SideUtil.isClient()) {
            return ClientHelper.getClientRegistryAccess();
        }
        if (ServerLifecycleHooks.getCurrentServer() != null) {
            return ServerLifecycleHooks.getCurrentServer().m_206579_();
        }
        return RegistryAccess.f_243945_;
    }

    @Contract(pure=true)
    public static ICalioDynamicRegistryManager getDynamicRegistries(@Nullable MinecraftServer server) {
        return CalioDynamicRegistryManager.getInstance((RegistryAccess)(server == null ? CalioAPI.getSidedRegistryAccess() : server.m_206579_()));
    }

    @Contract(pure=true)
    public static ICalioDynamicRegistryManager getDynamicRegistries(@Nullable CommonLevelAccessor level) {
        return CalioDynamicRegistryManager.getInstance(level == null ? CalioAPI.getSidedRegistryAccess() : level.m_9598_());
    }

    @Contract(pure=true)
    public static ICalioDynamicRegistryManager getDynamicRegistries(@Nullable RegistryAccess access) {
        return CalioDynamicRegistryManager.getInstance(access);
    }

    @Contract(pure=true)
    public static LazyOptional<IAbilityHolder> getAbilityHolder(Entity entity) {
        return entity.getCapability(ABILITY_HOLDER);
    }
}

