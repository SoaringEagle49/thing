/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  org.jetbrains.annotations.NotNull
 */
package io.github.edwinmindcraft.calio.api.registry;

import io.github.edwinmindcraft.calio.api.registry.ICalioDynamicRegistryManager;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.NotNull;

public interface DynamicRegistryListener {
    default public void whenAvailable(@NotNull ICalioDynamicRegistryManager manager) {
    }

    default public void whenNamed(@NotNull ResourceLocation name) {
    }
}

