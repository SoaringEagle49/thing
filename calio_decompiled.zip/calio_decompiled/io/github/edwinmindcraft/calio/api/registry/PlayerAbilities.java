/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.registries.IForgeRegistry
 *  net.minecraftforge.registries.RegistryObject
 */
package io.github.edwinmindcraft.calio.api.registry;

import io.github.edwinmindcraft.calio.api.ability.PlayerAbility;
import io.github.edwinmindcraft.calio.common.ability.AllowFlyingAbility;
import io.github.edwinmindcraft.calio.common.ability.FlyingAbility;
import io.github.edwinmindcraft.calio.common.ability.InstabuildAbility;
import io.github.edwinmindcraft.calio.common.ability.InvulnerableAbility;
import io.github.edwinmindcraft.calio.common.registry.CalioRegisters;
import java.util.function.Supplier;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegistryObject;

public class PlayerAbilities {
    public static Supplier<IForgeRegistry<PlayerAbility>> REGISTRY;
    public static final RegistryObject<PlayerAbility> FLYING;
    public static final RegistryObject<PlayerAbility> ALLOW_FLYING;
    public static final RegistryObject<PlayerAbility> INSTABUILD;
    public static final RegistryObject<PlayerAbility> INVULNERABLE;
    public static final RegistryObject<PlayerAbility> MAY_NOT_BUILD;

    public static void register() {
    }

    static {
        FLYING = CalioRegisters.PLAYER_ABILITIES.register("flying", FlyingAbility::new);
        ALLOW_FLYING = CalioRegisters.PLAYER_ABILITIES.register("mayfly", AllowFlyingAbility::new);
        INSTABUILD = CalioRegisters.PLAYER_ABILITIES.register("instabuild", InstabuildAbility::new);
        INVULNERABLE = CalioRegisters.PLAYER_ABILITIES.register("invulnerable", InvulnerableAbility::new);
        MAY_NOT_BUILD = CalioRegisters.PLAYER_ABILITIES.register("maynotbuild", InvulnerableAbility::new);
    }
}

