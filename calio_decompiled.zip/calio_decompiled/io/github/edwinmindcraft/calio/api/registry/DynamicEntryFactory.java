/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableMap
 *  com.google.gson.JsonElement
 *  net.minecraft.resources.ResourceLocation
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package io.github.edwinmindcraft.calio.api.registry;

import com.google.common.collect.ImmutableMap;
import com.google.gson.JsonElement;
import java.util.List;
import java.util.Map;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@FunctionalInterface
public interface DynamicEntryFactory<T> {
    @Nullable
    public T accept(@NotNull ResourceLocation var1, @NotNull List<JsonElement> var2);

    @NotNull
    default public Map<ResourceLocation, T> create(ResourceLocation location, @NotNull List<JsonElement> entries) {
        T accept = this.accept(location, entries);
        if (accept != null) {
            return ImmutableMap.of((Object)location, accept);
        }
        return ImmutableMap.of();
    }
}

