/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.DataResult
 *  net.minecraft.resources.ResourceLocation
 *  org.jetbrains.annotations.NotNull
 */
package io.github.edwinmindcraft.calio.api.registry;

import com.mojang.serialization.DataResult;
import io.github.edwinmindcraft.calio.api.registry.ICalioDynamicRegistryManager;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.NotNull;

public interface DynamicEntryValidator<T> {
    @NotNull
    public DataResult<T> validate(@NotNull ResourceLocation var1, @NotNull T var2, @NotNull ICalioDynamicRegistryManager var3);
}

