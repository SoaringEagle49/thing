/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  net.minecraft.core.Holder
 *  net.minecraft.core.HolderSet
 *  net.minecraft.tags.TagKey
 */
package io.github.edwinmindcraft.calio.api.network;

import com.mojang.serialization.Codec;
import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderSet;
import net.minecraft.tags.TagKey;

public record CodecSet<T>(Codec<Holder<T>> holder, Codec<Holder<T>> holderRef, Codec<TagKey<T>> directTag, Codec<TagKey<T>> hashedTag, Codec<HolderSet<T>> directSet, Codec<HolderSet<T>> hashedSet, Codec<List<HolderSet<T>>> set) {
}

