/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.GameType
 */
package io.github.edwinmindcraft.calio.api.ability;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameType;

public abstract class PlayerAbility {
    public abstract void grant(Player var1, GameType var2);

    public abstract void revoke(Player var1, GameType var2);

    public abstract boolean has(Player var1);
}

