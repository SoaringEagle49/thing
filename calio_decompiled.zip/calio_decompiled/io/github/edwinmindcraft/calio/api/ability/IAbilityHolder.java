/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.Entity
 *  net.minecraftforge.common.util.LazyOptional
 */
package io.github.edwinmindcraft.calio.api.ability;

import io.github.edwinmindcraft.calio.api.CalioAPI;
import io.github.edwinmindcraft.calio.api.ability.PlayerAbility;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.common.util.LazyOptional;

public interface IAbilityHolder {
    public static LazyOptional<IAbilityHolder> get(Entity entity) {
        return entity.getCapability(CalioAPI.ABILITY_HOLDER);
    }

    public static boolean has(Entity entity, PlayerAbility ability) {
        return IAbilityHolder.get(entity).map(x -> x.has(ability)).orElse(false);
    }

    public void grant(PlayerAbility var1, ResourceLocation var2);

    public void revoke(PlayerAbility var1, ResourceLocation var2);

    public boolean has(PlayerAbility var1, ResourceLocation var2);

    public boolean has(PlayerAbility var1);

    public boolean applyRemovals();

    public boolean applyAdditions();
}

