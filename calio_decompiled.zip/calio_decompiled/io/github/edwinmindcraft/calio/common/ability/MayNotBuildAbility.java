/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.GameType
 *  org.jetbrains.annotations.NotNull
 */
package io.github.edwinmindcraft.calio.common.ability;

import io.github.edwinmindcraft.calio.api.ability.PlayerAbility;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameType;
import org.jetbrains.annotations.NotNull;

public class MayNotBuildAbility
extends PlayerAbility {
    @Override
    public void grant(@NotNull Player player, @NotNull GameType gameType) {
        player.m_150110_().f_35938_ = false;
    }

    @Override
    public void revoke(@NotNull Player player, @NotNull GameType gameType) {
        player.m_150110_().f_35938_ = !gameType.m_46407_();
    }

    @Override
    public boolean has(@NotNull Player player) {
        return !player.m_150110_().f_35938_;
    }
}

