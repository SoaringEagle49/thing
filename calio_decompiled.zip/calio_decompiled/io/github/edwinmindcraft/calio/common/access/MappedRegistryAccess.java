/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Holder
 *  net.minecraft.resources.ResourceKey
 */
package io.github.edwinmindcraft.calio.common.access;

import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceKey;

public interface MappedRegistryAccess<T> {
    public Holder<T> calio$getOrCreateHolderOrThrow(ResourceKey<T> var1);
}

