/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.FriendlyByteBuf
 *  net.minecraftforge.network.NetworkEvent$Context
 */
package io.github.edwinmindcraft.calio.common.network.packet;

import io.github.edwinmindcraft.calio.api.CalioAPI;
import java.util.function.IntSupplier;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

public class C2SAcknowledgePacket
implements IntSupplier {
    private int loginIndex;

    public static C2SAcknowledgePacket decode(FriendlyByteBuf buf) {
        return new C2SAcknowledgePacket();
    }

    public void encode(FriendlyByteBuf buf) {
    }

    public void handle(Supplier<NetworkEvent.Context> handler) {
        CalioAPI.LOGGER.info("Received acknowledgment for login packet with id {}", (Object)this.loginIndex);
        handler.get().setPacketHandled(true);
    }

    @Override
    public int getAsInt() {
        return this.loginIndex;
    }

    public int getLoginIndex() {
        return this.loginIndex;
    }

    public void setLoginIndex(int loginIndex) {
        this.loginIndex = loginIndex;
    }
}

