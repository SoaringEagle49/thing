/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.ByteBuf
 *  net.minecraft.client.Minecraft
 *  net.minecraft.network.FriendlyByteBuf
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  net.minecraftforge.fml.DistExecutor
 *  net.minecraftforge.network.NetworkEvent$Context
 */
package io.github.edwinmindcraft.calio.common.network.packet;

import io.github.apace100.calio.registry.DataObjectRegistry;
import io.netty.buffer.ByteBuf;
import java.util.function.Supplier;
import net.minecraft.client.Minecraft;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

public record S2CDataObjectRegistryPacket(ResourceLocation registry, FriendlyByteBuf buffer) {
    public static S2CDataObjectRegistryPacket decode(FriendlyByteBuf buf) {
        return new S2CDataObjectRegistryPacket(buf.m_130281_(), buf);
    }

    public void encode(FriendlyByteBuf buf) {
        buf.m_130085_(this.registry());
        buf.writeBytes((ByteBuf)this.buffer());
    }

    @OnlyIn(value=Dist.CLIENT)
    private void handleClient(Supplier<NetworkEvent.Context> ctx) {
        Minecraft minecraftClient = Minecraft.m_91087_();
        DataObjectRegistry.getRegistry(this.registry()).receive(this.buffer(), minecraftClient.m_91091_() ? r -> {} : arg_0 -> ((NetworkEvent.Context)ctx.get()).enqueueWork(arg_0));
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn((Dist)Dist.CLIENT, () -> () -> this.lambda$handle$1((Supplier)ctx));
    }

    private /* synthetic */ void lambda$handle$1(Supplier ctx) {
        this.handleClient(ctx);
    }
}

