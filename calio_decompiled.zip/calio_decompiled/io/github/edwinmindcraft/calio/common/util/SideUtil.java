/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.util.thread.SidedThreadGroup
 */
package io.github.edwinmindcraft.calio.common.util;

import net.minecraftforge.fml.util.thread.SidedThreadGroup;

public class SideUtil {
    public static boolean isClient() {
        ThreadGroup group = Thread.currentThread().getThreadGroup();
        return group instanceof SidedThreadGroup && ((SidedThreadGroup)group).getSide().isClient();
    }
}

