/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.network.chat.Component
 *  net.minecraft.network.chat.MutableComponent
 *  net.minecraft.world.item.ItemStack
 */
package io.github.edwinmindcraft.calio.common.util;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.world.item.ItemStack;

public class CoreHelper {
    public static Component removeItalic(ItemStack stack, Component component) {
        if (component instanceof MutableComponent) {
            MutableComponent mutableComponent = (MutableComponent)component;
            mutableComponent.m_130938_(style -> style.m_131155_(Boolean.valueOf(false)));
        }
        return component;
    }

    public static void removeNonItalicFlag(ItemStack stack) {
        CompoundTag display = stack.m_41737_("display");
        if (display != null && display.m_128441_("NonItalicName")) {
            display.m_128473_("NonItalicName");
        }
    }
}

