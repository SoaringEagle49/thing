/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.mojang.datafixers.util.Pair
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.DataResult
 *  com.mojang.serialization.DynamicOps
 *  com.mojang.serialization.JsonOps
 *  net.minecraftforge.common.crafting.CraftingHelper
 *  net.minecraftforge.common.crafting.conditions.ICondition
 */
package io.github.edwinmindcraft.calio.common.util;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import net.minecraftforge.common.crafting.CraftingHelper;
import net.minecraftforge.common.crafting.conditions.ICondition;

public class ForgeConditionCodec
implements Codec<ICondition> {
    public static final ForgeConditionCodec INSTANCE = new ForgeConditionCodec();

    public <T> DataResult<Pair<ICondition, T>> decode(DynamicOps<T> ops, T input) {
        JsonElement json = (JsonElement)ops.convertMap((DynamicOps)JsonOps.INSTANCE, input);
        if (!json.isJsonObject()) {
            return DataResult.error(() -> "Forge Condition JSON is not a JsonObject");
        }
        try {
            ICondition condition = CraftingHelper.getCondition((JsonObject)json.getAsJsonObject());
            return DataResult.success((Object)Pair.of((Object)condition, (Object)ops.empty()));
        }
        catch (Exception e) {
            return DataResult.error(() -> "Failed to deserialize Forge Condition JSON: " + e.getMessage());
        }
    }

    public <T> DataResult<T> encode(ICondition input, DynamicOps<T> ops, T prefix) {
        try {
            JsonObject object = CraftingHelper.serialize((ICondition)input);
            return DataResult.success((Object)JsonOps.INSTANCE.convertTo(ops, (JsonElement)object));
        }
        catch (Exception e) {
            return DataResult.error(() -> "Failed to serialize Forge Condition JSON:" + e.getMessage());
        }
    }
}

