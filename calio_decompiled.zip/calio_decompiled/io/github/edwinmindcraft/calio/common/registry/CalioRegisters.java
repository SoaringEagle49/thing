/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.eventbus.api.IEventBus
 *  net.minecraftforge.registries.DeferredRegister
 *  net.minecraftforge.registries.RegistryBuilder
 */
package io.github.edwinmindcraft.calio.common.registry;

import io.github.edwinmindcraft.calio.api.CalioAPI;
import io.github.edwinmindcraft.calio.api.ability.PlayerAbility;
import io.github.edwinmindcraft.calio.api.registry.PlayerAbilities;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryBuilder;

public class CalioRegisters {
    public static final DeferredRegister<PlayerAbility> PLAYER_ABILITIES = DeferredRegister.create((ResourceLocation)CalioAPI.resource("player_ability"), (String)"calio");

    public static void register(IEventBus bus) {
        PlayerAbilities.REGISTRY = PLAYER_ABILITIES.makeRegistry(() -> new RegistryBuilder().disableSaving());
        PLAYER_ABILITIES.register(bus);
    }
}

