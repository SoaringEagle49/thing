/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.core.Holder
 *  net.minecraft.core.Holder$Reference
 *  net.minecraft.core.HolderOwner
 *  net.minecraft.core.MappedRegistry
 *  net.minecraft.resources.ResourceKey
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 */
package io.github.edwinmindcraft.calio.mixin;

import io.github.edwinmindcraft.calio.common.access.MappedRegistryAccess;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderOwner;
import net.minecraft.core.MappedRegistry;
import net.minecraft.resources.ResourceKey;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(value={MappedRegistry.class})
public abstract class MappedRegistryMixin<T>
implements MappedRegistryAccess<T> {
    @Shadow
    @Final
    private Map<ResourceKey<T>, Holder.Reference<T>> f_205842_;
    @Shadow
    @Nullable
    protected Map<T, Holder.Reference<T>> f_244282_;

    @Shadow
    public abstract HolderOwner<T> m_255331_();

    @Override
    public Holder<T> calio$getOrCreateHolderOrThrow(ResourceKey<T> key) {
        if (this.f_244282_ != null) {
            throw new IllegalStateException("This registry can't create new holders without value");
        }
        if (!this.f_205842_.containsKey(key)) {
            this.f_205842_.put(key, Holder.Reference.m_254896_(this.m_255331_(), key));
        }
        return (Holder)this.f_205842_.get(key);
    }
}

