/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.server.packs.PackType
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.client.event.ClientPlayerNetworkEvent$LoggingOut
 *  net.minecraftforge.client.event.RegisterClientReloadListenersEvent
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber
 *  net.minecraftforge.fml.common.Mod$EventBusSubscriber$Bus
 */
package io.github.edwinmindcraft.calio.client;

import io.github.apace100.calio.resource.OrderedResourceListenerManager;
import io.github.edwinmindcraft.calio.common.registry.CalioDynamicRegistryManager;
import net.minecraft.server.packs.PackType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RegisterClientReloadListenersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid="calio", value={Dist.CLIENT}, bus=Mod.EventBusSubscriber.Bus.MOD)
public class CalioClientEventHandler {
    @SubscribeEvent
    public void addClientResources(RegisterClientReloadListenersEvent event) {
        OrderedResourceListenerManager.getInstance().addResources(PackType.CLIENT_RESOURCES, arg_0 -> ((RegisterClientReloadListenersEvent)event).registerReloadListener(arg_0));
    }

    @SubscribeEvent
    public void onDisconnecting(ClientPlayerNetworkEvent.LoggingOut event) {
        CalioDynamicRegistryManager.removeClientInstance();
    }
}

