/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.core.RegistryAccess
 *  net.minecraftforge.server.ServerLifecycleHooks
 *  org.jetbrains.annotations.Nullable
 */
package io.github.edwinmindcraft.calio.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.core.RegistryAccess;
import net.minecraftforge.server.ServerLifecycleHooks;
import org.jetbrains.annotations.Nullable;

public class ClientHelper {
    public static boolean isServerContext(@Nullable RegistryAccess access) {
        Minecraft instance = Minecraft.m_91087_();
        if (instance == null) {
            return true;
        }
        if (instance.m_91403_() == null) {
            return true;
        }
        if (ServerLifecycleHooks.getCurrentServer() == null) {
            return false;
        }
        if (!ServerLifecycleHooks.getCurrentServer().m_6982_()) {
            return true;
        }
        return access != null && access != instance.m_91403_().m_105152_();
    }

    public static RegistryAccess getClientRegistryAccess() {
        Minecraft instance = Minecraft.m_91087_();
        if (instance.f_91073_ == null) {
            return null;
        }
        return instance.f_91073_.m_9598_();
    }
}

