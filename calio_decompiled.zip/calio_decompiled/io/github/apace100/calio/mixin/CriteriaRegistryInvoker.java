/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.advancements.CriteriaTriggers
 *  net.minecraft.advancements.CriterionTrigger
 */
package io.github.apace100.calio.mixin;

import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.advancements.CriterionTrigger;

@Deprecated
public interface CriteriaRegistryInvoker {
    @Deprecated
    public static <T extends CriterionTrigger<?>> T callRegister(T object) {
        return (T)CriteriaTriggers.m_10595_(object);
    }
}

