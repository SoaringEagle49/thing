/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.screens.inventory.AbstractContainerScreen
 *  net.minecraft.world.inventory.Slot
 */
package io.github.apace100.calio.mixin;

import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.Slot;

@Deprecated
public interface HandledScreenFocusedSlotAccessor {
    @Deprecated
    default public Slot getFocusedSlot() {
        return ((AbstractContainerScreen)this).f_97734_;
    }
}

