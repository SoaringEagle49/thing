/*
 * Decompiled with CFR 0.152.
 */
package io.github.apace100.calio.resource;

import io.github.apace100.calio.resource.OrderedResourceListenerManager;

public interface OrderedResourceListenerInitializer {
    public void registerResourceListeners(OrderedResourceListenerManager var1);
}

