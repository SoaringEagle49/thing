/*
 * Decompiled with CFR 0.152.
 */
package io.github.apace100.calio;

public final class ClassUtil {
    public static <T> Class<T> castClass(Class<?> aClass) {
        return aClass;
    }

    @SafeVarargs
    public static <T> Class<T> get(T ... array) {
        return array.getClass().getComponentType();
    }
}

