/*
 * Decompiled with CFR 0.152.
 */
package io.github.apace100.calio.registry;

import io.github.apace100.calio.data.SerializableData;

public interface DataObjectFactory<T> {
    public SerializableData getData();

    public T fromData(SerializableData.Instance var1);

    public SerializableData.Instance toData(T var1);
}

