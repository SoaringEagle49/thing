/*
 * Decompiled with CFR 0.152.
 */
package io.github.apace100.calio.registry;

import io.github.apace100.calio.registry.DataObjectFactory;

public interface DataObject<T extends DataObject<T>> {
    public DataObjectFactory<T> getFactory();
}

