/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.advancements.CriteriaTriggers
 *  net.minecraft.advancements.CriterionTrigger
 *  net.minecraft.core.Registry
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.tags.TagKey
 *  net.minecraft.world.item.ItemStack
 *  net.minecraftforge.fml.ModLoadingContext
 *  net.minecraftforge.fml.common.Mod
 */
package io.github.apace100.calio;

import io.github.apace100.calio.CodeTriggerCriterion;
import io.github.edwinmindcraft.calio.api.CalioAPI;
import io.github.edwinmindcraft.calio.common.CalioCommon;
import io.github.edwinmindcraft.calio.common.CalioConfig;
import java.util.Objects;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.advancements.CriterionTrigger;
import net.minecraft.core.Registry;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;

@Mod(value="calio")
public class Calio {
    public static boolean isDebugMode() {
        return (Boolean)CalioConfig.COMMON.debugMode.get();
    }

    public Calio() {
        CalioAPI.LOGGER.info("Calio {} initializing...", (Object)ModLoadingContext.get().getActiveContainer().getModInfo().getVersion());
        CalioCommon.initialize();
        CriteriaTriggers.m_10595_((CriterionTrigger)CodeTriggerCriterion.INSTANCE);
    }

    public static boolean hasNonItalicName(ItemStack stack) {
        if (stack.m_41782_()) {
            CompoundTag display = stack.m_41737_("display");
            return display != null && display.m_128471_("NonItalicName");
        }
        return false;
    }

    public static void setNameNonItalic(ItemStack stack) {
        if (stack != null) {
            stack.m_41698_("display").m_128379_("NonItalicName", true);
        }
    }

    public static boolean areEntityAttributesAdditional(ItemStack stack) {
        return stack.m_41782_() && Objects.requireNonNull(stack.m_41783_()).m_128441_("AdditionalAttributes") && stack.m_41783_().m_128471_("AdditionalAttributes");
    }

    public static void setEntityAttributesAdditional(ItemStack stack, boolean additional) {
        if (stack != null) {
            if (additional) {
                stack.m_41784_().m_128379_("AdditionalAttributes", true);
            } else if (stack.m_41782_()) {
                Objects.requireNonNull(stack.m_41783_()).m_128473_("AdditionalAttributes");
            }
        }
    }

    @Deprecated
    public static <T> boolean areTagsEqual(ResourceKey<? extends Registry<T>> registryKey, TagKey<T> tag1, TagKey<T> tag2) {
        return Calio.areTagsEqual(tag1, tag2);
    }

    @Deprecated
    public static <T> boolean areTagsEqual(TagKey<T> tag1, TagKey<T> tag2) {
        if (tag1 == tag2) {
            return true;
        }
        if (tag1 == null || tag2 == null) {
            return false;
        }
        if (!tag1.f_203867_().equals((Object)tag2.f_203867_())) {
            return false;
        }
        return tag1.f_203868_().equals((Object)tag2.f_203868_());
    }
}

