/*
 * Decompiled with CFR 0.152.
 */
package io.github.apace100.calio;

public final class NbtConstants {
    public static final String NON_ITALIC_NAME = "NonItalicName";
    public static final String ADDITIONAL_ATTRIBUTES = "AdditionalAttributes";
}

