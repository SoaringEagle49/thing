/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.ImmutableSet
 *  com.google.common.collect.ImmutableSet$Builder
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.server.packs.PackType
 *  net.minecraft.server.packs.resources.PreparableReloadListener
 *  org.jetbrains.annotations.ApiStatus$ScheduledForRemoval
 */
package io.github.apace100.calio.util;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import io.github.apace100.calio.resource.OrderedResourceListener;
import io.github.apace100.calio.resource.OrderedResourceListenerManager;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.OptionalInt;
import java.util.stream.Collectors;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.resources.PreparableReloadListener;
import org.jetbrains.annotations.ApiStatus;

@Deprecated(forRemoval=true, since="1.18.2")
@ApiStatus.ScheduledForRemoval(inVersion="1.19")
public final class OrderedResourceListeners {
    private static final Map<ResourceLocation, ImmutableRegistration> REGISTRATIONS = new HashMap<ResourceLocation, ImmutableRegistration>();

    @Deprecated
    public static List<PreparableReloadListener> orderedList() {
        int prevSize;
        HashSet<ResourceLocation> handled = new HashSet<ResourceLocation>();
        LinkedList<ResourceLocation> ordered = new LinkedList<ResourceLocation>();
        do {
            prevSize = handled.size();
            for (ImmutableRegistration value : REGISTRATIONS.values()) {
                if (handled.contains(value.key()) || !handled.containsAll((Collection<?>)value.dependencies())) continue;
                handled.add(value.key());
                OptionalInt min = value.children().stream().mapToInt(ordered::indexOf).filter(x -> x >= 0).min();
                if (min.isEmpty()) {
                    ordered.add(value.key());
                    continue;
                }
                ordered.add(min.getAsInt(), value.key());
            }
        } while (prevSize != handled.size());
        if (handled.size() != REGISTRATIONS.size()) {
            throw new IllegalStateException("Some validators have missing or circular dependencies: [" + String.join((CharSequence)",", REGISTRATIONS.values().stream().filter(x -> !handled.contains(x.key())).map(Record::toString).collect(Collectors.toSet())) + "]");
        }
        return (List)ordered.stream().map(REGISTRATIONS::get).filter(x -> !x.dummy() && x.listener() != null).map(ImmutableRegistration::listener).collect(ImmutableList.toImmutableList());
    }

    @Deprecated
    public static Registration register(PreparableReloadListener resourceReloadListener, ResourceLocation location) {
        return new Registration(resourceReloadListener, location);
    }

    @Deprecated
    public static void addDummy(ResourceLocation location) {
        new Registration(null, location, true).complete();
    }

    @Deprecated
    public static void completeRegistration(Registration registration) {
        ImmutableRegistration value = new ImmutableRegistration(registration.resourceReloadListener, registration.key(), (ImmutableSet<ResourceLocation>)registration.afterSet.build(), (ImmutableSet<ResourceLocation>)registration.beforeSet.build(), registration.dummy);
        REGISTRATIONS.put(registration.key(), value);
        OrderedResourceListener.Registration register = OrderedResourceListenerManager.getInstance().register(PackType.SERVER_DATA, registration.key(), registration.resourceReloadListener);
        value.children().forEach(register::before);
        value.dependencies().forEach(register::after);
        register.complete();
    }

    @Deprecated
    private record ImmutableRegistration(PreparableReloadListener listener, ResourceLocation key, ImmutableSet<ResourceLocation> dependencies, ImmutableSet<ResourceLocation> children, boolean dummy) {
    }

    @Deprecated
    public static class Registration {
        private final PreparableReloadListener resourceReloadListener;
        private final ResourceLocation key;
        private final ImmutableSet.Builder<ResourceLocation> afterSet = new ImmutableSet.Builder();
        private final ImmutableSet.Builder<ResourceLocation> beforeSet = new ImmutableSet.Builder();
        private final boolean dummy;
        private boolean isCompleted;

        @Deprecated
        private Registration(PreparableReloadListener resourceReloadListener, ResourceLocation key, boolean dummy) {
            this.resourceReloadListener = resourceReloadListener;
            this.key = key;
            this.dummy = dummy;
        }

        @Deprecated
        private Registration(PreparableReloadListener resourceReloadListener, ResourceLocation key) {
            this(resourceReloadListener, key, false);
        }

        @Deprecated
        public ResourceLocation key() {
            return this.key;
        }

        @Deprecated
        public Registration after(ResourceLocation identifier) {
            if (this.isCompleted) {
                throw new IllegalStateException("Can't add a resource reload listener registration dependency after it was completed.");
            }
            this.afterSet.add((Object)identifier);
            return this;
        }

        @Deprecated
        public Registration before(ResourceLocation identifier) {
            if (this.isCompleted) {
                throw new IllegalStateException("Can't add a resource reload listener registration dependency after it was completed.");
            }
            this.beforeSet.add((Object)identifier);
            return this;
        }

        @Deprecated
        public void complete() {
            OrderedResourceListeners.completeRegistration(this);
            this.isCompleted = true;
        }
    }
}

