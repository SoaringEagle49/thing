/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.effect.MobEffectInstance
 */
package io.github.apace100.calio.util;

import net.minecraft.world.effect.MobEffectInstance;

public class StatusEffectChance {
    public MobEffectInstance statusEffectInstance;
    public float chance;
}

