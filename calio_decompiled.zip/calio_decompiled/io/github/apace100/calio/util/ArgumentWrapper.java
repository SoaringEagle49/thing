/*
 * Decompiled with CFR 0.152.
 */
package io.github.apace100.calio.util;

public record ArgumentWrapper<T>(T get, String rawArgument) {
}

