/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonSyntaxException
 *  com.mojang.brigadier.StringReader
 *  com.mojang.brigadier.exceptions.CommandSyntaxException
 *  net.minecraft.core.particles.ParticleOptions
 *  net.minecraft.core.particles.ParticleOptions$Deserializer
 *  net.minecraft.core.particles.ParticleType
 *  net.minecraft.network.FriendlyByteBuf
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.tags.TagKey
 *  net.minecraft.util.GsonHelper
 *  net.minecraft.world.effect.MobEffect
 *  net.minecraft.world.effect.MobEffectInstance
 *  net.minecraft.world.entity.ai.attributes.AttributeModifier
 *  net.minecraft.world.entity.ai.attributes.AttributeModifier$Operation
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.material.Fluid
 *  net.minecraftforge.registries.ForgeRegistries
 *  org.apache.commons.lang3.Validate
 */
package io.github.apace100.calio;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Objects;
import java.util.function.Function;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.material.Fluid;
import net.minecraftforge.registries.ForgeRegistries;
import org.apache.commons.lang3.Validate;

public class SerializationHelper {
    public static TagKey<Fluid> getFluidTagFromId(ResourceLocation id) {
        return Objects.requireNonNull(ForgeRegistries.FLUIDS.tags()).createTagKey(id);
    }

    public static TagKey<Block> getBlockTagFromId(ResourceLocation id) {
        return Objects.requireNonNull(ForgeRegistries.BLOCKS.tags()).createTagKey(id);
    }

    @Deprecated
    public static AttributeModifier readAttributeModifier(JsonElement jsonElement) {
        if (jsonElement.isJsonObject()) {
            JsonObject json = jsonElement.getAsJsonObject();
            String name = GsonHelper.m_13851_((JsonObject)json, (String)"name", (String)"Unnamed attribute modifier");
            String operation = GsonHelper.m_13906_((JsonObject)json, (String)"operation").toUpperCase(Locale.ROOT);
            double value = GsonHelper.m_13915_((JsonObject)json, (String)"value");
            return new AttributeModifier(name, value, AttributeModifier.Operation.valueOf((String)operation));
        }
        throw new JsonSyntaxException("Attribute modifier needs to be a JSON object.");
    }

    @Deprecated
    public static JsonElement writeAttributeModifier(AttributeModifier modifier) {
        JsonObject obj = new JsonObject();
        obj.addProperty("name", modifier.m_22214_());
        obj.addProperty("operation", modifier.m_22217_().name());
        obj.addProperty("value", (Number)modifier.m_22218_());
        return obj;
    }

    @Deprecated
    public static AttributeModifier readAttributeModifier(FriendlyByteBuf buf) {
        String modName = buf.m_130277_();
        double modValue = buf.readDouble();
        int operation = buf.readInt();
        return new AttributeModifier(modName, modValue, AttributeModifier.Operation.m_22236_((int)operation));
    }

    @Deprecated
    public static void writeAttributeModifier(FriendlyByteBuf buf, AttributeModifier modifier) {
        buf.m_130070_(modifier.m_22214_());
        buf.writeDouble(modifier.m_22218_());
        buf.writeInt(modifier.m_22217_().m_22235_());
    }

    public static MobEffectInstance readStatusEffect(JsonElement jsonElement) {
        if (jsonElement.isJsonObject()) {
            JsonObject json = jsonElement.getAsJsonObject();
            String effect = GsonHelper.m_13906_((JsonObject)json, (String)"effect");
            MobEffect effectOptional = (MobEffect)ForgeRegistries.MOB_EFFECTS.getValue(ResourceLocation.m_135820_((String)effect));
            if (effectOptional == null) {
                throw new JsonSyntaxException("Error reading status effect: could not find status effect with id: " + effect);
            }
            int duration = GsonHelper.m_13824_((JsonObject)json, (String)"duration", (int)100);
            int amplifier = GsonHelper.m_13824_((JsonObject)json, (String)"amplifier", (int)0);
            boolean ambient = GsonHelper.m_13855_((JsonObject)json, (String)"is_ambient", (boolean)false);
            boolean showParticles = GsonHelper.m_13855_((JsonObject)json, (String)"show_particles", (boolean)true);
            boolean showIcon = GsonHelper.m_13855_((JsonObject)json, (String)"show_icon", (boolean)true);
            return new MobEffectInstance(effectOptional, duration, amplifier, ambient, showParticles, showIcon);
        }
        throw new JsonSyntaxException("Expected status effect to be a json object.");
    }

    public static JsonElement writeStatusEffect(MobEffectInstance instance) {
        JsonObject object = new JsonObject();
        ResourceLocation registryName = ForgeRegistries.MOB_EFFECTS.getKey((Object)instance.m_19544_());
        Validate.notNull((Object)registryName, (String)"Unregistered mob effect: %s", (Object[])new Object[]{instance.m_19544_()});
        object.addProperty("effect", registryName.toString());
        object.addProperty("duration", (Number)instance.m_19557_());
        object.addProperty("amplifier", (Number)instance.m_19564_());
        object.addProperty("is_ambient", Boolean.valueOf(instance.m_19571_()));
        object.addProperty("show_particles", Boolean.valueOf(instance.m_19572_()));
        object.addProperty("show_icon", Boolean.valueOf(instance.m_19575_()));
        return object;
    }

    public static MobEffectInstance readStatusEffect(FriendlyByteBuf buf) {
        ResourceLocation effect = buf.m_130281_();
        int duration = buf.readInt();
        int amplifier = buf.readInt();
        boolean ambient = buf.readBoolean();
        boolean showParticles = buf.readBoolean();
        boolean showIcon = buf.readBoolean();
        MobEffect mobEffect = (MobEffect)ForgeRegistries.MOB_EFFECTS.getValue(effect);
        Validate.notNull((Object)mobEffect, (String)"Missing mob effect: %s", (Object[])new Object[]{effect});
        return new MobEffectInstance(mobEffect, duration, amplifier, ambient, showParticles, showIcon);
    }

    public static void writeStatusEffect(FriendlyByteBuf buf, MobEffectInstance statusEffectInstance) {
        ResourceLocation registryName = ForgeRegistries.MOB_EFFECTS.getKey((Object)statusEffectInstance.m_19544_());
        Validate.notNull((Object)registryName, (String)"Unregistered mob effect: %s".formatted(statusEffectInstance.m_19544_()), (Object[])new Object[0]);
        buf.m_130085_(registryName);
        buf.writeInt(statusEffectInstance.m_19557_());
        buf.writeInt(statusEffectInstance.m_19564_());
        buf.writeBoolean(statusEffectInstance.m_19571_());
        buf.writeBoolean(statusEffectInstance.m_19572_());
        buf.writeBoolean(statusEffectInstance.m_19575_());
    }

    public static <T extends Enum<T>> HashMap<String, T> buildEnumMap(Class<T> enumClass, Function<T, String> enumToString) {
        HashMap<String, Enum> map = new HashMap<String, Enum>();
        for (Enum enumConstant : (Enum[])enumClass.getEnumConstants()) {
            map.put(enumToString.apply(enumConstant), enumConstant);
        }
        return map;
    }

    public static <T extends ParticleOptions> T loadParticle(ParticleType<T> type, String parameters) {
        ParticleOptions.Deserializer factory = type.m_123743_();
        try {
            return (T)factory.m_5739_(type, new StringReader(" " + parameters));
        }
        catch (CommandSyntaxException e) {
            throw new RuntimeException(e);
        }
    }
}

