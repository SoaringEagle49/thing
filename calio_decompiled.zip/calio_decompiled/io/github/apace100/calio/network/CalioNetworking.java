/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 */
package io.github.apace100.calio.network;

import net.minecraft.resources.ResourceLocation;

public class CalioNetworking {
    public static final ResourceLocation SYNC_DATA_OBJECT_REGISTRY = new ResourceLocation("calio", "sync_data_object_registry");
}

