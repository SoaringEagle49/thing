/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 *  com.google.gson.Gson
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonParseException
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.server.packs.resources.Resource
 *  net.minecraft.server.packs.resources.ResourceManager
 *  net.minecraft.server.packs.resources.SimplePreparableReloadListener
 *  net.minecraft.util.GsonHelper
 *  net.minecraft.util.profiling.ProfilerFiller
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 *  org.jetbrains.annotations.NotNull
 */
package io.github.apace100.calio.data;

import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimplePreparableReloadListener;
import net.minecraft.util.GsonHelper;
import net.minecraft.util.profiling.ProfilerFiller;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;

public abstract class MultiJsonDataLoader
extends SimplePreparableReloadListener<Map<ResourceLocation, List<JsonElement>>> {
    private static final Logger LOGGER = LogManager.getLogger();
    private static final int FILE_SUFFIX_LENGTH = ".json".length();
    private final Gson gson;
    private final String dataType;

    public MultiJsonDataLoader(Gson gson, String dataType) {
        this.gson = gson;
        this.dataType = dataType;
    }

    @NotNull
    protected Map<ResourceLocation, List<JsonElement>> prepare(ResourceManager resourceManager, @NotNull ProfilerFiller profiler) {
        HashMap map = Maps.newHashMap();
        int i = this.dataType.length() + 1;
        HashSet<String> resourcesHandled = new HashSet<String>();
        for (Map.Entry entry : resourceManager.m_214160_(this.dataType, stringx -> stringx.m_135815_().endsWith(".json")).entrySet()) {
            ResourceLocation identifier = (ResourceLocation)entry.getKey();
            String string = identifier.m_135815_();
            ResourceLocation identifier2 = new ResourceLocation(identifier.m_135827_(), string.substring(i, string.length() - FILE_SUFFIX_LENGTH));
            resourcesHandled.clear();
            for (Resource resource : (List)entry.getValue()) {
                if (resourcesHandled.contains(resource.m_215506_())) continue;
                resourcesHandled.add(resource.m_215506_());
                try {
                    BufferedReader reader = resource.m_215508_();
                    try {
                        JsonElement jsonElement = (JsonElement)GsonHelper.m_13776_((Gson)this.gson, (Reader)reader, JsonElement.class);
                        if (jsonElement != null) {
                            if (map.containsKey(identifier2)) {
                                ((List)map.get(identifier2)).add(jsonElement);
                                continue;
                            }
                            LinkedList<JsonElement> elementList = new LinkedList<JsonElement>();
                            elementList.add(jsonElement);
                            map.put(identifier2, elementList);
                            continue;
                        }
                        LOGGER.error("Couldn't load data file {} from {} as it's null or empty", (Object)identifier2, (Object)identifier);
                    }
                    finally {
                        if (reader == null) continue;
                        ((Reader)reader).close();
                    }
                }
                catch (JsonParseException | IOException | IllegalArgumentException e) {
                    LOGGER.error("Couldn't parse data file {} from {}", (Object)identifier2, (Object)identifier, (Object)e);
                }
            }
        }
        return map;
    }
}

