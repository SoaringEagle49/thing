/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  com.google.gson.JsonElement
 *  net.minecraft.Util
 *  net.minecraft.data.CachedOutput
 *  net.minecraft.data.DataGenerator
 *  net.minecraft.data.DataProvider
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.server.packs.PackType
 *  net.minecraftforge.common.data.ExistingFileHelper
 *  org.jetbrains.annotations.NotNull
 */
package io.github.apace100.calio.data;

import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import net.minecraft.Util;
import net.minecraft.data.CachedOutput;
import net.minecraft.data.DataGenerator;
import net.minecraft.data.DataProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.PackType;
import net.minecraftforge.common.data.ExistingFileHelper;
import org.jetbrains.annotations.NotNull;

public abstract class JsonDataProvider<T>
implements DataProvider {
    protected static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    protected final String modid;
    protected final String folder;
    protected final DataGenerator generator;
    protected final ExistingFileHelper existingFileHelper;
    protected final Map<ResourceLocation, T> objects = new HashMap<ResourceLocation, T>();
    private final PackType resourceType;

    protected JsonDataProvider(DataGenerator generator, String modid, ExistingFileHelper existingFileHelper, String folder, PackType resourceType) {
        this.modid = modid;
        this.folder = folder;
        this.generator = generator;
        this.existingFileHelper = existingFileHelper;
        this.resourceType = resourceType;
    }

    protected abstract void populate();

    protected void validate() {
    }

    protected abstract JsonElement asJson(T var1);

    public void add(ResourceLocation location, T input) {
        this.objects.put(location, input);
    }

    public void add(String name, T input) {
        this.add(new ResourceLocation(this.modid, name), input);
    }

    public CompletableFuture<?> m_213708_(@NotNull CachedOutput cache) {
        this.populate();
        this.validate();
        ArrayList list = Lists.newArrayList();
        for (Map.Entry<ResourceLocation, T> entry : this.objects.entrySet()) {
            list.add(CompletableFuture.supplyAsync(() -> DataProvider.m_253162_((CachedOutput)cache, (JsonElement)this.asJson(entry.getValue()), (Path)this.getPath((ResourceLocation)entry.getKey())), Util.m_183991_()).thenCompose(p_253441_ -> p_253441_));
        }
        return Util.m_143840_((List)list);
    }

    protected Path getPath(ResourceLocation entry) {
        return this.generator.getPackOutput().m_245114_().resolve(Paths.get(this.resourceType.m_10305_(), entry.m_135827_(), this.folder, entry.m_135815_() + ".json"));
    }
}

