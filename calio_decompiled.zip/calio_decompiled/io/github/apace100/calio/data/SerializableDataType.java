/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.BiMap
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonNull
 *  com.google.gson.JsonParseException
 *  com.google.gson.JsonSyntaxException
 *  com.mojang.brigadier.StringReader
 *  com.mojang.brigadier.arguments.ArgumentType
 *  com.mojang.brigadier.exceptions.CommandSyntaxException
 *  com.mojang.datafixers.util.Pair
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.DataResult
 *  com.mojang.serialization.DynamicOps
 *  com.mojang.serialization.JsonOps
 *  io.netty.buffer.ByteBuf
 *  io.netty.buffer.ByteBufInputStream
 *  io.netty.buffer.ByteBufOutputStream
 *  io.netty.buffer.Unpooled
 *  io.netty.handler.codec.EncoderException
 *  net.minecraft.core.Holder
 *  net.minecraft.core.Holder$Reference
 *  net.minecraft.core.Registry
 *  net.minecraft.nbt.NbtAccounter
 *  net.minecraft.nbt.NbtIo
 *  net.minecraft.nbt.NbtOps
 *  net.minecraft.nbt.Tag
 *  net.minecraft.network.FriendlyByteBuf
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.tags.TagKey
 *  net.minecraftforge.registries.IForgeRegistry
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package io.github.apace100.calio.data;

import com.google.common.collect.BiMap;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import io.github.apace100.calio.ClassUtil;
import io.github.apace100.calio.FilterableWeightedList;
import io.github.apace100.calio.SerializationHelper;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.apace100.calio.util.ArgumentWrapper;
import io.github.apace100.calio.util.TagLike;
import io.github.edwinmindcraft.calio.api.CalioAPI;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import io.github.edwinmindcraft.calio.api.network.EnumValueCodec;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufInputStream;
import io.netty.buffer.ByteBufOutputStream;
import io.netty.buffer.Unpooled;
import io.netty.handler.codec.EncoderException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.nbt.NbtAccounter;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraftforge.registries.IForgeRegistry;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class SerializableDataType<T>
implements Codec<T> {
    private final Class<T> dataClass;
    private final Codec<T> codec;
    private final BiConsumer<FriendlyByteBuf, T> send;
    private final Function<FriendlyByteBuf, T> receive;
    private final Function<JsonElement, T> read;
    private final Function<T, JsonElement> write;

    public SerializableDataType(Class<T> dataClass, BiConsumer<FriendlyByteBuf, T> send, Function<FriendlyByteBuf, T> receive, Function<JsonElement, T> read) {
        this(dataClass, send, receive, read, null);
    }

    public SerializableDataType(Class<T> dataClass, BiConsumer<FriendlyByteBuf, T> send, Function<FriendlyByteBuf, T> receive, Function<JsonElement, T> read, Function<T, JsonElement> write) {
        this.dataClass = dataClass;
        this.send = send;
        this.receive = receive;
        this.read = read;
        this.write = write;
        this.codec = null;
    }

    public SerializableDataType(Class<T> dataClass, Codec<T> codec) {
        this.dataClass = dataClass;
        this.codec = codec;
        this.send = (buf, t) -> this.writeWithCodec((FriendlyByteBuf)buf, this.codec, (T)t);
        this.receive = buf -> this.readWithCodec((FriendlyByteBuf)buf, codec);
        this.read = jsonElement -> codec.decode((DynamicOps)JsonOps.INSTANCE, jsonElement).map(Pair::getFirst).getOrThrow(false, s -> {
            throw new JsonParseException(s);
        });
        this.write = t -> (JsonElement)codec.encodeStart((DynamicOps)JsonOps.INSTANCE, t).getOrThrow(false, s -> {});
    }

    public static <T> boolean isDataContext(DynamicOps<T> ops) {
        return !ops.compressMaps() && ops instanceof JsonOps;
    }

    public static <T> SerializableDataType<List<T>> list(SerializableDataType<T> singleDataType) {
        return new SerializableDataType<List<T>>(ClassUtil.castClass(List.class), CalioCodecHelper.listOf(singleDataType));
    }

    public static <T> SerializableDataType<FilterableWeightedList<T>> weightedList(SerializableDataType<T> singleDataType) {
        return new SerializableDataType<FilterableWeightedList<T>>(ClassUtil.castClass(FilterableWeightedList.class), CalioCodecHelper.weightedListOf(singleDataType));
    }

    public static <T> SerializableDataType<T> registry(Class<T> dataClass, Registry<T> registry) {
        return SerializableDataType.wrap(dataClass, SerializableDataTypes.IDENTIFIER, arg_0 -> registry.m_7981_(arg_0), id -> registry.m_6612_(id).orElseThrow(() -> new RuntimeException("Identifier \"" + id + "\" was not registered in registry \"" + registry.m_123023_().m_135782_() + "\".")));
    }

    public static <T> SerializableDataType<T> registry(Class<T> dataClass, IForgeRegistry<T> registry) {
        return SerializableDataType.wrap(dataClass, SerializableDataTypes.IDENTIFIER, arg_0 -> registry.getKey(arg_0), id -> {
            Optional<Holder.Reference> delegate = registry.getDelegate(id).filter(Holder::m_203633_);
            if (delegate.isEmpty()) {
                throw new RuntimeException("Identifier \"" + id + "\" was not registered in registry \"" + registry.getRegistryName() + "\".");
            }
            return delegate.get().m_203334_();
        });
    }

    public static <T> SerializableDataType<T> compound(Class<T> dataClass, SerializableData data, Function<SerializableData.Instance, T> toInstance, BiFunction<SerializableData, T, SerializableData.Instance> toData) {
        return new SerializableDataType<T>(dataClass, data.codec().xmap(toInstance, t -> (SerializableData.Instance)toData.apply(data, t)));
    }

    public static <T extends Enum<T>> SerializableDataType<T> enumValue(Class<T> dataClass) {
        return SerializableDataType.enumValue(dataClass, (HashMap)null);
    }

    public static <T extends Enum<T>> SerializableDataType<T> enumValue(Class<T> dataClass, @Nullable HashMap<String, T> additionalMap) {
        return new SerializableDataType<T>(dataClass, new EnumValueCodec((Enum[])dataClass.getEnumConstants(), additionalMap));
    }

    public static <T extends Enum<T>> SerializableDataType<T> enumValue(Class<T> dataClass, @NotNull Function<T, String> additionalMap) {
        return new SerializableDataType<T>(dataClass, new EnumValueCodec((Enum[])dataClass.getEnumConstants(), SerializationHelper.buildEnumMap(dataClass, additionalMap)));
    }

    public static <T> SerializableDataType<T> mapped(Class<T> dataClass, BiMap<String, T> map) {
        return new SerializableDataType<T>(dataClass, Codec.STRING.xmap(arg_0 -> map.get(arg_0), arg_0 -> map.inverse().get(arg_0)));
    }

    public static <T, U> SerializableDataType<T> wrap(Class<T> dataClass, SerializableDataType<U> base, Function<T, U> toFunction, Function<U, T> fromFunction) {
        return base.codec().map(codec -> new SerializableDataType(dataClass, codec.xmap(fromFunction, toFunction))).orElseGet(() -> new SerializableDataType<Object>(dataClass, (buf, t) -> base.send((FriendlyByteBuf)buf, toFunction.apply(t)), buf -> fromFunction.apply(base.receive((FriendlyByteBuf)buf)), json -> fromFunction.apply(base.read((JsonElement)json)), base.write != null ? t -> base.write(toFunction.apply(t)) : null));
    }

    public static <T> SerializableDataType<TagKey<T>> tag(ResourceKey<? extends Registry<T>> registryKey) {
        return SerializableDataType.wrap(ClassUtil.castClass(TagKey.class), SerializableDataTypes.IDENTIFIER, TagKey::f_203868_, id -> TagKey.m_203882_((ResourceKey)registryKey, (ResourceLocation)id));
    }

    public static <T> SerializableDataType<ResourceKey<T>> registryKey(ResourceKey<Registry<T>> registryKeyRegistry) {
        return SerializableDataType.wrap(ClassUtil.castClass(ResourceKey.class), SerializableDataTypes.IDENTIFIER, ResourceKey::m_135782_, identifier -> ResourceKey.m_135785_((ResourceKey)registryKeyRegistry, (ResourceLocation)identifier));
    }

    public static <T extends Enum<T>> SerializableDataType<EnumSet<T>> enumSet(Class<T> enumClass, SerializableDataType<T> enumDataType) {
        return new SerializableDataType<EnumSet<T>>(ClassUtil.castClass(EnumSet.class), CalioCodecHelper.setOf(enumDataType).xmap(EnumSet::copyOf, Function.identity()));
    }

    public void send(FriendlyByteBuf buffer, Object value) {
        this.send.accept(buffer, (FriendlyByteBuf)this.cast(value));
    }

    public T receive(FriendlyByteBuf buffer) {
        return this.receive.apply(buffer);
    }

    public T read(JsonElement jsonElement) {
        return this.read.apply(jsonElement);
    }

    public JsonElement write(T value) {
        return this.write == null ? JsonNull.INSTANCE : this.write.apply(value);
    }

    public T cast(Object data) {
        return this.dataClass.cast(data);
    }

    public Optional<Codec<T>> codec() {
        return Optional.ofNullable(this.codec);
    }

    public <T1> DataResult<Pair<T, T1>> decode(DynamicOps<T1> ops, T1 input) {
        if (this.codec != null) {
            return this.codec.decode(ops, input);
        }
        if (SerializableDataType.isDataContext(ops)) {
            JsonElement jsonElement = (JsonElement)ops.convertTo((DynamicOps)JsonOps.INSTANCE, input);
            try {
                return DataResult.success((Object)Pair.of(this.read.apply(jsonElement), (Object)ops.empty()));
            }
            catch (Exception e) {
                return DataResult.error(() -> "At " + this.dataClass.getSimpleName() + ": " + e.getMessage());
            }
        }
        return ops.getByteBuffer(input).flatMap(x -> {
            FriendlyByteBuf buffer = new FriendlyByteBuf(Unpooled.copiedBuffer((ByteBuffer)x));
            try {
                Pair pair = Pair.of(this.receive.apply(buffer), (Object)ops.empty());
                DataResult dataResult = DataResult.success((Object)pair);
                return dataResult;
            }
            catch (Exception e) {
                DataResult dataResult = DataResult.error(() -> "At " + this.dataClass.getSimpleName() + ": " + e.getMessage());
                return dataResult;
            }
            finally {
                buffer.release();
            }
        });
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public <T1> DataResult<T1> encode(T input, DynamicOps<T1> ops, T1 prefix) {
        if (this.codec != null) {
            try {
                return this.codec.encode(input, ops, prefix);
            }
            catch (Throwable t) {
                CalioAPI.LOGGER.error("Error", t);
                return DataResult.error(() -> "Error caught while encoding " + this.dataClass.getSimpleName() + ": " + input + ":" + t.getMessage());
            }
        }
        if (SerializableDataType.isDataContext(ops)) {
            if (this.write == null) {
                return DataResult.error(() -> "Writing is unsupported for type: " + this.dataClass.getSimpleName());
            }
            try {
                return DataResult.success((Object)JsonOps.INSTANCE.convertTo(ops, this.write.apply(input)));
            }
            catch (Exception e) {
                return DataResult.error(() -> "At " + this.dataClass.getSimpleName() + ": " + e.getMessage());
            }
        }
        FriendlyByteBuf buffer = new FriendlyByteBuf(Unpooled.buffer());
        try {
            this.send.accept(buffer, (FriendlyByteBuf)input);
            DataResult dataResult = DataResult.success((Object)ops.createByteList(buffer.nioBuffer()));
            return dataResult;
        }
        catch (Exception e) {
            DataResult dataResult = DataResult.error(() -> "At " + this.dataClass.getSimpleName() + ": " + e.getMessage());
            return dataResult;
        }
        finally {
            buffer.release();
        }
    }

    public static <T, U extends ArgumentType<T>> SerializableDataType<ArgumentWrapper<T>> argumentType(U argumentType) {
        return SerializableDataType.wrap(ClassUtil.castClass(ArgumentWrapper.class), SerializableDataTypes.STRING, ArgumentWrapper::rawArgument, str -> {
            try {
                Object t = argumentType.parse(new StringReader(str));
                return new ArgumentWrapper<Object>(t, (String)str);
            }
            catch (CommandSyntaxException e) {
                throw new RuntimeException("Wrong syntax in argument type data", e);
            }
        });
    }

    public static <T> SerializableDataType<TagLike<T>> tagLike(Registry<T> registry) {
        return new SerializableDataType<TagLike<T>>(ClassUtil.castClass(TagLike.class), (packetByteBuf, tagLike) -> tagLike.write((FriendlyByteBuf)packetByteBuf), packetByteBuf -> {
            TagLike tagLike = new TagLike(registry);
            tagLike.read((FriendlyByteBuf)packetByteBuf);
            return tagLike;
        }, jsonElement -> {
            TagLike tagLike = new TagLike(registry);
            if (!jsonElement.isJsonArray()) {
                throw new JsonSyntaxException("Expected a JSON array,");
            }
            JsonArray jsonArray = jsonElement.getAsJsonArray();
            jsonArray.forEach(je -> {
                String s = je.getAsString();
                if (s.startsWith("#")) {
                    ResourceLocation id = new ResourceLocation(s.substring(1));
                    tagLike.addTag(id);
                } else {
                    tagLike.add(new ResourceLocation(s));
                }
            });
            return tagLike;
        }, tagLike -> {
            JsonArray array = new JsonArray();
            tagLike.forEach(either -> either.ifLeft(tagKey -> {
                String s = "#" + tagKey.f_203868_();
                array.add(s);
            }).ifRight(t -> {
                String s = registry.m_7981_(t).toString();
                array.add(s);
            }));
            return array;
        });
    }

    private void writeWithCodec(FriendlyByteBuf buf, Codec<T> codec, T data) {
        DataResult dataResult = codec.encodeStart((DynamicOps)NbtOps.f_128958_, data);
        dataResult.error().ifPresent(partialResult -> {
            throw new EncoderException("Failed to encode: " + partialResult.message() + " " + data);
        });
        try {
            NbtIo.m_128950_((Tag)((Tag)dataResult.result().get()), (DataOutput)new ByteBufOutputStream((ByteBuf)buf));
        }
        catch (IOException ioexception) {
            throw new EncoderException("Failed to encode SerializableDataType: " + ioexception);
        }
    }

    private T readWithCodec(FriendlyByteBuf buf, Codec<T> codec) {
        Tag compoundTag = this.readAnySizeNbt(buf);
        DataResult dataResult = codec.parse((DynamicOps)NbtOps.f_128958_, (Object)compoundTag);
        dataResult.error().ifPresent(partialResult -> {
            throw new EncoderException("Failed to decode: " + partialResult.message() + " " + compoundTag);
        });
        return dataResult.result().get();
    }

    @Nullable
    private Tag readAnySizeNbt(FriendlyByteBuf buf) {
        int i = buf.readerIndex();
        byte b0 = buf.readByte();
        if (b0 == 0) {
            return null;
        }
        buf.readerIndex(i);
        try {
            return NbtIo.m_128930_((DataInput)new ByteBufInputStream((ByteBuf)buf), (int)0, (NbtAccounter)NbtAccounter.f_128917_);
        }
        catch (IOException ioexception) {
            throw new EncoderException((Throwable)ioexception);
        }
    }
}

