/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Registry
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.registries.IForgeRegistry
 */
package io.github.edwinmindcraft.origins.api.registry;

import io.github.apace100.origins.Origins;
import io.github.apace100.origins.badge.BadgeFactory;
import io.github.edwinmindcraft.origins.api.origin.Origin;
import java.util.function.Supplier;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.registries.IForgeRegistry;

public class OriginsBuiltinRegistries {
    public static final ResourceKey<Registry<BadgeFactory>> BADGE_FACTORY_KEY = ResourceKey.m_135788_((ResourceLocation)Origins.identifier("badge_factory"));
    public static Supplier<IForgeRegistry<Origin>> ORIGINS;
    public static Supplier<IForgeRegistry<BadgeFactory>> BADGE_FACTORIES;
}

