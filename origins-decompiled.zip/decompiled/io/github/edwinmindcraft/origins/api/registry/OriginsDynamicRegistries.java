/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Registry
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 */
package io.github.edwinmindcraft.origins.api.registry;

import io.github.edwinmindcraft.origins.api.origin.Origin;
import io.github.edwinmindcraft.origins.api.origin.OriginLayer;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;

public class OriginsDynamicRegistries {
    public static final ResourceKey<Registry<Origin>> ORIGINS_REGISTRY = ResourceKey.m_135788_((ResourceLocation)new ResourceLocation("origins", "origins"));
    public static final ResourceKey<Registry<OriginLayer>> LAYERS_REGISTRY = ResourceKey.m_135788_((ResourceLocation)new ResourceLocation("origins", "layers"));
}

