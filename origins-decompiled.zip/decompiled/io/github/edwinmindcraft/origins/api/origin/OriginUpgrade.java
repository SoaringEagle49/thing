/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.MapCodec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.core.Holder
 *  net.minecraft.resources.ResourceLocation
 */
package io.github.edwinmindcraft.origins.api.origin;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import io.github.edwinmindcraft.origins.api.origin.Origin;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;

public record OriginUpgrade(ResourceLocation advancement, Holder<Origin> origin, String announcement) {
    public static final MapCodec<OriginUpgrade> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group((App)ResourceLocation.f_135803_.fieldOf("condition").forGetter(OriginUpgrade::advancement), (App)Origin.HOLDER_REFERENCE.fieldOf("origin").forGetter(OriginUpgrade::origin), (App)CalioCodecHelper.optionalField((Codec)Codec.STRING, (String)"announcement", (Object)"").forGetter(OriginUpgrade::announcement)).apply((Applicative)instance, OriginUpgrade::new));
    public static final Codec<OriginUpgrade> CODEC = MAP_CODEC.codec();
}

