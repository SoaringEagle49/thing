/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  io.github.edwinmindcraft.calio.api.network.OptionalFuncs
 *  net.minecraft.network.chat.Component
 *  org.jetbrains.annotations.Nullable
 */
package io.github.edwinmindcraft.origins.api.origin;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import io.github.edwinmindcraft.calio.api.network.OptionalFuncs;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.Nullable;

public record GuiTitle(@Nullable Component view, @Nullable Component choose) {
    public static final GuiTitle DEFAULT = new GuiTitle(null, null);
    public static final Codec<GuiTitle> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)CalioCodecHelper.COMPONENT_CODEC.optionalFieldOf("view_origin").forGetter(OptionalFuncs.opt(GuiTitle::view)), (App)CalioCodecHelper.COMPONENT_CODEC.optionalFieldOf("choose_origin").forGetter(OptionalFuncs.opt(GuiTitle::choose))).apply((Applicative)instance, OptionalFuncs.of(GuiTitle::new)));
}

