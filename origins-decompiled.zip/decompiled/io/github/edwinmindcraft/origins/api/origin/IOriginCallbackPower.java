/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration
 *  io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower
 *  io.github.edwinmindcraft.apoli.api.power.factory.PowerFactory
 *  net.minecraft.world.entity.Entity
 */
package io.github.edwinmindcraft.origins.api.origin;

import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.apoli.api.power.factory.PowerFactory;
import net.minecraft.world.entity.Entity;

public interface IOriginCallbackPower<T extends IDynamicFeatureConfiguration> {
    default public <F extends PowerFactory<T>> void onChosen(ConfiguredPower<T, F> power, Entity living, boolean isOrb) {
        if (power.getFactory() instanceof IOriginCallbackPower) {
            ((IOriginCallbackPower)power.getFactory()).onChosen(power.getConfiguration(), living, isOrb);
        }
    }

    default public <F extends PowerFactory<T>> void prepare(ConfiguredPower<T, F> power, Entity living, boolean isOrb) {
        if (power.getFactory() instanceof IOriginCallbackPower) {
            ((IOriginCallbackPower)power.getFactory()).prepare(power.getConfiguration(), living, isOrb);
        }
    }

    default public <F extends PowerFactory<T>> boolean isReady(ConfiguredPower<T, F> power, Entity living, boolean isOrb) {
        if (power.getFactory() instanceof IOriginCallbackPower) {
            return ((IOriginCallbackPower)power.getFactory()).isReady(power.getConfiguration(), living, isOrb);
        }
        return false;
    }

    public void onChosen(T var1, Entity var2, boolean var3);

    default public boolean isReady(T configuration, Entity entity, boolean isOrb) {
        return true;
    }

    default public void prepare(T configuration, Entity entity, boolean isOrb) {
    }
}

