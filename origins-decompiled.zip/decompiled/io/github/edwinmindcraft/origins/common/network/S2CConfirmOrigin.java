/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.FriendlyByteBuf
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.fml.DistExecutor
 *  net.minecraftforge.network.NetworkEvent$Context
 */
package io.github.edwinmindcraft.origins.common.network;

import io.github.apace100.origins.Origins;
import io.github.edwinmindcraft.origins.api.OriginsAPI;
import io.github.edwinmindcraft.origins.api.capabilities.IOriginContainer;
import io.github.edwinmindcraft.origins.api.origin.Origin;
import io.github.edwinmindcraft.origins.api.origin.OriginLayer;
import io.github.edwinmindcraft.origins.client.OriginsClient;
import io.github.edwinmindcraft.origins.client.OriginsClientUtils;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

public record S2CConfirmOrigin(ResourceLocation layer, ResourceLocation origin) {
    public static S2CConfirmOrigin decode(FriendlyByteBuf buf) {
        return new S2CConfirmOrigin(buf.m_130281_(), buf.m_130281_());
    }

    public void encode(FriendlyByteBuf buf) {
        buf.m_130085_(this.layer());
        buf.m_130085_(this.origin());
    }

    public void handle(Supplier<NetworkEvent.Context> contextSupplier) {
        contextSupplier.get().enqueueWork(() -> {
            Player player = (Player)DistExecutor.safeCallWhenOn((Dist)Dist.CLIENT, () -> OriginsClientUtils::getClientPlayer);
            if (player == null) {
                return;
            }
            OriginLayer layer = (OriginLayer)OriginsAPI.getLayersRegistry().m_7745_(this.layer());
            Origin origin = (Origin)OriginsAPI.getOriginsRegistry().m_7745_(this.origin());
            if (layer == null || origin == null) {
                Origins.LOGGER.warn("Received invalid confirmation: {} ({}): {} ({})", (Object)this.layer(), (Object)layer, (Object)this.origin(), (Object)origin);
                return;
            }
            IOriginContainer.get((Entity)player).ifPresent(x -> x.setOrigin(layer, origin));
            DistExecutor.unsafeRunWhenOn((Dist)Dist.CLIENT, () -> () -> OriginsClient.OPEN_NEXT_LAYER.set(true));
        });
        contextSupplier.get().setPacketHandled(true);
    }
}

