/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.edwinmindcraft.apoli.api.power.factory.EntityCondition
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.world.entity.Entity
 *  org.jetbrains.annotations.NotNull
 */
package io.github.edwinmindcraft.origins.common.condition;

import io.github.edwinmindcraft.apoli.api.power.factory.EntityCondition;
import io.github.edwinmindcraft.origins.api.capabilities.IOriginContainer;
import io.github.edwinmindcraft.origins.api.origin.OriginLayer;
import io.github.edwinmindcraft.origins.common.condition.configuration.OriginConfiguration;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.Entity;
import org.jetbrains.annotations.NotNull;

public class OriginCondition
extends EntityCondition<OriginConfiguration> {
    public OriginCondition() {
        super(OriginConfiguration.CODEC);
    }

    public boolean check(@NotNull OriginConfiguration configuration, @NotNull Entity entity) {
        return IOriginContainer.get(entity).resolve().map(container -> {
            if (!configuration.origin().m_203633_()) {
                return false;
            }
            if (configuration.layer() != null && configuration.layer().m_203633_()) {
                return configuration.layer().m_203543_().isPresent() && configuration.origin().m_203565_(container.getOrigin((ResourceKey<OriginLayer>)((ResourceKey)configuration.layer().m_203543_().get())));
            }
            return container.getOrigins().values().stream().anyMatch(arg_0 -> configuration.origin().m_203565_(arg_0));
        }).orElse(false);
    }
}

