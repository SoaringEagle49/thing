/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.core.Holder
 *  org.jetbrains.annotations.Nullable
 */
package io.github.edwinmindcraft.origins.common.condition.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import io.github.edwinmindcraft.origins.api.origin.Origin;
import io.github.edwinmindcraft.origins.api.origin.OriginLayer;
import java.util.Optional;
import net.minecraft.core.Holder;
import org.jetbrains.annotations.Nullable;

public record OriginConfiguration(Holder<Origin> origin, @Nullable Holder<OriginLayer> layer) implements IDynamicFeatureConfiguration
{
    public static final Codec<OriginConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)Origin.HOLDER_REFERENCE.fieldOf("origin").forGetter(OriginConfiguration::origin), (App)CalioCodecHelper.optionalField(OriginLayer.HOLDER_REFERENCE, (String)"layer").forGetter(x -> Optional.ofNullable(x.layer()))).apply((Applicative)instance, (o, l) -> new OriginConfiguration((Holder<Origin>)o, (Holder<OriginLayer>)((Holder)l.orElse(null)))));
}

