/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.tags.TagKey
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.state.BlockState
 *  org.jetbrains.annotations.Nullable
 */
package io.github.edwinmindcraft.origins.common.power.configuration;

import com.mojang.serialization.Codec;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import java.util.Optional;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

public record NoSlowdownConfiguration(@Nullable TagKey<Block> blocks) implements IDynamicFeatureConfiguration
{
    public static final Codec<NoSlowdownConfiguration> CODEC = TagKey.m_203886_((ResourceKey)Registries.f_256747_).optionalFieldOf("tag").xmap(x -> new NoSlowdownConfiguration((TagKey<Block>)((TagKey)x.orElse(null))), x -> Optional.ofNullable(x.blocks())).codec();

    public boolean test(BlockState state) {
        return this.blocks() == null || state.m_204336_(this.blocks());
    }
}

