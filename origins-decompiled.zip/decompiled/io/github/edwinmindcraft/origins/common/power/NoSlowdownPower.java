/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.edwinmindcraft.apoli.api.component.IPowerContainer
 *  io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower
 *  io.github.edwinmindcraft.apoli.api.power.factory.PowerFactory
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.level.block.state.BlockState
 */
package io.github.edwinmindcraft.origins.common.power;

import io.github.apace100.origins.power.OriginsPowerTypes;
import io.github.edwinmindcraft.apoli.api.component.IPowerContainer;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.apoli.api.power.factory.PowerFactory;
import io.github.edwinmindcraft.origins.common.power.configuration.NoSlowdownConfiguration;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.state.BlockState;

public class NoSlowdownPower
extends PowerFactory<NoSlowdownConfiguration> {
    public static boolean isActive(Entity player, BlockState state) {
        return IPowerContainer.getPowers((Entity)player, (PowerFactory)((NoSlowdownPower)((Object)OriginsPowerTypes.NO_SLOWDOWN.get()))).stream().anyMatch(x -> ((NoSlowdownConfiguration)((ConfiguredPower)x.m_203334_()).getConfiguration()).test(state));
    }

    public NoSlowdownPower() {
        super(NoSlowdownConfiguration.CODEC);
    }
}

