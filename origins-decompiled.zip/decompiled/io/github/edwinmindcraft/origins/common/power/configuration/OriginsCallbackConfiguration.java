/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration
 *  io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredEntityAction
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.core.Holder
 */
package io.github.edwinmindcraft.origins.common.power.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredEntityAction;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import net.minecraft.core.Holder;

public record OriginsCallbackConfiguration(Holder<ConfiguredEntityAction<?, ?>> entityActionRespawned, Holder<ConfiguredEntityAction<?, ?>> entityActionRemoved, Holder<ConfiguredEntityAction<?, ?>> entityActionGained, Holder<ConfiguredEntityAction<?, ?>> entityActionLost, Holder<ConfiguredEntityAction<?, ?>> entityActionAdded, Holder<ConfiguredEntityAction<?, ?>> entityActionChosen, boolean onOrb) implements IDynamicFeatureConfiguration
{
    public static final Codec<OriginsCallbackConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)ConfiguredEntityAction.optional((String)"entity_action_respawned").forGetter(OriginsCallbackConfiguration::entityActionRespawned), (App)ConfiguredEntityAction.optional((String)"entity_action_removed").forGetter(OriginsCallbackConfiguration::entityActionRemoved), (App)ConfiguredEntityAction.optional((String)"entity_action_gained").forGetter(OriginsCallbackConfiguration::entityActionGained), (App)ConfiguredEntityAction.optional((String)"entity_action_lost").forGetter(OriginsCallbackConfiguration::entityActionLost), (App)ConfiguredEntityAction.optional((String)"entity_action_added").forGetter(OriginsCallbackConfiguration::entityActionAdded), (App)ConfiguredEntityAction.optional((String)"entity_action_chosen").forGetter(OriginsCallbackConfiguration::entityActionChosen), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.BOOL, (String)"execute_chosen_when_orb", (Object)true).forGetter(OriginsCallbackConfiguration::onOrb)).apply((Applicative)instance, OriginsCallbackConfiguration::new));
}

