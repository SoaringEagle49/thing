/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.edwinmindcraft.apoli.api.component.IPowerContainer
 *  io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower
 *  io.github.edwinmindcraft.apoli.api.power.factory.PowerFactory
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 */
package io.github.edwinmindcraft.origins.common.power;

import io.github.apace100.origins.power.OriginsPowerTypes;
import io.github.edwinmindcraft.apoli.api.component.IPowerContainer;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.apoli.api.power.factory.PowerFactory;
import io.github.edwinmindcraft.origins.common.power.configuration.WaterVisionConfiguration;
import java.util.Optional;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public class WaterVisionPower
extends PowerFactory<WaterVisionConfiguration> {
    public static Optional<Float> getWaterVisionStrength(LivingEntity living) {
        if (!OriginsPowerTypes.WATER_VISION.isPresent()) {
            return Optional.empty();
        }
        return IPowerContainer.getPowers((Entity)living, (PowerFactory)((WaterVisionPower)((Object)OriginsPowerTypes.WATER_VISION.get()))).stream().map(x -> Float.valueOf(((WaterVisionConfiguration)((ConfiguredPower)x.m_203334_()).getConfiguration()).strength())).max(Float::compareTo);
    }

    public WaterVisionPower() {
        super(WaterVisionConfiguration.CODEC);
    }
}

