/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 */
package io.github.edwinmindcraft.origins.common.power.configuration;

import com.mojang.serialization.Codec;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;

public record WaterVisionConfiguration(float strength) implements IDynamicFeatureConfiguration
{
    public static final Codec<WaterVisionConfiguration> CODEC = CalioCodecHelper.optionalField((Codec)CalioCodecHelper.FLOAT, (String)"strength", (Object)Float.valueOf(1.0f)).xmap(WaterVisionConfiguration::new, WaterVisionConfiguration::strength).codec();
}

