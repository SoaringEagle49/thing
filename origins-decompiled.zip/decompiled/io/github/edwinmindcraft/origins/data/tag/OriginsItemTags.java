/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.tags.ItemTags
 *  net.minecraft.tags.TagKey
 *  net.minecraft.world.item.Item
 */
package io.github.edwinmindcraft.origins.data.tag;

import io.github.apace100.origins.Origins;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;

public class OriginsItemTags {
    public static final TagKey<Item> MEAT = OriginsItemTags.tag("meat");
    public static final TagKey<Item> IGNORE_DIET = OriginsItemTags.tag("ignore_diet");
    public static final TagKey<Item> RANGED_WEAPONS = OriginsItemTags.tag("ranged_weapons");

    private static TagKey<Item> tag(String path) {
        return ItemTags.create((ResourceLocation)Origins.identifier(path));
    }
}

