/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.data.DataGenerator
 *  net.minecraft.data.DataProvider
 *  net.minecraftforge.common.data.ExistingFileHelper
 *  net.minecraftforge.data.event.GatherDataEvent
 *  net.minecraftforge.eventbus.api.IEventBus
 *  net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext
 */
package io.github.edwinmindcraft.origins.data;

import io.github.edwinmindcraft.origins.data.generator.OriginsBlockStateProvider;
import io.github.edwinmindcraft.origins.data.generator.OriginsBlockTagProvider;
import io.github.edwinmindcraft.origins.data.generator.OriginsItemModelProvider;
import io.github.edwinmindcraft.origins.data.generator.OriginsPowerProvider;
import java.util.concurrent.CompletableFuture;
import net.minecraft.data.DataGenerator;
import net.minecraft.data.DataProvider;
import net.minecraftforge.common.data.ExistingFileHelper;
import net.minecraftforge.data.event.GatherDataEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

public class OriginsData {
    public static void initialize() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        bus.addListener(OriginsData::gatherData);
    }

    private static void gatherData(GatherDataEvent event) {
        DataGenerator generator = event.getGenerator();
        CompletableFuture lookupProvider = event.getLookupProvider();
        ExistingFileHelper existingFileHelper = event.getExistingFileHelper();
        generator.addProvider(event.includeClient(), (DataProvider)new OriginsBlockStateProvider(generator, existingFileHelper));
        generator.addProvider(event.includeClient(), (DataProvider)new OriginsItemModelProvider(generator, existingFileHelper));
        generator.addProvider(event.includeServer(), (DataProvider)new OriginsBlockTagProvider(generator, lookupProvider, existingFileHelper));
        generator.addProvider(event.includeServer(), (DataProvider)new OriginsPowerProvider(generator, existingFileHelper));
    }
}

