/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.data.DataGenerator
 *  net.minecraft.world.level.block.Block
 *  net.minecraftforge.client.model.generators.BlockModelBuilder
 *  net.minecraftforge.client.model.generators.BlockStateProvider
 *  net.minecraftforge.client.model.generators.ModelFile
 *  net.minecraftforge.common.data.ExistingFileHelper
 */
package io.github.edwinmindcraft.origins.data.generator;

import io.github.apace100.origins.registry.ModBlocks;
import net.minecraft.data.DataGenerator;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.client.model.generators.BlockModelBuilder;
import net.minecraftforge.client.model.generators.BlockStateProvider;
import net.minecraftforge.client.model.generators.ModelFile;
import net.minecraftforge.common.data.ExistingFileHelper;

public class OriginsBlockStateProvider
extends BlockStateProvider {
    public OriginsBlockStateProvider(DataGenerator gen, ExistingFileHelper exFileHelper) {
        super(gen.getPackOutput(), "origins", exFileHelper);
    }

    protected void registerStatesAndModels() {
        BlockModelBuilder builder = (BlockModelBuilder)((BlockModelBuilder)this.models().withExistingParent("temporary_cobweb", "cobweb")).renderType("cutout");
        this.simpleBlock((Block)ModBlocks.TEMPORARY_COBWEB.get(), (ModelFile)builder);
    }
}

