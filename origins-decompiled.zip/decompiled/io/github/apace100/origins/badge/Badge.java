/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.apace100.calio.data.SerializableData$Instance
 *  io.github.apace100.calio.registry.DataObject
 *  io.github.apace100.calio.registry.DataObjectFactory
 *  io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower
 *  net.minecraft.client.gui.Font
 *  net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent
 *  net.minecraft.network.FriendlyByteBuf
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package io.github.apace100.origins.badge;

import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.registry.DataObject;
import io.github.apace100.calio.registry.DataObjectFactory;
import io.github.apace100.origins.badge.BadgeFactory;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import java.util.List;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public interface Badge
extends DataObject<Badge> {
    public ResourceLocation spriteId();

    public boolean hasTooltip();

    @OnlyIn(value=Dist.CLIENT)
    public List<ClientTooltipComponent> getTooltipComponents(ConfiguredPower<?, ?> var1, int var2, float var3, Font var4);

    public SerializableData.Instance toData(SerializableData.Instance var1);

    public BadgeFactory getBadgeFactory();

    default public DataObjectFactory<Badge> getFactory() {
        return this.getBadgeFactory();
    }

    default public void writeBuf(FriendlyByteBuf buf) {
        DataObjectFactory<Badge> factory = this.getFactory();
        buf.m_130085_(this.getBadgeFactory().id());
        factory.getData().write(buf, factory.toData((Object)this));
    }
}

