/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.apace100.calio.data.SerializableDataType
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.ItemLike
 */
package io.github.apace100.origins.data;

import io.github.apace100.calio.data.SerializableDataType;
import io.github.apace100.calio.data.SerializableDataTypes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;

public final class CompatibilityDataTypes {
    public static final SerializableDataType<ItemStack> ITEM_OR_ITEM_STACK = new SerializableDataType(ItemStack.class, (arg_0, arg_1) -> ((SerializableDataType)SerializableDataTypes.ITEM_STACK).send(arg_0, arg_1), arg_0 -> ((SerializableDataType)SerializableDataTypes.ITEM_STACK).receive(arg_0), jsonElement -> {
        if (jsonElement.isJsonPrimitive() && jsonElement.getAsJsonPrimitive().isString()) {
            Item item = (Item)SerializableDataTypes.ITEM.read(jsonElement);
            return new ItemStack((ItemLike)item);
        }
        return (ItemStack)SerializableDataTypes.ITEM_STACK.read(jsonElement);
    });
}

