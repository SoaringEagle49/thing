/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.item.BlockItem
 *  net.minecraft.world.item.Item$Properties
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.state.BlockBehaviour$Properties
 *  net.minecraft.world.level.material.MapColor
 *  net.minecraftforge.registries.RegistryObject
 */
package io.github.apace100.origins.registry;

import io.github.apace100.origins.content.TemporaryCobwebBlock;
import io.github.edwinmindcraft.origins.common.registry.OriginRegisters;
import java.util.function.Supplier;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final RegistryObject<TemporaryCobwebBlock> TEMPORARY_COBWEB = ModBlocks.register("temporary_cobweb", () -> new TemporaryCobwebBlock(BlockBehaviour.Properties.m_284310_().m_284180_(MapColor.f_283930_).m_280606_().m_60910_().m_60999_().m_60978_(4.0f)), false);

    public static void register() {
    }

    private static <T extends Block> RegistryObject<T> register(String blockName, Supplier<T> block) {
        return ModBlocks.register(blockName, block, true);
    }

    private static <T extends Block> RegistryObject<T> register(String blockName, Supplier<T> block, boolean withBlockItem) {
        RegistryObject register = OriginRegisters.BLOCKS.register(blockName, block);
        if (withBlockItem) {
            OriginRegisters.ITEMS.register(blockName, () -> new BlockItem((Block)register.get(), new Item.Properties()));
        }
        return register;
    }
}

