/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.EntityType$Builder
 *  net.minecraft.world.entity.MobCategory
 *  net.minecraftforge.registries.RegistryObject
 */
package io.github.apace100.origins.registry;

import io.github.apace100.origins.entity.EnderianPearlEntity;
import io.github.edwinmindcraft.origins.common.registry.OriginRegisters;
import java.util.function.Supplier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final RegistryObject<EntityType<EnderianPearlEntity>> ENDERIAN_PEARL = ModEntities.register("enderian_pearl", () -> EntityType.Builder.m_20704_(EnderianPearlEntity::new, (MobCategory)MobCategory.MISC).m_20699_(0.25f, 0.25f).m_20699_(0.25f, 0.25f).m_20702_(4).m_20717_(10));

    private static <T extends Entity> RegistryObject<EntityType<T>> register(String name, Supplier<EntityType.Builder<T>> builder) {
        return OriginRegisters.ENTITY_TYPES.register(name, () -> ((EntityType.Builder)builder.get()).m_20712_("origins:" + name));
    }

    public static void register() {
    }
}

