/*
 * Decompiled with CFR 0.152.
 */
package io.github.apace100.origins.component;

import io.github.apace100.origins.component.OriginComponent;
import io.github.apace100.origins.origin.Origin;
import io.github.apace100.origins.origin.OriginLayer;
import io.github.apace100.origins.origin.OriginLayers;
import io.github.apace100.origins.origin.OriginRegistry;
import io.github.edwinmindcraft.origins.api.capabilities.IOriginContainer;
import java.util.HashMap;

@Deprecated
public class PlayerOriginComponent
implements OriginComponent {
    private final IOriginContainer wrapped;
    private final HashMap<OriginLayer, Origin> origins = new HashMap();

    public PlayerOriginComponent(IOriginContainer wrapped) {
        this.wrapped = wrapped;
    }

    @Override
    @Deprecated
    public boolean hasAllOrigins() {
        return this.wrapped.hasAllOrigins();
    }

    @Override
    @Deprecated
    public HashMap<OriginLayer, Origin> getOrigins() {
        this.origins.clear();
        this.wrapped.getOrigins().forEach((x, y) -> this.origins.put(OriginLayers.getLayer(x.m_135782_()), OriginRegistry.get(y.m_135782_())));
        return this.origins;
    }

    @Override
    @Deprecated
    public boolean hasOrigin(OriginLayer layer) {
        return this.wrapped.hasOrigin(layer.getWrapped());
    }

    @Override
    @Deprecated
    public Origin getOrigin(OriginLayer layer) {
        return OriginRegistry.get(this.wrapped.getOrigin(layer.getWrapped()).m_135782_());
    }

    @Override
    @Deprecated
    public boolean hadOriginBefore() {
        return this.wrapped.hasAllOrigins();
    }

    @Override
    @Deprecated
    public void setOrigin(OriginLayer layer, Origin origin) {
        this.wrapped.setOrigin(layer.getWrapped(), origin.getWrapped());
    }

    @Override
    @Deprecated
    public void sync() {
        OriginComponent.sync(this.wrapped.getOwner());
    }
}

