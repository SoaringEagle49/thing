/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 */
package io.github.apace100.origins.component;

import io.github.apace100.origins.origin.Origin;
import io.github.apace100.origins.origin.OriginLayer;
import io.github.edwinmindcraft.origins.api.OriginsAPI;
import io.github.edwinmindcraft.origins.api.capabilities.IOriginContainer;
import java.util.HashMap;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

@Deprecated
public interface OriginComponent {
    @Deprecated
    public boolean hasOrigin(OriginLayer var1);

    @Deprecated
    public boolean hasAllOrigins();

    @Deprecated
    public HashMap<OriginLayer, Origin> getOrigins();

    @Deprecated
    public Origin getOrigin(OriginLayer var1);

    @Deprecated
    public boolean hadOriginBefore();

    @Deprecated
    public void setOrigin(OriginLayer var1, Origin var2);

    @Deprecated
    public void sync();

    @Deprecated(forRemoval=true)
    default public void onPowersRead() {
    }

    @Deprecated
    public static void sync(Player player) {
        IOriginContainer.get((Entity)player).ifPresent(IOriginContainer::synchronize);
    }

    @Deprecated
    public static void onChosen(Player player, boolean hadOriginBefore) {
        IOriginContainer.get((Entity)player).ifPresent(x -> x.onChosen(hadOriginBefore));
    }

    @Deprecated
    public static void partialOnChosen(Player player, boolean hadOriginBefore, Origin origin) {
        IOriginContainer.get((Entity)player).ifPresent(x -> x.onChosen((ResourceKey<io.github.edwinmindcraft.origins.api.origin.Origin>)((ResourceKey)OriginsAPI.getOriginsRegistry().m_7854_((Object)origin.getWrapped()).orElseThrow()), hadOriginBefore));
    }

    @Deprecated
    default public boolean checkAutoChoosingLayers(Player player, boolean includeDefaults) {
        return IOriginContainer.get((Entity)player).map(x -> x.checkAutoChoosingLayers(includeDefaults)).orElse(false);
    }
}

