/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.apace100.apoli.power.PowerTypeRegistry
 *  io.github.edwinmindcraft.apoli.api.ApoliAPI
 *  io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower
 *  net.minecraft.core.MappedRegistry
 *  net.minecraft.core.Registry
 *  net.minecraft.resources.ResourceLocation
 */
package io.github.apace100.origins.util;

import io.github.apace100.apoli.power.PowerTypeRegistry;
import io.github.edwinmindcraft.apoli.api.ApoliAPI;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import java.util.HashMap;
import java.util.Optional;
import net.minecraft.core.MappedRegistry;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;

public class PowerKeyManager {
    private static final HashMap<ResourceLocation, String> KEY_CACHE = new HashMap();

    public static void clearCache() {
        KEY_CACHE.clear();
    }

    public static String getKeyIdentifier(ResourceLocation powerId) {
        if (KEY_CACHE.containsKey(powerId)) {
            return KEY_CACHE.get(powerId);
        }
        String key = PowerKeyManager.getKeyFromPower(powerId);
        KEY_CACHE.put(powerId, key);
        return key;
    }

    private static String getKeyFromPower(ResourceLocation powerId) {
        if (PowerTypeRegistry.contains((ResourceLocation)powerId)) {
            MappedRegistry powers = ApoliAPI.getPowers();
            ConfiguredPower powerType = (ConfiguredPower)powers.m_7745_(powerId);
            if (powerType == null) {
                return "";
            }
            return powerType.getKey(null).map(key -> key.key().equals("none") ? "key.origins.primary_active" : key.key()).or(() -> PowerKeyManager.lambda$getKeyFromPower$3(powerType, (Registry)powers)).orElse("");
        }
        return "";
    }

    private static /* synthetic */ Optional lambda$getKeyFromPower$3(ConfiguredPower powerType, Registry powers) {
        return powerType.getContainedPowerKeys().stream().filter(arg_0 -> ((Registry)powers).m_142003_(arg_0)).map(x -> PowerKeyManager.getKeyFromPower(x.m_135782_())).filter(x -> !x.isBlank()).findFirst();
    }
}

