/*
 * Decompiled with CFR 0.152.
 */
package io.github.apace100.origins.util;

public class Constants {
    public static final int[] LIGHT_ARMOR_MAX_PROTECTION = new int[]{1, 4, 5, 2};
}

