/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.inventory.MenuType
 */
package io.github.apace100.origins.util;

import net.minecraft.world.inventory.MenuType;

public enum InventoryType {
    THREE_BY_THREE(MenuType.f_39963_),
    NINE_BY_ONE(MenuType.f_39957_),
    NINE_BY_TWO(MenuType.f_39958_),
    NINE_BY_THREE(MenuType.f_39959_),
    NINE_BY_FOUR(MenuType.f_39960_),
    NINE_BY_FIVE(MenuType.f_39961_),
    NINE_BY_SIX(MenuType.f_39962_);

    private final MenuType<?> type;

    private InventoryType(MenuType<?> type) {
        this.type = type;
    }

    public MenuType<?> getType() {
        return this.type;
    }
}

