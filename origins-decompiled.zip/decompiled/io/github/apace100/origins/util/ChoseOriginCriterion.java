/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonPrimitive
 *  net.minecraft.advancements.critereon.AbstractCriterionTriggerInstance
 *  net.minecraft.advancements.critereon.ContextAwarePredicate
 *  net.minecraft.advancements.critereon.DeserializationContext
 *  net.minecraft.advancements.critereon.SerializationContext
 *  net.minecraft.advancements.critereon.SimpleCriterionTrigger
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.util.GsonHelper
 *  org.jetbrains.annotations.NotNull
 */
package io.github.apace100.origins.util;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import io.github.edwinmindcraft.origins.api.origin.Origin;
import java.util.Objects;
import net.minecraft.advancements.critereon.AbstractCriterionTriggerInstance;
import net.minecraft.advancements.critereon.ContextAwarePredicate;
import net.minecraft.advancements.critereon.DeserializationContext;
import net.minecraft.advancements.critereon.SerializationContext;
import net.minecraft.advancements.critereon.SimpleCriterionTrigger;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.GsonHelper;
import org.jetbrains.annotations.NotNull;

public class ChoseOriginCriterion
extends SimpleCriterionTrigger<Conditions> {
    public static final ChoseOriginCriterion INSTANCE = new ChoseOriginCriterion();
    private static final ResourceLocation ID = new ResourceLocation("origins", "chose_origin");

    @NotNull
    protected Conditions createInstance(@NotNull JsonObject obj, @NotNull ContextAwarePredicate playerPredicate, @NotNull DeserializationContext predicateDeserializer) {
        ResourceLocation id = ResourceLocation.m_135820_((String)GsonHelper.m_13906_((JsonObject)obj, (String)"origin"));
        return new Conditions(playerPredicate, id);
    }

    public void trigger(ServerPlayer player, ResourceKey<Origin> origin) {
        this.m_66234_(player, conditions -> conditions.matches(origin));
    }

    @NotNull
    public ResourceLocation m_7295_() {
        return ID;
    }

    public static class Conditions
    extends AbstractCriterionTriggerInstance {
        private final ResourceLocation originId;

        public Conditions(ContextAwarePredicate player, ResourceLocation originId) {
            super(ID, player);
            this.originId = originId;
        }

        public boolean matches(ResourceKey<Origin> origin) {
            return Objects.equals(origin.m_135782_(), this.originId);
        }

        @NotNull
        public JsonObject m_7683_(@NotNull SerializationContext predicateSerializer) {
            JsonObject jsonObject = super.m_7683_(predicateSerializer);
            jsonObject.add("origin", (JsonElement)new JsonPrimitive(this.originId.toString()));
            return jsonObject;
        }
    }
}

