/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.edwinmindcraft.apoli.api.component.IPowerContainer
 *  io.github.edwinmindcraft.apoli.api.power.factory.PowerFactory
 *  io.github.edwinmindcraft.apoli.common.power.DummyPower
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.phys.Vec3
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Redirect
 */
package io.github.apace100.origins.mixin;

import io.github.apace100.origins.power.OriginsPowerTypes;
import io.github.edwinmindcraft.apoli.api.component.IPowerContainer;
import io.github.edwinmindcraft.apoli.api.power.factory.PowerFactory;
import io.github.edwinmindcraft.apoli.common.power.DummyPower;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value={LivingEntity.class})
public abstract class LikeWaterMixin
extends Entity {
    public LikeWaterMixin(EntityType<?> type, Level world) {
        super(type, world);
    }

    @Redirect(method={"travel"}, at=@At(value="INVOKE", target="Lnet/minecraft/world/entity/LivingEntity;getFluidFallingAdjustedMovement(DZLnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3;"))
    public Vec3 method_26317Proxy(LivingEntity entity, double d, boolean bl, Vec3 vec3d) {
        Vec3 oldReturn = entity.m_20994_(d, bl, vec3d);
        if (IPowerContainer.hasPower((Entity)entity, (PowerFactory)((DummyPower)OriginsPowerTypes.LIKE_WATER.get())) && Math.abs(vec3d.f_82480_ - d / 16.0) < 0.025) {
            return new Vec3(oldReturn.f_82479_, 0.0, oldReturn.f_82481_);
        }
        return entity.m_20994_(d, bl, vec3d);
    }
}

