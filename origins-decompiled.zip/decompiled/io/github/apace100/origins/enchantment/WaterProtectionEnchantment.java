/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.EquipmentSlot
 *  net.minecraft.world.item.enchantment.Enchantment
 *  net.minecraft.world.item.enchantment.Enchantment$Rarity
 *  net.minecraft.world.item.enchantment.EnchantmentCategory
 *  net.minecraft.world.item.enchantment.ProtectionEnchantment
 *  net.minecraft.world.item.enchantment.ProtectionEnchantment$Type
 *  org.jetbrains.annotations.NotNull
 */
package io.github.apace100.origins.enchantment;

import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.item.enchantment.ProtectionEnchantment;
import org.jetbrains.annotations.NotNull;

public class WaterProtectionEnchantment
extends Enchantment {
    public WaterProtectionEnchantment(Enchantment.Rarity weight, EnchantmentCategory type, EquipmentSlot[] slotTypes) {
        super(weight, type, slotTypes);
    }

    public int m_6183_(int level) {
        return 8 + level * 5;
    }

    public int m_6175_(int level) {
        return this.m_6183_(level) + 8;
    }

    public boolean m_6591_() {
        return true;
    }

    public int m_6586_() {
        return 4;
    }

    protected boolean m_5975_(@NotNull Enchantment other) {
        if (other == this || other instanceof ProtectionEnchantment && ((ProtectionEnchantment)other).f_45124_ != ProtectionEnchantment.Type.FALL) {
            return false;
        }
        return super.m_5975_(other);
    }
}

