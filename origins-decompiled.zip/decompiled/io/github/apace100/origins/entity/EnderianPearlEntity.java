/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.particles.ParticleOptions
 *  net.minecraft.core.particles.ParticleTypes
 *  net.minecraft.network.protocol.Packet
 *  net.minecraft.network.protocol.game.ClientGamePacketListener
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityType
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.projectile.ThrownEnderpearl
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.Items
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.gameevent.GameEvent
 *  net.minecraft.world.phys.BlockHitResult
 *  net.minecraft.world.phys.EntityHitResult
 *  net.minecraft.world.phys.HitResult
 *  net.minecraft.world.phys.HitResult$Type
 *  net.minecraftforge.event.ForgeEventFactory
 *  net.minecraftforge.event.entity.EntityTeleportEvent$EnderPearl
 *  net.minecraftforge.network.NetworkHooks
 *  org.jetbrains.annotations.NotNull
 */
package io.github.apace100.origins.entity;

import io.github.apace100.origins.registry.ModEntities;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrownEnderpearl;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.event.ForgeEventFactory;
import net.minecraftforge.event.entity.EntityTeleportEvent;
import net.minecraftforge.network.NetworkHooks;
import org.jetbrains.annotations.NotNull;

public class EnderianPearlEntity
extends ThrownEnderpearl {
    public EnderianPearlEntity(EntityType<? extends EnderianPearlEntity> entityType, Level world) {
        super(entityType, world);
    }

    public EnderianPearlEntity(EntityType<? extends EnderianPearlEntity> entityType, LivingEntity owner, Level world) {
        super(entityType, world);
        this.m_6034_(owner.m_20185_(), owner.m_20188_() - 0.1, owner.m_20189_());
        this.m_5602_((Entity)owner);
    }

    public EnderianPearlEntity(Level world, LivingEntity owner) {
        this((EntityType<? extends EnderianPearlEntity>)((EntityType)ModEntities.ENDERIAN_PEARL.get()), owner, world);
    }

    protected void m_5790_(@NotNull EntityHitResult entityHitResult) {
    }

    @NotNull
    protected Item m_7881_() {
        return Items.f_42584_;
    }

    protected void m_6532_(HitResult result) {
        HitResult.Type type = result.m_6662_();
        if (type == HitResult.Type.ENTITY) {
            this.m_5790_((EntityHitResult)result);
        } else if (type == HitResult.Type.BLOCK) {
            this.m_8060_((BlockHitResult)result);
        }
        if (type != HitResult.Type.MISS) {
            this.m_146852_(GameEvent.f_157777_, this.m_19749_());
        }
        for (int i = 0; i < 32; ++i) {
            this.m_9236_().m_7106_((ParticleOptions)ParticleTypes.f_123760_, this.m_20185_(), this.m_20186_() + this.f_19796_.m_188500_() * 2.0, this.m_20189_(), this.f_19796_.m_188583_(), 0.0, this.f_19796_.m_188583_());
        }
        if (!this.m_9236_().f_46443_ && !this.m_213877_()) {
            Entity entity = this.m_19749_();
            if (entity instanceof ServerPlayer) {
                EntityTeleportEvent.EnderPearl event;
                ServerPlayer serverplayer = (ServerPlayer)entity;
                if (serverplayer.f_8906_.m_6198_() && serverplayer.m_9236_() == this.m_9236_() && !serverplayer.m_5803_() && !(event = ForgeEventFactory.onEnderPearlLand((ServerPlayer)serverplayer, (double)this.m_20185_(), (double)this.m_20186_(), (double)this.m_20189_(), (ThrownEnderpearl)this, (float)0.0f, (HitResult)result)).isCanceled()) {
                    if (entity.m_20159_()) {
                        serverplayer.m_142098_(this.m_20185_(), this.m_20186_(), this.m_20189_());
                    } else {
                        entity.m_6021_(this.m_20185_(), this.m_20186_(), this.m_20189_());
                    }
                    entity.m_6021_(event.getTargetX(), event.getTargetY(), event.getTargetZ());
                    entity.f_19789_ = 0.0f;
                    if (event.getAttackDamage() > 0.0f) {
                        entity.m_6469_(entity.m_269291_().m_268989_(), event.getAttackDamage());
                    }
                }
            } else if (entity != null) {
                entity.m_6021_(this.m_20185_(), this.m_20186_(), this.m_20189_());
                entity.f_19789_ = 0.0f;
            }
            this.m_146870_();
        }
    }

    @NotNull
    public Packet<ClientGamePacketListener> m_5654_() {
        return NetworkHooks.getEntitySpawningPacket((Entity)this);
    }
}

