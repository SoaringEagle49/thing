/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.GuiGraphics
 *  net.minecraft.client.gui.screens.Screen
 *  net.minecraft.client.player.LocalPlayer
 *  net.minecraft.core.Holder
 *  net.minecraft.network.chat.Component
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraftforge.common.util.LazyOptional
 *  org.jetbrains.annotations.NotNull
 */
package io.github.apace100.origins.screen;

import com.google.common.collect.ImmutableList;
import io.github.apace100.origins.screen.ChooseOriginScreen;
import io.github.edwinmindcraft.origins.api.capabilities.IOriginContainer;
import io.github.edwinmindcraft.origins.api.origin.OriginLayer;
import java.util.List;
import java.util.Objects;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.util.LazyOptional;
import org.jetbrains.annotations.NotNull;

public class WaitForNextLayerScreen
extends Screen {
    private final List<Holder<OriginLayer>> layerList;
    private final int currentLayerIndex;
    private final boolean showDirtBackground;
    private final int maxSelection;

    protected WaitForNextLayerScreen(List<Holder<OriginLayer>> layerList, int currentLayerIndex, boolean showDirtBackground) {
        super((Component)Component.m_237119_());
        this.layerList = ImmutableList.copyOf(layerList);
        this.currentLayerIndex = currentLayerIndex;
        this.showDirtBackground = showDirtBackground;
        LocalPlayer player = Minecraft.m_91087_().f_91074_;
        Holder<OriginLayer> currentLayer = layerList.get(currentLayerIndex);
        this.maxSelection = ((OriginLayer)currentLayer.m_203334_()).getOriginOptionCount((Player)Objects.requireNonNull(player));
    }

    public void openSelection() {
        LocalPlayer player = Minecraft.m_91087_().f_91074_;
        LazyOptional<IOriginContainer> iOriginContainerLazyOptional = IOriginContainer.get((Entity)player);
        if (!iOriginContainerLazyOptional.isPresent()) {
            Minecraft.m_91087_().m_91152_(null);
            return;
        }
        IOriginContainer component = (IOriginContainer)iOriginContainerLazyOptional.orElseThrow(RuntimeException::new);
        for (int index = this.currentLayerIndex + 1; index < this.layerList.size(); ++index) {
            if (component.hasOrigin(this.layerList.get(index)) || ((OriginLayer)this.layerList.get(index).m_203334_()).origins((Player)Objects.requireNonNull(player)).size() <= 0) continue;
            Minecraft.m_91087_().m_91152_((Screen)new ChooseOriginScreen(this.layerList, index, this.showDirtBackground));
            return;
        }
        Minecraft.m_91087_().m_91152_(null);
    }

    public void m_88315_(@NotNull GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        if (this.maxSelection == 0) {
            this.openSelection();
            return;
        }
        this.m_280273_(graphics);
    }

    public void m_280273_(@NotNull GuiGraphics graphics) {
        if (this.showDirtBackground) {
            super.m_280039_(graphics);
        } else {
            super.m_280273_(graphics);
        }
    }
}

