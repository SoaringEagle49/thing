/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.gui.Font
 *  net.minecraft.client.gui.GuiGraphics
 *  net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent
 *  net.minecraft.core.NonNullList
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.item.ItemStack
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  org.jetbrains.annotations.NotNull
 */
package io.github.apace100.origins.screen.tooltip;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.apace100.origins.Origins;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.core.NonNullList;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jetbrains.annotations.NotNull;

@OnlyIn(value=Dist.CLIENT)
public class CraftingRecipeTooltipComponent
implements ClientTooltipComponent {
    private final NonNullList<ItemStack> inputs;
    private final ItemStack output;
    private static final ResourceLocation TEXTURE = Origins.identifier("textures/gui/tooltip/recipe_tooltip.png");

    public CraftingRecipeTooltipComponent(NonNullList<ItemStack> inputs, ItemStack output) {
        this.inputs = inputs;
        this.output = output;
    }

    public int m_142103_() {
        return 68;
    }

    public int m_142069_(@NotNull Font pFont) {
        return 130;
    }

    public void m_183452_(@NotNull Font pFont, int pMouseX, int pMouseY, @NotNull GuiGraphics pGuiGraphics) {
        this.drawBackGround(pGuiGraphics, pMouseX, pMouseY);
        for (int column = 0; column < 3; ++column) {
            for (int row = 0; row < 3; ++row) {
                int index = column + row * 3;
                int slotX = pMouseX + 8 + column * 18;
                int slotY = pMouseY + 8 + row * 18;
                ItemStack stack = (ItemStack)this.inputs.get(index);
                pGuiGraphics.m_280256_(stack, slotX, slotY, index);
                pGuiGraphics.m_280370_(pFont, stack, slotX, slotY);
            }
        }
        pGuiGraphics.m_280256_(this.output, pMouseX + 101, pMouseY + 25, 10);
        pGuiGraphics.m_280370_(pFont, this.output, pMouseX + 101, pMouseY + 25);
    }

    public void drawBackGround(GuiGraphics graphics, int x, int y) {
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        graphics.m_280163_(TEXTURE, x, y, 0.0f, 0.0f, 130, 86, 256, 256);
    }
}

