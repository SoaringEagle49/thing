/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableMap
 *  com.google.common.collect.Lists
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.GuiGraphics
 *  net.minecraft.client.gui.components.Button
 *  net.minecraft.client.gui.components.events.GuiEventListener
 *  net.minecraft.client.gui.screens.Screen
 *  net.minecraft.core.Holder
 *  net.minecraft.core.Holder$Reference
 *  net.minecraft.core.MappedRegistry
 *  net.minecraft.network.chat.Component
 *  net.minecraft.util.Tuple
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.Items
 *  org.jetbrains.annotations.NotNull
 */
package io.github.apace100.origins.screen;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import io.github.apace100.origins.screen.ChooseOriginScreen;
import io.github.apace100.origins.screen.OriginDisplayScreen;
import io.github.edwinmindcraft.origins.api.OriginsAPI;
import io.github.edwinmindcraft.origins.api.capabilities.IOriginContainer;
import io.github.edwinmindcraft.origins.api.origin.Origin;
import io.github.edwinmindcraft.origins.api.origin.OriginLayer;
import io.github.edwinmindcraft.origins.common.registry.OriginRegisters;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.Holder;
import net.minecraft.core.MappedRegistry;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Tuple;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.jetbrains.annotations.NotNull;

public class ViewOriginScreen
extends OriginDisplayScreen {
    private final ArrayList<Tuple<Holder<OriginLayer>, Holder<Origin>>> originLayers;
    private int currentLayer = 0;
    private Button chooseOriginButton;

    public ViewOriginScreen() {
        super((Component)Component.m_237115_((String)"origins.screen.view_origin"), false);
        Player player = (Player)Objects.requireNonNull(Minecraft.m_91087_().f_91074_);
        Map origins = IOriginContainer.get((Entity)player).map(IOriginContainer::getOrigins).orElseGet(ImmutableMap::of);
        this.originLayers = new ArrayList(origins.size());
        MappedRegistry<Origin> originsRegistry = OriginsAPI.getOriginsRegistry();
        MappedRegistry<OriginLayer> layersRegistry = OriginsAPI.getLayersRegistry();
        origins.forEach((layer, origin) -> {
            Optional origin1 = originsRegistry.m_203636_(origin);
            Optional layer1 = layersRegistry.m_203636_(layer);
            if (origin1.isEmpty() || !((Holder.Reference)origin1.get()).m_203633_()) {
                return;
            }
            if (layer1.isEmpty() || !((Holder.Reference)layer1.get()).m_203633_()) {
                return;
            }
            ItemStack displayItem = ((Origin)((Holder.Reference)origin1.get()).m_203334_()).getIcon();
            if (!(displayItem.m_41720_() != Items.f_42680_ || displayItem.m_41782_() && Objects.requireNonNull(displayItem.m_41783_()).m_128441_("SkullOwner"))) {
                displayItem.m_41784_().m_128359_("SkullOwner", player.m_5446_().getString());
            }
            if (!(((Holder.Reference)origin1.get()).m_203373_(OriginRegisters.EMPTY.getId()) && ((OriginLayer)((Holder.Reference)layer1.get()).m_203334_()).getOriginOptionCount(player) <= 0 || ((OriginLayer)((Holder.Reference)layer1.get()).m_203334_()).hidden())) {
                this.originLayers.add((Tuple<Holder<OriginLayer>, Holder<Origin>>)new Tuple((Object)((Holder)layer1.get()), (Object)((Holder)origin1.get())));
            }
        });
        this.originLayers.sort(Comparator.comparing(x -> (OriginLayer)((Holder)x.m_14418_()).m_203334_()));
        if (this.originLayers.size() > 0) {
            Tuple<Holder<OriginLayer>, Holder<Origin>> current = this.originLayers.get(this.currentLayer);
            this.showOrigin((Holder<Origin>)((Holder)current.m_14419_()), (Holder<OriginLayer>)((Holder)current.m_14418_()), false);
        } else {
            this.showNone();
        }
    }

    public boolean m_6913_() {
        return true;
    }

    @Override
    protected void m_7856_() {
        super.m_7856_();
        this.guiLeft = (this.f_96543_ - 176) / 2;
        this.guiTop = (this.f_96544_ - 182) / 2;
        if (this.originLayers.size() > 0) {
            this.chooseOriginButton = Button.m_253074_((Component)Component.m_237115_((String)"origins.gui.choose"), b -> Minecraft.m_91087_().m_91152_((Screen)new ChooseOriginScreen(Lists.newArrayList((Object[])new Holder[]{(Holder)this.originLayers.get(this.currentLayer).m_14418_()}), 0, false))).m_252987_(this.guiLeft + 88 - 50, this.guiTop + 182 - 40, 100, 20).m_253136_();
            this.m_142416_((GuiEventListener)this.chooseOriginButton);
            Player player = (Player)Objects.requireNonNull(Minecraft.m_91087_().f_91074_);
            this.chooseOriginButton.f_93624_ = ((Holder)this.originLayers.get(this.currentLayer).m_14419_()).m_203373_(OriginRegisters.EMPTY.getId()) && ((OriginLayer)((Holder)this.originLayers.get(this.currentLayer).m_14418_()).m_203334_()).getOriginOptionCount(player) > 0;
            this.chooseOriginButton.f_93623_ = this.chooseOriginButton.f_93624_;
            if (this.originLayers.size() > 1) {
                this.m_142416_((GuiEventListener)Button.m_253074_((Component)Component.m_237113_((String)"<"), b -> {
                    this.currentLayer = (this.currentLayer - 1 + this.originLayers.size()) % this.originLayers.size();
                    this.switchLayer(player);
                }).m_252987_(this.guiLeft - 40, this.f_96544_ / 2 - 10, 20, 20).m_253136_());
                this.m_142416_((GuiEventListener)Button.m_253074_((Component)Component.m_237113_((String)">"), b -> {
                    this.currentLayer = (this.currentLayer + 1) % this.originLayers.size();
                    this.switchLayer(player);
                }).m_252987_(this.guiLeft + 176 + 20, this.f_96544_ / 2 - 10, 20, 20).m_253136_());
            }
        }
        this.m_142416_((GuiEventListener)Button.m_253074_((Component)Component.m_237115_((String)"origins.gui.close"), b -> Minecraft.m_91087_().m_91152_(null)).m_252987_(this.guiLeft + 88 - 50, this.guiTop + 182 + 5, 100, 20).m_253136_());
    }

    private void switchLayer(Player player) {
        Tuple<Holder<OriginLayer>, Holder<Origin>> current = this.originLayers.get(this.currentLayer);
        this.showOrigin((Holder<Origin>)((Holder)current.m_14419_()), (Holder<OriginLayer>)((Holder)current.m_14418_()), false);
        this.chooseOriginButton.f_93624_ = ((Holder)current.m_14419_()).m_203373_(OriginRegisters.EMPTY.getId()) && ((OriginLayer)((Holder)current.m_14418_()).m_203334_()).getOriginOptionCount(player) > 0;
        this.chooseOriginButton.f_93623_ = this.chooseOriginButton.f_93624_;
    }

    @Override
    public void m_88315_(@NotNull GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        super.m_88315_(graphics, mouseX, mouseY, delta);
        if (this.originLayers.size() == 0) {
            graphics.m_280137_(this.f_96547_, Component.m_237115_((String)"origins.gui.view_origin.empty").getString(), this.f_96543_ / 2, this.guiTop + 48, 0xFFFFFF);
        }
    }

    @Override
    protected Component getTitleText() {
        Component titleText = ((OriginLayer)this.getCurrentLayer().get()).title().view();
        if (titleText != null) {
            return titleText;
        }
        return Component.m_237110_((String)"origins.gui.view_origin.title", (Object[])new Object[]{((OriginLayer)this.getCurrentLayer().get()).name()});
    }
}

