/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 */
package io.github.apace100.origins.origin;

import io.github.apace100.origins.origin.Origin;
import io.github.edwinmindcraft.origins.api.OriginsAPI;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;

@Deprecated
public class OriginRegistry {
    private static final Map<io.github.edwinmindcraft.origins.api.origin.Origin, Origin> CACHE_MAP = new ConcurrentHashMap<io.github.edwinmindcraft.origins.api.origin.Origin, Origin>();

    @Deprecated
    public static Origin register(Origin origin) {
        return OriginRegistry.register(origin.getIdentifier(), origin);
    }

    @Deprecated
    public static Origin register(ResourceLocation id, Origin origin) {
        return origin;
    }

    @Deprecated
    protected static Origin update(ResourceLocation id, Origin origin) {
        return OriginRegistry.register(id, origin);
    }

    public static int size() {
        return OriginsAPI.getOriginsRegistry().m_6566_().size();
    }

    public static Stream<ResourceLocation> identifiers() {
        return OriginsAPI.getOriginsRegistry().m_6566_().stream();
    }

    public static Iterable<Map.Entry<ResourceLocation, Origin>> entries() {
        return () -> {
            final Iterator iterator = OriginsAPI.getOriginsRegistry().m_6579_().iterator();
            return new Iterator<Map.Entry<ResourceLocation, Origin>>(){

                @Override
                public boolean hasNext() {
                    return iterator.hasNext();
                }

                @Override
                public Map.Entry<ResourceLocation, Origin> next() {
                    final Map.Entry next = (Map.Entry)iterator.next();
                    return new Map.Entry<ResourceLocation, Origin>(){

                        @Override
                        public ResourceLocation getKey() {
                            return ((ResourceKey)next.getKey()).m_135782_();
                        }

                        @Override
                        public Origin getValue() {
                            return OriginRegistry.get((io.github.edwinmindcraft.origins.api.origin.Origin)next.getValue());
                        }

                        @Override
                        public Origin setValue(Origin value) {
                            return null;
                        }
                    };
                }
            };
        };
    }

    public static Iterable<Origin> values() {
        return () -> {
            final Iterator iterator = OriginsAPI.getOriginsRegistry().iterator();
            return new Iterator<Origin>(){

                @Override
                public boolean hasNext() {
                    return iterator.hasNext();
                }

                @Override
                public Origin next() {
                    return OriginRegistry.get((io.github.edwinmindcraft.origins.api.origin.Origin)iterator.next());
                }
            };
        };
    }

    public static Origin get(ResourceLocation id) {
        return OriginsAPI.getOriginsRegistry().m_6612_(id).map(OriginRegistry::get).orElseThrow(() -> new IllegalArgumentException("Could not get origin from id '" + id.toString() + "', as it was not registered!"));
    }

    public static Origin get(io.github.edwinmindcraft.origins.api.origin.Origin origin) {
        return CACHE_MAP.computeIfAbsent(origin, o -> new Origin(() -> o));
    }

    public static boolean contains(ResourceLocation id) {
        return OriginsAPI.getOriginsRegistry().m_7804_(id);
    }

    public static boolean contains(Origin origin) {
        return OriginRegistry.contains(origin.getIdentifier());
    }

    public static void clear() {
        CACHE_MAP.clear();
    }

    public static void reset() {
        OriginRegistry.clear();
    }

    public static void remove(ResourceLocation id) {
        throw new UnsupportedOperationException("Remove origins by cancelling a registration event.");
    }
}

