/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableSet
 *  net.minecraft.resources.ResourceLocation
 */
package io.github.apace100.origins.origin;

import com.google.common.collect.ImmutableSet;
import io.github.apace100.origins.origin.OriginLayer;
import io.github.edwinmindcraft.origins.api.OriginsAPI;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.resources.ResourceLocation;

@Deprecated
public class OriginLayers {
    private static final Map<io.github.edwinmindcraft.origins.api.origin.OriginLayer, OriginLayer> CACHE_MAP = new ConcurrentHashMap<io.github.edwinmindcraft.origins.api.origin.OriginLayer, OriginLayer>();

    public static OriginLayer getLayer(ResourceLocation id) {
        return OriginsAPI.getLayersRegistry().m_6612_(id).map(OriginLayer::new).orElse(null);
    }

    public static Collection<OriginLayer> getLayers() {
        return (Collection)OriginsAPI.getLayersRegistry().m_123024_().map(OriginLayer::new).collect(ImmutableSet.toImmutableSet());
    }

    public static int size() {
        return OriginsAPI.getLayersRegistry().m_6566_().size();
    }

    public static void clear() {
        CACHE_MAP.clear();
    }

    @Deprecated
    public static void add(OriginLayer layer) {
    }

    public static OriginLayer get(io.github.edwinmindcraft.origins.api.origin.OriginLayer layer) {
        return CACHE_MAP.computeIfAbsent(layer, OriginLayer::new);
    }
}

