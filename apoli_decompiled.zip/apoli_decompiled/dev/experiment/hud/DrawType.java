/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.booleans.BooleanUnaryOperator
 */
package dev.experiment.hud;

import it.unimi.dsi.fastutil.booleans.BooleanUnaryOperator;

public enum DrawType implements BooleanUnaryOperator
{
    FORCE(x -> true),
    SHOW(BooleanUnaryOperator.identity()),
    HIDE(x -> false);

    private final BooleanUnaryOperator operator;

    private DrawType(BooleanUnaryOperator operator) {
        this.operator = operator;
    }

    public boolean apply(boolean other) {
        return this.operator.apply(other);
    }
}

