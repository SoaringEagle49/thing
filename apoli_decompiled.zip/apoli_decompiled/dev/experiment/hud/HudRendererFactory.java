/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  net.minecraft.client.gui.GuiGraphics
 *  net.minecraft.world.entity.Entity
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  org.jetbrains.annotations.NotNull
 */
package dev.experiment.hud;

import com.mojang.serialization.Codec;
import dev.experiment.hud.ConfiguredHudRenderer;
import dev.experiment.hud.DrawType;
import dev.experiment.hud.HudExperiment;
import io.github.apace100.apoli.util.HudRender;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.ConfiguredFactory;
import io.github.edwinmindcraft.apoli.api.power.IFactory;
import io.github.edwinmindcraft.apoli.api.registry.ApoliRegistries;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jetbrains.annotations.NotNull;

public abstract class HudRendererFactory<T extends IDynamicFeatureConfiguration>
implements IFactory<T, ConfiguredHudRenderer<T, HudRendererFactory<T>>, HudRendererFactory<T>> {
    public static final Codec<HudRendererFactory<?>> CODEC = ApoliRegistries.codec(HudExperiment.HUD_RENDERERS.registry());
    private final Codec<ConfiguredHudRenderer<T, ?>> codec;

    public HudRendererFactory(Codec<T> codec) {
        this.codec = IFactory.singleCodec(IFactory.asMap(codec), iDynamicFeatureConfiguration -> this.configure((IDynamicFeatureConfiguration)iDynamicFeatureConfiguration), ConfiguredFactory::getConfiguration);
    }

    public Codec<ConfiguredHudRenderer<T, ?>> getCodec() {
        return this.codec;
    }

    @Override
    @NotNull
    public ConfiguredHudRenderer<T, HudRendererFactory<T>> configure(@NotNull T input) {
        return new ConfiguredHudRenderer<T, HudRendererFactory>(() -> this, input);
    }

    @OnlyIn(value=Dist.CLIENT)
    public abstract void drawBar(ConfiguredHudRenderer<T, ?> var1, Entity var2, GuiGraphics var3, int var4, int var5, int var6, float var7);

    @OnlyIn(value=Dist.CLIENT)
    public abstract void drawIcon(ConfiguredHudRenderer<T, ?> var1, Entity var2, GuiGraphics var3, int var4, int var5, float var6);

    public abstract DrawType shouldDraw(ConfiguredHudRenderer<T, ?> var1, Entity var2);

    public abstract int height(ConfiguredHudRenderer<T, ?> var1, Entity var2);

    public abstract HudRender asStable(ConfiguredHudRenderer<T, ?> var1);
}

