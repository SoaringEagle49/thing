/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.registries.DeferredRegister
 *  net.minecraftforge.registries.IForgeRegistry
 *  net.minecraftforge.registries.RegistryBuilder
 */
package dev.experiment.helper;

import io.github.apace100.apoli.Apoli;
import java.util.function.Supplier;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegistryBuilder;

public record RegistryDefinition<T>(DeferredRegister<T> register, Supplier<IForgeRegistry<T>> registry) {
    public static <T> RegistryDefinition<T> define(String registryName) {
        DeferredRegister deferredRegister = DeferredRegister.create((ResourceLocation)Apoli.identifier(registryName), (String)"apoli");
        Supplier registry = deferredRegister.makeRegistry(() -> new RegistryBuilder().disableSaving());
        return new RegistryDefinition<T>(deferredRegister, registry);
    }
}

