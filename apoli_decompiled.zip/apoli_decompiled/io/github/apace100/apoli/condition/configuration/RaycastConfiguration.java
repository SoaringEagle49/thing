/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  net.minecraft.core.Holder
 */
package io.github.apace100.apoli.condition.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.apoli.configuration.RaycastSettingsConfiguration;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiEntityCondition;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBlockCondition;
import net.minecraft.core.Holder;

public record RaycastConfiguration(RaycastSettingsConfiguration settings, Holder<ConfiguredBiEntityCondition<?, ?>> matchCondition, Holder<ConfiguredBiEntityCondition<?, ?>> hitCondition, Holder<ConfiguredBlockCondition<?, ?>> blockCondition) implements IDynamicFeatureConfiguration
{
    public static final Codec<RaycastConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)RaycastSettingsConfiguration.MAP_CODEC.forGetter(RaycastConfiguration::settings), (App)ConfiguredBiEntityCondition.optional("match_bientity_condition").forGetter(RaycastConfiguration::matchCondition), (App)ConfiguredBiEntityCondition.optional("hit_bientity_condition").forGetter(RaycastConfiguration::hitCondition), (App)ConfiguredBlockCondition.optional("block_condition").forGetter(RaycastConfiguration::blockCondition)).apply((Applicative)instance, RaycastConfiguration::new));
}

