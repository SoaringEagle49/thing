/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataType
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.core.Direction$Axis
 */
package io.github.apace100.apoli.condition.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.apoli.power.factory.condition.bientity.RelativeRotationCondition;
import io.github.apace100.calio.data.SerializableDataType;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.configuration.DoubleComparisonConfiguration;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import java.util.EnumSet;
import net.minecraft.core.Direction;

public record RelativeRotationConfiguration(EnumSet<Direction.Axis> axes, RelativeRotationCondition.RotationType actorRotation, RelativeRotationCondition.RotationType targetRotation, DoubleComparisonConfiguration comparison) implements IDynamicFeatureConfiguration
{
    public static final Codec<RelativeRotationConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)CalioCodecHelper.optionalField((Codec)SerializableDataTypes.AXIS_SET, (String)"axes", EnumSet.allOf(Direction.Axis.class)).forGetter(RelativeRotationConfiguration::axes), (App)CalioCodecHelper.optionalField((Codec)SerializableDataType.enumValue(RelativeRotationCondition.RotationType.class), (String)"actor_rotation", (Object)((Object)RelativeRotationCondition.RotationType.HEAD)).forGetter(RelativeRotationConfiguration::actorRotation), (App)CalioCodecHelper.optionalField((Codec)SerializableDataType.enumValue(RelativeRotationCondition.RotationType.class), (String)"target_rotation", (Object)((Object)RelativeRotationCondition.RotationType.BODY)).forGetter(RelativeRotationConfiguration::targetRotation), (App)DoubleComparisonConfiguration.MAP_CODEC.forGetter(RelativeRotationConfiguration::comparison)).apply((Applicative)instance, RelativeRotationConfiguration::new));
}

