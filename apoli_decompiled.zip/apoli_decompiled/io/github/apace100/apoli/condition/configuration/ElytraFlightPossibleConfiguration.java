/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 */
package io.github.apace100.apoli.condition.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;

public record ElytraFlightPossibleConfiguration(boolean checkState, boolean checkAbility) implements IDynamicFeatureConfiguration
{
    public static final Codec<ElytraFlightPossibleConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.BOOL, (String)"check_state", (Object)false).forGetter(ElytraFlightPossibleConfiguration::checkState), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.BOOL, (String)"check_ability", (Object)true).forGetter(ElytraFlightPossibleConfiguration::checkAbility)).apply((Applicative)instance, ElytraFlightPossibleConfiguration::new));
}

