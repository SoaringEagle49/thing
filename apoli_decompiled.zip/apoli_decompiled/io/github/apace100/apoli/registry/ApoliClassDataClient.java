/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.apace100.calio.ClassUtil
 *  io.github.apace100.calio.data.ClassDataRegistry
 *  net.minecraft.client.renderer.entity.layers.ArrowLayer
 *  net.minecraft.client.renderer.entity.layers.BeeStingerLayer
 *  net.minecraft.client.renderer.entity.layers.CapeLayer
 *  net.minecraft.client.renderer.entity.layers.CarriedBlockLayer
 *  net.minecraft.client.renderer.entity.layers.CatCollarLayer
 *  net.minecraft.client.renderer.entity.layers.CrossedArmsItemLayer
 *  net.minecraft.client.renderer.entity.layers.CustomHeadLayer
 *  net.minecraft.client.renderer.entity.layers.Deadmau5EarsLayer
 *  net.minecraft.client.renderer.entity.layers.DolphinCarryingItemLayer
 *  net.minecraft.client.renderer.entity.layers.DrownedOuterLayer
 *  net.minecraft.client.renderer.entity.layers.ElytraLayer
 *  net.minecraft.client.renderer.entity.layers.EnergySwirlLayer
 *  net.minecraft.client.renderer.entity.layers.EyesLayer
 *  net.minecraft.client.renderer.entity.layers.FoxHeldItemLayer
 *  net.minecraft.client.renderer.entity.layers.HorseArmorLayer
 *  net.minecraft.client.renderer.entity.layers.HorseMarkingLayer
 *  net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer
 *  net.minecraft.client.renderer.entity.layers.IronGolemCrackinessLayer
 *  net.minecraft.client.renderer.entity.layers.IronGolemFlowerLayer
 *  net.minecraft.client.renderer.entity.layers.ItemInHandLayer
 *  net.minecraft.client.renderer.entity.layers.LlamaDecorLayer
 *  net.minecraft.client.renderer.entity.layers.MushroomCowMushroomLayer
 *  net.minecraft.client.renderer.entity.layers.PandaHoldsItemLayer
 *  net.minecraft.client.renderer.entity.layers.ParrotOnShoulderLayer
 *  net.minecraft.client.renderer.entity.layers.RenderLayer
 *  net.minecraft.client.renderer.entity.layers.SaddleLayer
 *  net.minecraft.client.renderer.entity.layers.SheepFurLayer
 *  net.minecraft.client.renderer.entity.layers.ShulkerHeadLayer
 *  net.minecraft.client.renderer.entity.layers.SlimeOuterLayer
 *  net.minecraft.client.renderer.entity.layers.SnowGolemHeadLayer
 *  net.minecraft.client.renderer.entity.layers.SpinAttackEffectLayer
 *  net.minecraft.client.renderer.entity.layers.StrayClothingLayer
 *  net.minecraft.client.renderer.entity.layers.StuckInBodyLayer
 *  net.minecraft.client.renderer.entity.layers.TropicalFishPatternLayer
 *  net.minecraft.client.renderer.entity.layers.VillagerProfessionLayer
 *  net.minecraft.client.renderer.entity.layers.WolfCollarLayer
 */
package io.github.apace100.apoli.registry;

import io.github.apace100.calio.ClassUtil;
import io.github.apace100.calio.data.ClassDataRegistry;
import net.minecraft.client.renderer.entity.layers.ArrowLayer;
import net.minecraft.client.renderer.entity.layers.BeeStingerLayer;
import net.minecraft.client.renderer.entity.layers.CapeLayer;
import net.minecraft.client.renderer.entity.layers.CarriedBlockLayer;
import net.minecraft.client.renderer.entity.layers.CatCollarLayer;
import net.minecraft.client.renderer.entity.layers.CrossedArmsItemLayer;
import net.minecraft.client.renderer.entity.layers.CustomHeadLayer;
import net.minecraft.client.renderer.entity.layers.Deadmau5EarsLayer;
import net.minecraft.client.renderer.entity.layers.DolphinCarryingItemLayer;
import net.minecraft.client.renderer.entity.layers.DrownedOuterLayer;
import net.minecraft.client.renderer.entity.layers.ElytraLayer;
import net.minecraft.client.renderer.entity.layers.EnergySwirlLayer;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.client.renderer.entity.layers.FoxHeldItemLayer;
import net.minecraft.client.renderer.entity.layers.HorseArmorLayer;
import net.minecraft.client.renderer.entity.layers.HorseMarkingLayer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.layers.IronGolemCrackinessLayer;
import net.minecraft.client.renderer.entity.layers.IronGolemFlowerLayer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.client.renderer.entity.layers.LlamaDecorLayer;
import net.minecraft.client.renderer.entity.layers.MushroomCowMushroomLayer;
import net.minecraft.client.renderer.entity.layers.PandaHoldsItemLayer;
import net.minecraft.client.renderer.entity.layers.ParrotOnShoulderLayer;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.layers.SaddleLayer;
import net.minecraft.client.renderer.entity.layers.SheepFurLayer;
import net.minecraft.client.renderer.entity.layers.ShulkerHeadLayer;
import net.minecraft.client.renderer.entity.layers.SlimeOuterLayer;
import net.minecraft.client.renderer.entity.layers.SnowGolemHeadLayer;
import net.minecraft.client.renderer.entity.layers.SpinAttackEffectLayer;
import net.minecraft.client.renderer.entity.layers.StrayClothingLayer;
import net.minecraft.client.renderer.entity.layers.StuckInBodyLayer;
import net.minecraft.client.renderer.entity.layers.TropicalFishPatternLayer;
import net.minecraft.client.renderer.entity.layers.VillagerProfessionLayer;
import net.minecraft.client.renderer.entity.layers.WolfCollarLayer;

public class ApoliClassDataClient {
    public static void registerAll() {
        ClassDataRegistry featureRenderer = ClassDataRegistry.getOrCreate((Class)ClassUtil.castClass(RenderLayer.class), (String)"FeatureRenderer");
        featureRenderer.addMapping("slime_overlay", SlimeOuterLayer.class);
        featureRenderer.addMapping("snowman_pumpkin", SnowGolemHeadLayer.class);
        featureRenderer.addMapping("fox_held_item", FoxHeldItemLayer.class);
        featureRenderer.addMapping("llama_decor", LlamaDecorLayer.class);
        featureRenderer.addMapping("elytra", ElytraLayer.class);
        featureRenderer.addMapping("villager_clothing", VillagerProfessionLayer.class);
        featureRenderer.addMapping("panda_held_item", PandaHoldsItemLayer.class);
        featureRenderer.addMapping("drowned_overlay", DrownedOuterLayer.class);
        featureRenderer.addMapping("saddle", SaddleLayer.class);
        featureRenderer.addMapping("shoulder_parrot", ParrotOnShoulderLayer.class);
        featureRenderer.addMapping("horse_armor", HorseArmorLayer.class);
        featureRenderer.addMapping("wolf_collar", WolfCollarLayer.class);
        featureRenderer.addMapping("energy_swirl_overlay", EnergySwirlLayer.class);
        featureRenderer.addMapping("held_item", ItemInHandLayer.class);
        featureRenderer.addMapping("sheep_wool", SheepFurLayer.class);
        featureRenderer.addMapping("iron_golem_flower", IronGolemFlowerLayer.class);
        featureRenderer.addMapping("cape", CapeLayer.class);
        featureRenderer.addMapping("eyes", EyesLayer.class);
        featureRenderer.addMapping("dolphin_held_item", DolphinCarryingItemLayer.class);
        featureRenderer.addMapping("horse_marking", HorseMarkingLayer.class);
        featureRenderer.addMapping("deadmau5", Deadmau5EarsLayer.class);
        featureRenderer.addMapping("armor", HumanoidArmorLayer.class);
        featureRenderer.addMapping("stray_overlay", StrayClothingLayer.class);
        featureRenderer.addMapping("enderman_block", CarriedBlockLayer.class);
        featureRenderer.addMapping("mooshroom_mushroom", MushroomCowMushroomLayer.class);
        featureRenderer.addMapping("iron_golem_crack", IronGolemCrackinessLayer.class);
        featureRenderer.addMapping("villager_held_item", CrossedArmsItemLayer.class);
        featureRenderer.addMapping("trident_riptide", SpinAttackEffectLayer.class);
        featureRenderer.addMapping("head", CustomHeadLayer.class);
        featureRenderer.addMapping("cat_collar", CatCollarLayer.class);
        featureRenderer.addMapping("tropical_fish_color", TropicalFishPatternLayer.class);
        featureRenderer.addMapping("shulker_head", ShulkerHeadLayer.class);
        featureRenderer.addMapping("stuck_objects", StuckInBodyLayer.class);
        featureRenderer.addMapping("stuck_stingers", BeeStingerLayer.class);
        featureRenderer.addMapping("stuck_arrows", ArrowLayer.class);
    }
}

