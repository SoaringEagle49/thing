/*
 * Decompiled with CFR 0.152.
 */
package io.github.apace100.apoli.global;

public class GlobalPowerSetLoader {
}

