/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.item.ItemStack
 */
package io.github.apace100.apoli.access;

import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.apoli.common.power.ModifyFoodPower;
import io.github.edwinmindcraft.apoli.common.power.configuration.ModifyFoodConfiguration;
import java.util.List;
import net.minecraft.world.item.ItemStack;

public interface ModifiableFoodEntity {
    public ItemStack getOriginalFoodStack();

    public void setOriginalFoodStack(ItemStack var1);

    public List<ConfiguredPower<ModifyFoodConfiguration, ModifyFoodPower>> getCurrentModifyFoodPowers();

    public void setCurrentModifyFoodPowers(List<ConfiguredPower<ModifyFoodConfiguration, ModifyFoodPower>> var1);

    public void enforceFoodSync();

    public void resetFoodSync();

    public boolean shouldSyncFood();
}

