/*
 * Decompiled with CFR 0.152.
 */
package io.github.apace100.apoli.access;

import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;

public interface PowerCraftingInventory {
    public void setPower(ConfiguredPower<?, ?> var1);

    public ConfiguredPower<?, ?> getPower();
}

