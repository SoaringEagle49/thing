/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.effect.MobEffectInstance
 */
package io.github.apace100.apoli.access;

import net.minecraft.world.effect.MobEffectInstance;

public interface HiddenEffectStatus {
    public MobEffectInstance getHiddenEffect();
}

