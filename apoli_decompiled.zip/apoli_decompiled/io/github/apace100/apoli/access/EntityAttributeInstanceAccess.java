/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 *  org.jetbrains.annotations.Nullable
 */
package io.github.apace100.apoli.access;

import net.minecraft.world.entity.Entity;
import org.jetbrains.annotations.Nullable;

public interface EntityAttributeInstanceAccess {
    @Nullable
    public Entity getEntity();

    public void setEntity(Entity var1);
}

