/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.Entity
 *  org.jetbrains.annotations.Nullable
 */
package io.github.apace100.apoli.access;

import io.github.apace100.apoli.Apoli;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import org.jetbrains.annotations.Nullable;

public interface EntityLinkedItemStack {
    public static final ResourceLocation KEY = Apoli.identifier("entity_linked_item");

    public Entity getEntity();

    public void setEntity(@Nullable Entity var1);
}

