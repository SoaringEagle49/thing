/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.tags.TagKey
 *  net.minecraft.world.level.material.Fluid
 */
package io.github.apace100.apoli.access;

import net.minecraft.tags.TagKey;
import net.minecraft.world.level.material.Fluid;

public interface SubmergableEntity {
    public boolean isSubmergedInLoosely(TagKey<Fluid> var1);

    public double getFluidHeightLoosely(TagKey<Fluid> var1);
}

