/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.level.storage.loot.parameters.LootContextParamSet
 */
package io.github.apace100.apoli.access;

import net.minecraft.world.level.storage.loot.parameters.LootContextParamSet;

public interface ReplacingLootContextParameterSet {
    public void setType(LootContextParamSet var1);

    public LootContextParamSet getType();
}

