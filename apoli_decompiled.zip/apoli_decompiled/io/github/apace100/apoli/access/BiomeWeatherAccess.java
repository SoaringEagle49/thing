/*
 * Decompiled with CFR 0.152.
 */
package io.github.apace100.apoli.access;

public interface BiomeWeatherAccess {
    public float getDownfall();

    public void setDownfall(float var1);
}

