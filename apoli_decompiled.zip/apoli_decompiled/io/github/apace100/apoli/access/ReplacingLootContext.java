/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.level.storage.loot.LootTable
 *  net.minecraft.world.level.storage.loot.parameters.LootContextParamSet
 */
package io.github.apace100.apoli.access;

import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSet;

public interface ReplacingLootContext {
    public void setType(LootContextParamSet var1);

    public LootContextParamSet getType();

    public void setReplaced(LootTable var1);

    public boolean isReplaced(LootTable var1);
}

