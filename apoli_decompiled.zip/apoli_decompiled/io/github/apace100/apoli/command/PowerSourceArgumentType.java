/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.StringReader
 *  com.mojang.brigadier.arguments.ArgumentType
 *  com.mojang.brigadier.context.CommandContext
 *  com.mojang.brigadier.exceptions.CommandSyntaxException
 *  com.mojang.brigadier.suggestion.Suggestions
 *  com.mojang.brigadier.suggestion.SuggestionsBuilder
 *  io.github.edwinmindcraft.calio.api.CalioAPI
 *  net.minecraft.commands.CommandBuildContext
 *  net.minecraft.commands.CommandRuntimeException
 *  net.minecraft.commands.CommandSourceStack
 *  net.minecraft.commands.SharedSuggestionProvider
 *  net.minecraft.commands.arguments.EntityArgument
 *  net.minecraft.network.chat.Component
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.server.MinecraftServer
 *  org.jetbrains.annotations.Nullable
 */
package io.github.apace100.apoli.command;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import io.github.edwinmindcraft.apoli.api.ApoliAPI;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.apoli.api.registry.ApoliDynamicRegistries;
import io.github.edwinmindcraft.calio.api.CalioAPI;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.commands.CommandRuntimeException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

public class PowerSourceArgumentType
implements ArgumentType<ResourceLocation> {
    private final String target;

    public static PowerSourceArgumentType powerSource(String target) {
        return new PowerSourceArgumentType(target);
    }

    public static PowerSourceArgumentType powerSource(CommandBuildContext context) {
        return new PowerSourceArgumentType(null);
    }

    public static ConfiguredPower<?, ?> getConfiguredPower(CommandContext<CommandSourceStack> context, String argumentName) {
        ResourceLocation argument = (ResourceLocation)context.getArgument(argumentName, ResourceLocation.class);
        return (ConfiguredPower)CalioAPI.getDynamicRegistries((MinecraftServer)((CommandSourceStack)context.getSource()).m_81377_()).get(ApoliDynamicRegistries.CONFIGURED_POWER_KEY).m_6612_(argument).orElseThrow(() -> new CommandRuntimeException((Component)Component.m_237110_((String)"arguments.apoli.power_source.fail", (Object[])new Object[]{argument})));
    }

    public PowerSourceArgumentType(@Nullable String target) {
        this.target = target;
    }

    public ResourceLocation parse(StringReader reader) throws CommandSyntaxException {
        return ResourceLocation.m_135818_((StringReader)reader);
    }

    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        if (context.getSource() instanceof CommandSourceStack && this.target != null) {
            try {
                Set collect = EntityArgument.m_91461_(context, (String)this.target).stream().map(ApoliAPI::getPowerContainer).filter(Objects::nonNull).flatMap(x -> x.getPowerTypes(true).stream().flatMap(name -> x.getSources((ResourceKey<ConfiguredPower<?, ?>>)name).stream())).collect(Collectors.toSet());
                return SharedSuggestionProvider.m_82926_(collect, (SuggestionsBuilder)builder);
            }
            catch (CommandSyntaxException e) {
                return Suggestions.empty();
            }
        }
        return Suggestions.empty();
    }
}

