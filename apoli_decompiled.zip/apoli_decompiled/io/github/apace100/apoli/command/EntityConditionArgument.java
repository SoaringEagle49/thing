/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableSet
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  com.google.gson.stream.JsonReader
 *  com.mojang.brigadier.context.CommandContext
 *  com.mojang.brigadier.exceptions.CommandSyntaxException
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.commands.CommandSourceStack
 */
package io.github.apace100.apoli.command;

import com.google.common.collect.ImmutableSet;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.stream.JsonReader;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.apace100.apoli.command.JsonObjectArgument;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredEntityCondition;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import java.io.IOException;
import java.util.Collection;
import net.minecraft.commands.CommandSourceStack;

public class EntityConditionArgument
extends JsonObjectArgument<ConfiguredEntityCondition<?, ?>> {
    private static final Gson GSON = new GsonBuilder().disableHtmlEscaping().registerTypeHierarchyAdapter(ConfiguredEntityCondition.class, (Object)CalioCodecHelper.jsonAdapter(ConfiguredEntityCondition.CODEC)).create();

    public static EntityConditionArgument entityCondition() {
        return new EntityConditionArgument();
    }

    public static ConfiguredEntityCondition<?, ?> getEntityCondition(CommandContext<CommandSourceStack> pContext, String pName) throws CommandSyntaxException {
        return (ConfiguredEntityCondition)pContext.getArgument(pName, ConfiguredEntityCondition.class);
    }

    @Override
    protected ConfiguredEntityCondition<?, ?> convert(JsonReader obj) throws IOException {
        return (ConfiguredEntityCondition)GSON.getAdapter(ConfiguredEntityCondition.class).read(obj);
    }

    public Collection<String> getExamples() {
        return ImmutableSet.of((Object)"{\"type\":\"apoli:exposed_to_sky\"}");
    }
}

