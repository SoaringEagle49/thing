/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.StringReader
 *  com.mojang.brigadier.arguments.ArgumentType
 *  com.mojang.brigadier.context.CommandContext
 *  com.mojang.brigadier.exceptions.CommandSyntaxException
 *  com.mojang.brigadier.suggestion.Suggestions
 *  com.mojang.brigadier.suggestion.SuggestionsBuilder
 *  net.minecraft.commands.CommandRuntimeException
 *  net.minecraft.commands.CommandSourceStack
 *  net.minecraft.commands.SharedSuggestionProvider
 *  net.minecraft.network.chat.Component
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 */
package io.github.apace100.apoli.command;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import io.github.edwinmindcraft.apoli.api.ApoliAPI;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.apoli.api.registry.ApoliDynamicRegistries;
import java.util.concurrent.CompletableFuture;
import net.minecraft.commands.CommandRuntimeException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;

public class PowerTypeArgumentType
implements ArgumentType<ResourceLocation> {
    public static PowerTypeArgumentType power() {
        return new PowerTypeArgumentType();
    }

    public static ResourceKey<ConfiguredPower<?, ?>> getConfiguredPower(CommandContext<CommandSourceStack> context, String argumentName) {
        ResourceLocation argument = (ResourceLocation)context.getArgument(argumentName, ResourceLocation.class);
        if (!ApoliAPI.getPowers(((CommandSourceStack)context.getSource()).m_81377_()).m_7804_(argument)) {
            throw new CommandRuntimeException((Component)Component.m_237110_((String)"commands.apoli.power_not_found", (Object[])new Object[]{argument}));
        }
        return ResourceKey.m_135785_(ApoliDynamicRegistries.CONFIGURED_POWER_KEY, (ResourceLocation)argument);
    }

    public ResourceLocation parse(StringReader reader) throws CommandSyntaxException {
        return ResourceLocation.m_135818_((StringReader)reader);
    }

    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        return SharedSuggestionProvider.m_82926_((Iterable)ApoliAPI.getPowers().m_6566_(), (SuggestionsBuilder)builder);
    }
}

