/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.tags.TagKey
 *  net.minecraft.world.level.block.Block
 *  net.minecraft.world.level.block.state.BlockState
 */
package io.github.apace100.apoli.data;

import io.github.apace100.apoli.Apoli;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public class LegacyMaterial {
    private final TagKey<Block> materialTagKey;
    private final String material;

    public LegacyMaterial(String material) {
        this.materialTagKey = TagKey.m_203882_((ResourceKey)Registries.f_256747_, (ResourceLocation)Apoli.identifier("material/" + material));
        this.material = material;
    }

    public String getMaterial() {
        return this.material;
    }

    public boolean blockStateIsOfMaterial(BlockState blockState) {
        return blockState.m_204336_(this.materialTagKey);
    }
}

