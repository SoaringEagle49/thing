/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.BiMap
 *  com.google.common.collect.HashBiMap
 *  com.google.common.collect.ImmutableBiMap
 *  com.mojang.brigadier.arguments.ArgumentType
 *  io.github.apace100.calio.ClassUtil
 *  io.github.apace100.calio.SerializationHelper
 *  io.github.apace100.calio.data.SerializableData
 *  io.github.apace100.calio.data.SerializableData$Instance
 *  io.github.apace100.calio.data.SerializableDataType
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.apace100.calio.util.ArgumentWrapper
 *  io.github.edwinmindcraft.calio.api.ability.PlayerAbility
 *  io.github.edwinmindcraft.calio.api.registry.PlayerAbilities
 *  net.minecraft.commands.arguments.EntityArgument
 *  net.minecraft.commands.arguments.SlotArgument
 *  net.minecraft.commands.arguments.selector.EntitySelector
 *  net.minecraft.core.Registry
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.stats.Stat
 *  net.minecraft.stats.StatType
 *  net.minecraft.util.Tuple
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Explosion$BlockInteraction
 *  net.minecraft.world.level.ItemLike
 *  net.minecraftforge.registries.ForgeRegistries
 *  net.minecraftforge.registries.IForgeRegistry
 */
package io.github.apace100.apoli.data;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import com.google.common.collect.ImmutableBiMap;
import com.mojang.brigadier.arguments.ArgumentType;
import io.github.apace100.apoli.data.DamageSourceDescription;
import io.github.apace100.apoli.data.LegacyMaterial;
import io.github.apace100.apoli.util.AttributedEntityAttributeModifier;
import io.github.apace100.apoli.util.Comparison;
import io.github.apace100.apoli.util.HudRender;
import io.github.apace100.apoli.util.InventoryUtil;
import io.github.apace100.apoli.util.ResourceOperation;
import io.github.apace100.apoli.util.Space;
import io.github.apace100.calio.ClassUtil;
import io.github.apace100.calio.SerializationHelper;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataType;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.apace100.calio.util.ArgumentWrapper;
import io.github.edwinmindcraft.calio.api.ability.PlayerAbility;
import io.github.edwinmindcraft.calio.api.registry.PlayerAbilities;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.SlotArgument;
import net.minecraft.commands.arguments.selector.EntitySelector;
import net.minecraft.core.Registry;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.stats.Stat;
import net.minecraft.stats.StatType;
import net.minecraft.util.Tuple;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.ItemLike;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.IForgeRegistry;

public class ApoliDataTypes {
    public static final SerializableDataType<Space> SPACE = SerializableDataType.enumValue(Space.class);
    public static final SerializableDataType<ResourceOperation> RESOURCE_OPERATION = SerializableDataType.enumValue(ResourceOperation.class);
    public static final SerializableDataType<InventoryUtil.InventoryType> INVENTORY_TYPE = SerializableDataType.enumValue(InventoryUtil.InventoryType.class);
    public static final SerializableDataType<EnumSet<InventoryUtil.InventoryType>> INVENTORY_TYPE_SET = SerializableDataType.enumSet(InventoryUtil.InventoryType.class, INVENTORY_TYPE);
    public static final SerializableDataType<InventoryUtil.ProcessMode> PROCESS_MODE = SerializableDataType.enumValue(InventoryUtil.ProcessMode.class);
    public static final SerializableDataType<AttributedEntityAttributeModifier> ATTRIBUTED_ATTRIBUTE_MODIFIER = new SerializableDataType(AttributedEntityAttributeModifier.class, AttributedEntityAttributeModifier.CODEC);
    public static final SerializableDataType<List<AttributedEntityAttributeModifier>> ATTRIBUTED_ATTRIBUTE_MODIFIERS = SerializableDataType.list(ATTRIBUTED_ATTRIBUTE_MODIFIER);
    public static final SerializableDataType<Tuple<Integer, ItemStack>> POSITIONED_ITEM_STACK = SerializableDataType.compound((Class)ClassUtil.castClass(Tuple.class), (SerializableData)new SerializableData().add("item", SerializableDataTypes.ITEM).add("amount", SerializableDataTypes.INT, (Object)1).add("tag", SerializableDataTypes.NBT, null).add("slot", SerializableDataTypes.INT, (Object)Integer.MIN_VALUE), data -> {
        ItemStack stack = new ItemStack((ItemLike)((Item)data.get("item")), data.getInt("amount"));
        if (data.isPresent("tag")) {
            stack.m_41751_((CompoundTag)data.get("tag"));
        }
        return new Tuple((Object)data.getInt("slot"), (Object)stack);
    }, (serializableData, positionedStack) -> {
        SerializableData.Instance data = new SerializableData.Instance(serializableData);
        data.set("item", (Object)((ItemStack)positionedStack.m_14419_()).m_41720_());
        data.set("amount", (Object)((ItemStack)positionedStack.m_14419_()).m_41613_());
        data.set("tag", ((ItemStack)positionedStack.m_14419_()).m_41782_() ? ((ItemStack)positionedStack.m_14419_()).m_41783_() : null);
        data.set("slot", positionedStack.m_14418_());
        return data;
    });
    public static final SerializableDataType<List<Tuple<Integer, ItemStack>>> POSITIONED_ITEM_STACKS = SerializableDataType.list(POSITIONED_ITEM_STACK);
    public static final SerializableDataType<HudRender> HUD_RENDER = new SerializableDataType(HudRender.class, HudRender.CODEC);
    public static final SerializableDataType<Comparison> COMPARISON = SerializableDataType.enumValue(Comparison.class, (HashMap)SerializationHelper.buildEnumMap(Comparison.class, Comparison::getComparisonString));
    public static final SerializableDataType<PlayerAbility> PLAYER_ABILITY = SerializableDataType.wrap(PlayerAbility.class, (SerializableDataType)SerializableDataTypes.IDENTIFIER, ability -> ((IForgeRegistry)PlayerAbilities.REGISTRY.get()).getKey(ability), id -> {
        PlayerAbility ability;
        ResourceLocation resolvedId = id;
        if (id.m_135827_().equals("minecraft")) {
            resolvedId = new ResourceLocation("calio", id.m_135815_());
        }
        if ((ability = (PlayerAbility)((IForgeRegistry)PlayerAbilities.REGISTRY.get()).getValue(resolvedId)) == null) {
            throw new NullPointerException(id + " has not been registered");
        }
        return ability;
    });
    public static final SerializableDataType<ArgumentWrapper<Integer>> ITEM_SLOT = SerializableDataType.argumentType((ArgumentType)SlotArgument.m_111276_());
    public static final SerializableDataType<List<ArgumentWrapper<Integer>>> ITEM_SLOTS = SerializableDataType.list(ITEM_SLOT);
    public static final SerializableDataType<Explosion.BlockInteraction> BACKWARDS_COMPATIBLE_DESTRUCTION_TYPE = SerializableDataType.mapped(Explosion.BlockInteraction.class, (BiMap)HashBiMap.create((Map)ImmutableBiMap.of((Object)"none", (Object)Explosion.BlockInteraction.KEEP, (Object)"break", (Object)Explosion.BlockInteraction.DESTROY, (Object)"destroy", (Object)Explosion.BlockInteraction.DESTROY_WITH_DECAY)));
    public static final SerializableDataType<ArgumentWrapper<EntitySelector>> ENTITIES_SELECTOR = SerializableDataType.argumentType((ArgumentType)EntityArgument.m_91460_());
    public static final SerializableDataType<DamageSourceDescription> DAMAGE_SOURCE_DESCRIPTION = new SerializableDataType(DamageSourceDescription.class, DamageSourceDescription.CODEC);
    public static final SerializableDataType<LegacyMaterial> LEGACY_MATERIAL = SerializableDataType.wrap(LegacyMaterial.class, (SerializableDataType)SerializableDataTypes.STRING, LegacyMaterial::getMaterial, LegacyMaterial::new);
    public static final SerializableDataType<List<LegacyMaterial>> LEGACY_MATERIALS = SerializableDataType.list(LEGACY_MATERIAL);
    public static final SerializableDataType<Stat<?>> STAT = SerializableDataType.compound((Class)ClassUtil.castClass(Stat.class), (SerializableData)new SerializableData().add("type", SerializableDataType.registry((Class)ClassUtil.castClass(StatType.class), (IForgeRegistry)ForgeRegistries.STAT_TYPES)).add("id", SerializableDataTypes.IDENTIFIER), data -> {
        ResourceLocation statId;
        StatType statType = (StatType)data.get("type");
        Registry statRegistry = statType.m_12893_();
        if (statRegistry.m_7804_(statId = (ResourceLocation)data.get("id"))) {
            Object statObject = statRegistry.m_7745_(statId);
            return statType.m_12902_(statObject);
        }
        throw new IllegalArgumentException("Desired stat \"" + statId + "\" does not exist in stat type ");
    }, (data, stat) -> {
        SerializableData.Instance inst = new SerializableData.Instance(data);
        inst.set("type", (Object)stat.m_12859_());
        Registry reg = stat.m_12859_().m_12893_();
        ResourceLocation statId = reg.m_7981_(stat.m_12867_());
        inst.set("id", (Object)statId);
        return inst;
    });
}

