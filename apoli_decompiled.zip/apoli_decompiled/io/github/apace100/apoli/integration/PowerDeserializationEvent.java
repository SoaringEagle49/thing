/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.eventbus.api.Event
 */
package io.github.apace100.apoli.integration;

import net.minecraftforge.eventbus.api.Event;

public class PowerDeserializationEvent
extends Event {
}

