/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 */
package io.github.apace100.apoli.util;

import io.github.apace100.apoli.Apoli;
import net.minecraft.resources.ResourceLocation;

public class ApoliResourceConditions {
    public static final ResourceLocation ANY_NAMESPACE_LOADED = Apoli.identifier("any_namespace_loaded");
    public static final ResourceLocation ALL_NAMESPACES_LOADED = Apoli.identifier("all_namespaces_loaded");
}

