/*
 * Decompiled with CFR 0.152.
 */
package io.github.apace100.apoli.util.modifier;

import io.github.apace100.apoli.util.modifier.IModifierOperation;

public final class ModifierOperation
extends Enum<ModifierOperation>
implements IModifierOperation {
    private static final /* synthetic */ ModifierOperation[] $VALUES;

    public static ModifierOperation[] values() {
        return (ModifierOperation[])$VALUES.clone();
    }

    public static ModifierOperation valueOf(String name) {
        return Enum.valueOf(ModifierOperation.class, name);
    }

    private static /* synthetic */ ModifierOperation[] $values() {
        return new ModifierOperation[0];
    }

    static {
        $VALUES = ModifierOperation.$values();
    }
}

