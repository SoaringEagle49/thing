/*
 * Decompiled with CFR 0.152.
 */
package io.github.apace100.apoli.util.modifier;

public final class ModifierOperations {
}

