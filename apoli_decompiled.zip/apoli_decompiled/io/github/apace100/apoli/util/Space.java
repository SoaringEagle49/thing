/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.Mth
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.phys.Vec3
 *  org.joml.Matrix3f
 *  org.joml.Matrix3fc
 *  org.joml.Vector3f
 */
package io.github.apace100.apoli.util;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Matrix3fc;
import org.joml.Vector3f;

public enum Space {
    WORLD,
    LOCAL,
    LOCAL_HORIZONTAL,
    LOCAL_HORIZONTAL_NORMALIZED,
    VELOCITY,
    VELOCITY_NORMALIZED,
    VELOCITY_HORIZONTAL,
    VELOCITY_HORIZONTAL_NORMALIZED;


    private static Matrix3f getBaseTransformMatrixFromNormalizedDirectionVector(Vec3 vector, float yaw) {
        double xZ;
        double xX;
        double zX = 0.0;
        double zY = vector.m_7098_();
        double zZ = 0.0;
        if (Math.abs(zY) != 1.0) {
            zX = vector.m_7096_();
            zZ = vector.m_7094_();
            xX = vector.m_7094_();
            xZ = -vector.m_7096_();
            float xFactor = (float)(1.0 / Math.sqrt(xX * xX + xZ * xZ));
            xX *= (double)xFactor;
            xZ *= (double)xFactor;
        } else {
            float trigonometricYaw = -yaw * ((float)Math.PI / 180);
            xX = Mth.m_14089_((float)trigonometricYaw);
            xZ = -Mth.m_14031_((float)trigonometricYaw);
        }
        Matrix3f res = new Matrix3f();
        res.set(0, 0, (float)xX);
        res.set(1, 0, 0.0f);
        res.set(2, 0, (float)xZ);
        res.set(0, 1, (float)(zY * xZ));
        res.set(1, 1, (float)(zZ * xX - zX * xZ));
        res.set(2, 1, (float)(-zY * xX));
        res.set(0, 2, (float)zX);
        res.set(1, 2, (float)zY);
        res.set(2, 2, (float)zZ);
        return res;
    }

    public static void transformVectorToBase(Vec3 baseForwardVector, Vector3f vector, float baseYaw, boolean normalizeBase) {
        double baseScaleD = baseForwardVector.m_82553_();
        if (baseScaleD <= 0.007) {
            vector.zero();
        } else {
            float baseScale = (float)baseScaleD;
            Vec3 normalizedBase = baseForwardVector.m_82541_();
            Matrix3f transformMatrix = Space.getBaseTransformMatrixFromNormalizedDirectionVector(normalizedBase, baseYaw);
            if (!normalizeBase) {
                transformMatrix.scale(baseScale, baseScale, baseScale);
            }
            vector.mulTranspose((Matrix3fc)transformMatrix);
        }
    }

    public void toGlobal(Vector3f vector, Entity entity) {
        switch (this) {
            case WORLD: {
                break;
            }
            case LOCAL: 
            case LOCAL_HORIZONTAL: 
            case LOCAL_HORIZONTAL_NORMALIZED: {
                Vec3 baseForwardVector = entity.m_20154_();
                if (this != LOCAL) {
                    baseForwardVector = new Vec3(baseForwardVector.m_7096_(), 0.0, baseForwardVector.m_7094_());
                }
                Space.transformVectorToBase(baseForwardVector, vector, entity.m_146908_(), this == LOCAL_HORIZONTAL_NORMALIZED);
                break;
            }
            case VELOCITY: 
            case VELOCITY_NORMALIZED: 
            case VELOCITY_HORIZONTAL: 
            case VELOCITY_HORIZONTAL_NORMALIZED: {
                Vec3 baseForwardVector = entity.m_20184_();
                if (this == VELOCITY_HORIZONTAL || this == VELOCITY_HORIZONTAL_NORMALIZED) {
                    baseForwardVector = new Vec3(baseForwardVector.m_7096_(), 0.0, baseForwardVector.m_7094_());
                }
                Space.transformVectorToBase(baseForwardVector, vector, entity.m_146908_(), this == VELOCITY_NORMALIZED || this == VELOCITY_HORIZONTAL_NORMALIZED);
            }
        }
    }
}

