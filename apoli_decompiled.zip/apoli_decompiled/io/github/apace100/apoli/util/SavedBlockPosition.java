/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.level.block.entity.BlockEntity
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.block.state.pattern.BlockInWorld
 */
package io.github.apace100.apoli.util;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.pattern.BlockInWorld;

public class SavedBlockPosition
extends BlockInWorld {
    private final BlockState blockState;
    private final BlockEntity blockEntity;

    public SavedBlockPosition(LevelReader world, BlockPos pos) {
        super(world, pos, true);
        this.blockState = world.m_8055_(pos);
        this.blockEntity = world.m_7702_(pos);
    }

    public BlockState m_61168_() {
        return this.blockState;
    }

    public BlockEntity m_61174_() {
        return this.blockEntity;
    }

    public LevelReader m_61175_() {
        return super.m_61175_();
    }

    public BlockPos m_61176_() {
        return super.m_61176_();
    }
}

