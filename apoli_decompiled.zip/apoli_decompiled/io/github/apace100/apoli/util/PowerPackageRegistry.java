/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.apace100.calio.data.ClassDataRegistry
 */
package io.github.apace100.apoli.util;

import io.github.apace100.apoli.power.Power;
import io.github.apace100.calio.data.ClassDataRegistry;

public class PowerPackageRegistry {
    @Deprecated
    public static void register(String pkg) {
        ClassDataRegistry.getOrCreate(Power.class, (String)"Power").addPackage(pkg);
    }
}

