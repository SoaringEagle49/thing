/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.common.ForgeConfigSpec
 *  net.minecraftforge.common.ForgeConfigSpec$Builder
 *  org.apache.commons.lang3.tuple.Pair
 */
package io.github.apace100.apoli.util;

import io.github.apace100.apoli.util.ApoliConfig;
import io.github.apace100.apoli.util.ApoliConfigClient;
import io.github.apace100.apoli.util.ApoliConfigServer;
import net.minecraftforge.common.ForgeConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

public class ApoliConfigs {
    public static final ForgeConfigSpec COMMON_SPECS;
    public static final ForgeConfigSpec CLIENT_SPECS;
    public static final ForgeConfigSpec SERVER_SPECS;
    public static final ApoliConfig COMMON;
    public static final ApoliConfigClient CLIENT;
    public static final ApoliConfigServer SERVER;

    static {
        Pair common = new ForgeConfigSpec.Builder().configure(ApoliConfig::new);
        COMMON_SPECS = (ForgeConfigSpec)common.getRight();
        COMMON = (ApoliConfig)common.getLeft();
        Pair client = new ForgeConfigSpec.Builder().configure(ApoliConfigClient::new);
        CLIENT_SPECS = (ForgeConfigSpec)client.getRight();
        CLIENT = (ApoliConfigClient)client.getLeft();
        Pair server = new ForgeConfigSpec.Builder().configure(ApoliConfigServer::new);
        SERVER_SPECS = (ForgeConfigSpec)server.getRight();
        SERVER = (ApoliConfigServer)server.getLeft();
    }
}

