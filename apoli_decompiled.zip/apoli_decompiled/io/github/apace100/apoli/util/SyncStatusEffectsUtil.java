/*
 * Decompiled with CFR 0.152.
 */
package io.github.apace100.apoli.util;

public class SyncStatusEffectsUtil {

    public static enum UpdateType {
        CLEAR,
        APPLY,
        UPGRADE,
        REMOVE;

    }
}

