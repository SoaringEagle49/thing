/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 */
package io.github.apace100.apoli.util;

import java.util.HashMap;
import net.minecraft.resources.ResourceLocation;

public final class NamespaceAlias {
    private static final HashMap<String, String> aliasedNamespaces = new HashMap();

    public static void addAlias(String fromNamespace, String toNamespace) {
        aliasedNamespaces.put(fromNamespace, toNamespace);
    }

    public static boolean hasAlias(String namespace) {
        return aliasedNamespaces.containsKey(namespace);
    }

    public static boolean hasAlias(ResourceLocation identifier) {
        return NamespaceAlias.hasAlias(identifier.m_135827_());
    }

    public static ResourceLocation resolveAlias(ResourceLocation original) {
        if (!aliasedNamespaces.containsKey(original.m_135827_())) {
            throw new RuntimeException("Tried to resolve a namespace alias for a namespace which didn't have an alias.");
        }
        return new ResourceLocation(aliasedNamespaces.get(original.m_135827_()), original.m_135815_());
    }
}

