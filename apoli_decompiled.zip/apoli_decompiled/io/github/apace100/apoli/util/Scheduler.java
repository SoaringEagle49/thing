/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.ints.Int2ObjectMap
 *  it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap
 *  net.minecraft.server.MinecraftServer
 *  net.minecraftforge.common.MinecraftForge
 *  net.minecraftforge.event.TickEvent$Phase
 */
package io.github.apace100.apoli.util;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.IntPredicate;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;

public class Scheduler {
    private final Int2ObjectMap<List<Consumer<MinecraftServer>>> taskQueue = new Int2ObjectOpenHashMap();
    private int currentTick = 0;

    public Scheduler() {
        MinecraftForge.EVENT_BUS.addListener(event -> {
            MinecraftServer server = event.getServer();
            if (event.phase == TickEvent.Phase.END) {
                this.currentTick = server.m_129921_();
                List runnables = (List)this.taskQueue.remove(this.currentTick);
                if (runnables != null) {
                    for (Consumer runnable : runnables) {
                        Repeating repeating;
                        runnable.accept(server);
                        if (!(runnable instanceof Repeating) || !(repeating = (Repeating)runnable).shouldQueue(this.currentTick)) continue;
                        this.queue(runnable, repeating.next);
                    }
                }
            }
        });
    }

    public void queue(Consumer<MinecraftServer> task, int tick) {
        ((List)this.taskQueue.computeIfAbsent(this.currentTick + tick + 1, t -> new ArrayList())).add(task);
    }

    public void repeating(Consumer<MinecraftServer> task, int tick, int interval) {
        this.repeatWhile(task, null, tick, interval);
    }

    public void repeatWhile(Consumer<MinecraftServer> task, IntPredicate requeue, int tick, int interval) {
        this.queue(new Repeating(task, requeue, interval), tick);
    }

    public void repeatN(Consumer<MinecraftServer> task, final int times, int tick, int interval) {
        this.repeatWhile(task, new IntPredicate(){
            private int remaining;
            {
                this.remaining = times;
            }

            @Override
            public boolean test(int value) {
                return this.remaining-- > 0;
            }
        }, tick, interval);
    }

    private static final class Repeating
    implements Consumer<MinecraftServer> {
        public final int next;
        private final Consumer<MinecraftServer> task;
        private final IntPredicate requeue;

        private Repeating(Consumer<MinecraftServer> task, IntPredicate requeue, int interval) {
            this.task = task;
            this.requeue = requeue;
            this.next = interval;
        }

        public boolean shouldQueue(int predicate) {
            if (this.requeue == null) {
                return true;
            }
            return this.requeue.test(predicate);
        }

        @Override
        public void accept(MinecraftServer server) {
            this.task.accept(server);
        }
    }
}

