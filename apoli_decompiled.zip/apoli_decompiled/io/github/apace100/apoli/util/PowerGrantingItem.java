/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.EquipmentSlot
 *  net.minecraft.world.item.ItemStack
 *  org.jetbrains.annotations.NotNull
 */
package io.github.apace100.apoli.util;

import io.github.apace100.apoli.util.StackPowerUtil;
import java.util.Collection;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;

public interface PowerGrantingItem {
    @NotNull
    public Collection<StackPowerUtil.StackPower> getPowers(@NotNull ItemStack var1, @NotNull EquipmentSlot var2);
}

