/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.world.entity.ai.attributes.Attribute
 *  net.minecraft.world.entity.ai.attributes.AttributeModifier
 */
package io.github.apace100.apoli.util;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;

public record AttributedEntityAttributeModifier(Attribute attribute, AttributeModifier modifier) {
    public static final Codec<AttributedEntityAttributeModifier> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)SerializableDataTypes.ATTRIBUTE.fieldOf("attribute").forGetter(AttributedEntityAttributeModifier::attribute), (App)SerializableDataTypes.MODIFIER_OPERATION.fieldOf("operation").forGetter(x -> x.modifier().m_22217_()), (App)CalioCodecHelper.DOUBLE.fieldOf("value").forGetter(x -> x.modifier().m_22218_()), (App)CalioCodecHelper.optionalField((Codec)Codec.STRING, (String)"name", (Object)"Unnamed EntityAttributeModifier").forGetter(x -> x.modifier().m_22214_())).apply((Applicative)instance, (attribute, operation, value, name) -> new AttributedEntityAttributeModifier((Attribute)attribute, new AttributeModifier(name, value.doubleValue(), operation))));

    public AttributeModifier getModifier() {
        return this.modifier;
    }

    public Attribute getAttribute() {
        return this.attribute;
    }
}

