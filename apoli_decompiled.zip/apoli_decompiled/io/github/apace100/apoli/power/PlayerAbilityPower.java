/*
 * Decompiled with CFR 0.152.
 */
package io.github.apace100.apoli.power;

public class PlayerAbilityPower {
}

