/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.apace100.calio.FilterableWeightedList
 *  io.github.apace100.calio.data.SerializableData
 *  io.github.apace100.calio.data.SerializableData$Instance
 *  io.github.apace100.calio.data.SerializableDataType
 */
package io.github.apace100.apoli.power.factory.action.meta;

import io.github.apace100.apoli.Apoli;
import io.github.apace100.apoli.power.factory.action.ActionFactory;
import io.github.apace100.calio.FilterableWeightedList;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataType;
import java.util.Random;

public class ChoiceAction {
    public static <T> void action(SerializableData.Instance data, T t) {
        FilterableWeightedList actionList = (FilterableWeightedList)data.get("actions");
        ActionFactory.Instance action = (ActionFactory.Instance)actionList.pickRandom(new Random());
        action.accept(t);
    }

    public static <T> ActionFactory<T> getFactory(SerializableDataType<ActionFactory.Instance> dataType) {
        return new ActionFactory<Object>(Apoli.identifier("choice"), new SerializableData().add("actions", SerializableDataType.weightedList(dataType)), ChoiceAction::action);
    }
}

