/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.level.Explosion
 *  net.minecraft.world.level.Explosion$BlockInteraction
 *  net.minecraft.world.level.ExplosionDamageCalculator
 *  net.minecraft.world.level.Level
 *  org.jetbrains.annotations.NotNull
 */
package io.github.apace100.apoli.power.factory.action.block;

import io.github.apace100.apoli.action.configuration.ExplodeConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.BlockAction;
import io.github.edwinmindcraft.apoli.common.registry.condition.ApoliDefaultConditions;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.ExplosionDamageCalculator;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;

public class ExplodeAction
extends BlockAction<ExplodeConfiguration> {
    public ExplodeAction() {
        super(ExplodeConfiguration.CODEC);
    }

    @Override
    public void execute(@NotNull ExplodeConfiguration configuration, @NotNull Level world, @NotNull BlockPos pos, @NotNull Direction direction) {
        if (world.m_5776_()) {
            return;
        }
        ExplosionDamageCalculator calculator = !configuration.indestructible().m_203373_(ApoliDefaultConditions.BLOCK_DEFAULT.getId()) ? configuration.calculator() : null;
        ExplodeAction.explode(world, null, world.m_269111_().m_269093_(null), calculator, (double)pos.m_123341_() + 0.5, (double)pos.m_123342_() + 0.5, (double)pos.m_123343_() + 0.5, configuration.power(), configuration.createFire(), configuration.destructionType());
    }

    private static void explode(Level world, Entity entity, DamageSource damageSource, ExplosionDamageCalculator behavior, double x, double y, double z, float power, boolean createFire, Explosion.BlockInteraction destructionType) {
        Explosion explosion = new Explosion(world, entity, damageSource, behavior, x, y, z, power, createFire, destructionType);
        explosion.m_46061_();
        explosion.m_46075_(true);
    }
}

