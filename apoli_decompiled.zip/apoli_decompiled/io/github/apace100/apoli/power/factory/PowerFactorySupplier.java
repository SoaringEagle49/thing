/*
 * Decompiled with CFR 0.152.
 */
package io.github.apace100.apoli.power.factory;

import io.github.apace100.apoli.power.Power;
import io.github.apace100.apoli.power.factory.PowerFactory;

@FunctionalInterface
public interface PowerFactorySupplier<T extends Power> {
    public PowerFactory<T> createFactory();
}

