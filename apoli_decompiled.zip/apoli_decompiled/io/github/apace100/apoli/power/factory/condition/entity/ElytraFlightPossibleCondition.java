/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.effect.MobEffects
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 *  org.jetbrains.annotations.NotNull
 *  top.theillusivec4.caelus.api.CaelusApi
 */
package io.github.apace100.apoli.power.factory.condition.entity;

import io.github.apace100.apoli.condition.configuration.ElytraFlightPossibleConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityCondition;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.jetbrains.annotations.NotNull;
import top.theillusivec4.caelus.api.CaelusApi;

public class ElytraFlightPossibleCondition
extends EntityCondition<ElytraFlightPossibleConfiguration> {
    public ElytraFlightPossibleCondition() {
        super(ElytraFlightPossibleConfiguration.CODEC);
    }

    @Override
    public boolean check(@NotNull ElytraFlightPossibleConfiguration config, @NotNull Entity entity) {
        if (!(entity instanceof LivingEntity)) {
            return false;
        }
        LivingEntity livingEntity = (LivingEntity)entity;
        boolean ability = config.checkAbility() || CaelusApi.getInstance().canFly(livingEntity);
        boolean state = true;
        if (config.checkState()) {
            state = !livingEntity.m_20096_() && !livingEntity.m_21255_() && !livingEntity.m_20069_() && !livingEntity.m_21023_(MobEffects.f_19620_);
        }
        return ability && state;
    }
}

