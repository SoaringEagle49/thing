/*
 * Decompiled with CFR 0.152.
 */
package io.github.apace100.apoli.power.factory.action.meta;

public class IfElseAction {
}

