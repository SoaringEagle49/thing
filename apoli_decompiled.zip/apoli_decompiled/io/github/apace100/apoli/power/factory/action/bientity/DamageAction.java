/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.Entity
 *  org.jetbrains.annotations.NotNull
 */
package io.github.apace100.apoli.power.factory.action.bientity;

import io.github.apace100.apoli.util.MiscUtil;
import io.github.edwinmindcraft.apoli.api.power.factory.BiEntityAction;
import io.github.edwinmindcraft.apoli.common.action.configuration.DamageConfiguration;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import org.jetbrains.annotations.NotNull;

public class DamageAction
extends BiEntityAction<DamageConfiguration> {
    public DamageAction() {
        super(DamageConfiguration.CODEC);
    }

    @Override
    public void execute(@NotNull DamageConfiguration configuration, @NotNull Entity actor, @NotNull Entity target) {
        DamageSource source = MiscUtil.createDamageSource(actor.m_269291_(), configuration.source(), configuration.damageType(), actor);
        target.m_6469_(source, configuration.amount());
    }
}

