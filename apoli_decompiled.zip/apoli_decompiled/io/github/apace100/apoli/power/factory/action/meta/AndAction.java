/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.apace100.calio.data.SerializableData
 *  io.github.apace100.calio.data.SerializableData$Instance
 *  io.github.apace100.calio.data.SerializableDataType
 */
package io.github.apace100.apoli.power.factory.action.meta;

import io.github.apace100.apoli.Apoli;
import io.github.apace100.apoli.power.factory.action.ActionFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataType;
import java.util.List;

public class AndAction {
    public static <T> void action(SerializableData.Instance data, T t) {
        List actions = (List)data.get("actions");
        actions.forEach(a -> a.accept(t));
    }

    public static <T> ActionFactory<T> getFactory(SerializableDataType<List<ActionFactory.Instance>> listDataType) {
        return new ActionFactory<Object>(Apoli.identifier("and"), new SerializableData().add("actions", listDataType), AndAction::action);
    }
}

