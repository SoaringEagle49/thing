/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.phys.Vec3
 *  org.jetbrains.annotations.NotNull
 */
package io.github.apace100.apoli.power.factory.action.entity;

import io.github.apace100.apoli.action.configuration.SpawnParticlesConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;

public class SpawnParticlesAction
extends EntityAction<SpawnParticlesConfiguration> {
    public SpawnParticlesAction() {
        super(SpawnParticlesConfiguration.CODEC);
    }

    @Override
    public void execute(@NotNull SpawnParticlesConfiguration configuration, @NotNull Entity entity) {
        Level level;
        if (entity.m_9236_().m_5776_() || !((level = entity.m_9236_()) instanceof ServerLevel)) {
            return;
        }
        ServerLevel level2 = (ServerLevel)level;
        if (configuration.count() <= 0) {
            return;
        }
        Vec3 spread = configuration.spread();
        float deltaX = (float)((double)entity.m_20205_() * spread.m_7096_());
        float deltaY = (float)((double)entity.m_20206_() * spread.m_7098_());
        float deltaZ = (float)((double)entity.m_20205_() * spread.m_7094_());
        float offsetY = entity.m_20206_() * configuration.offsetY();
        level2.m_8767_(configuration.particle(), entity.m_20185_(), entity.m_20186_() + (double)offsetY, entity.m_20189_(), configuration.count(), (double)deltaX, (double)deltaY, (double)deltaZ, (double)configuration.speed());
    }
}

