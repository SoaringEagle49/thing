/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.phys.BlockHitResult
 *  net.minecraft.world.phys.EntityHitResult
 *  net.minecraft.world.phys.HitResult
 *  net.minecraft.world.phys.HitResult$Type
 *  org.jetbrains.annotations.NotNull
 */
package io.github.apace100.apoli.power.factory.condition.entity;

import io.github.apace100.apoli.condition.configuration.RaycastConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiEntityCondition;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBlockCondition;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityCondition;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import org.jetbrains.annotations.NotNull;

public class RaycastCondition
extends EntityCondition<RaycastConfiguration> {
    public RaycastCondition() {
        super(RaycastConfiguration.CODEC);
    }

    @Override
    protected boolean check(@NotNull RaycastConfiguration configuration, @NotNull Entity entity) {
        HitResult hitResult = configuration.settings().perform(entity, configuration.matchCondition());
        if (hitResult.m_6662_() == HitResult.Type.MISS) {
            return false;
        }
        if (hitResult instanceof BlockHitResult) {
            BlockHitResult bhr = (BlockHitResult)hitResult;
            if (configuration.blockCondition().m_203633_()) {
                return ConfiguredBlockCondition.check(configuration.blockCondition(), (LevelReader)entity.m_9236_(), bhr.m_82425_());
            }
        }
        if (hitResult instanceof EntityHitResult) {
            EntityHitResult ehr = (EntityHitResult)hitResult;
            if (configuration.hitCondition().m_203633_()) {
                return ((ConfiguredBiEntityCondition)configuration.hitCondition().m_203334_()).check(entity, ehr.m_82443_());
            }
        }
        return true;
    }
}

