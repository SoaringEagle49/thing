/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.apace100.calio.data.SerializableData
 *  io.github.apace100.calio.data.SerializableData$Instance
 *  io.github.apace100.calio.data.SerializableDataType
 *  io.github.apace100.calio.data.SerializableDataTypes
 */
package io.github.apace100.apoli.power.factory.action.meta;

import io.github.apace100.apoli.Apoli;
import io.github.apace100.apoli.power.factory.action.ActionFactory;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataType;
import io.github.apace100.calio.data.SerializableDataTypes;
import java.util.Random;

public class ChanceAction {
    public static <T> void action(SerializableData.Instance data, T t) {
        ActionFactory.Instance action = (ActionFactory.Instance)data.get("action");
        Random random = new Random();
        if (random.nextFloat() < data.getFloat("chance")) {
            action.accept(t);
        } else if (data.isPresent("fail_action")) {
            ActionFactory.Instance fail = (ActionFactory.Instance)data.get("fail_action");
            fail.accept(t);
        }
    }

    public static <T> ActionFactory<T> getFactory(SerializableDataType<ActionFactory.Instance> dataType) {
        return new ActionFactory<Object>(Apoli.identifier("chance"), new SerializableData().add("action", dataType).add("chance", SerializableDataTypes.FLOAT).add("fail_action", dataType, null), ChanceAction::action);
    }
}

