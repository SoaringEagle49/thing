/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.apace100.calio.data.SerializableData
 *  io.github.apace100.calio.data.SerializableData$Instance
 *  io.github.apace100.calio.data.SerializableDataType
 *  io.github.apace100.calio.data.SerializableDataTypes
 */
package io.github.apace100.apoli.power.factory.action.meta;

import io.github.apace100.apoli.Apoli;
import io.github.apace100.apoli.power.factory.action.ActionFactory;
import io.github.apace100.apoli.util.Scheduler;
import io.github.apace100.calio.data.SerializableData;
import io.github.apace100.calio.data.SerializableDataType;
import io.github.apace100.calio.data.SerializableDataTypes;

public class DelayAction {
    private static final Scheduler SCHEDULER = new Scheduler();

    public static <T> void action(SerializableData.Instance data, T t) {
        ActionFactory.Instance action = (ActionFactory.Instance)data.get("action");
        SCHEDULER.queue(s -> action.accept(t), data.getInt("ticks"));
    }

    public static <T> ActionFactory<T> getFactory(SerializableDataType<ActionFactory.Instance> dataType) {
        return new ActionFactory<Object>(Apoli.identifier("delay"), new SerializableData().add("ticks", SerializableDataTypes.INT).add("action", dataType), DelayAction::action);
    }
}

