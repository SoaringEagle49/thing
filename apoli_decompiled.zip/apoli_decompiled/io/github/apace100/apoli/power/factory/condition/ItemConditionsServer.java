/*
 * Decompiled with CFR 0.152.
 */
package io.github.apace100.apoli.power.factory.condition;

public class ItemConditionsServer {
    public static void register() {
    }
}

