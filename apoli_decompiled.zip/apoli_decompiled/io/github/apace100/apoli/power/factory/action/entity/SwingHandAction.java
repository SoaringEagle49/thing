/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 *  org.jetbrains.annotations.NotNull
 */
package io.github.apace100.apoli.power.factory.action.entity;

import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.configuration.FieldConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.jetbrains.annotations.NotNull;

public class SwingHandAction
extends EntityAction<FieldConfiguration<InteractionHand>> {
    public SwingHandAction() {
        super(FieldConfiguration.codec(SerializableDataTypes.HAND, "hand", InteractionHand.MAIN_HAND));
    }

    @Override
    public void execute(@NotNull FieldConfiguration<InteractionHand> configuration, @NotNull Entity entity) {
        if (entity instanceof LivingEntity) {
            LivingEntity living = (LivingEntity)entity;
            living.m_21011_(configuration.value(), true);
        }
    }
}

