/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Lifecycle
 *  io.github.edwinmindcraft.calio.api.CalioAPI
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 */
package io.github.apace100.apoli.power;

import com.mojang.serialization.Lifecycle;
import io.github.apace100.apoli.power.Power;
import io.github.apace100.apoli.power.PowerType;
import io.github.edwinmindcraft.apoli.api.ApoliAPI;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.apoli.api.registry.ApoliDynamicRegistries;
import io.github.edwinmindcraft.calio.api.CalioAPI;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;

public class PowerTypeRegistry {
    @Deprecated
    public static <T extends Power> PowerType<T> register(ResourceLocation id, PowerType<T> powerType) {
        CalioAPI.getDynamicRegistries().get(ApoliDynamicRegistries.CONFIGURED_POWER_KEY).m_255290_(ResourceKey.m_135785_(ApoliDynamicRegistries.CONFIGURED_POWER_KEY, (ResourceLocation)id), powerType.getConfiguredPower(), Lifecycle.experimental());
        return powerType;
    }

    @Deprecated
    protected static <T extends Power> PowerType<T> update(ResourceLocation id, PowerType<T> powerType) {
        CalioAPI.getDynamicRegistries().get(ApoliDynamicRegistries.CONFIGURED_POWER_KEY).m_255290_(ResourceKey.m_135785_(ApoliDynamicRegistries.CONFIGURED_POWER_KEY, (ResourceLocation)id), powerType.getConfiguredPower(), Lifecycle.experimental());
        return powerType;
    }

    public static int size() {
        return ApoliAPI.getPowers().m_6566_().size();
    }

    public static Stream<ResourceLocation> identifiers() {
        return ApoliAPI.getPowers().m_6566_().stream();
    }

    public static Iterable<Map.Entry<ResourceLocation, PowerType<?>>> entries() {
        return ApoliAPI.getPowers().m_6579_().stream().map(x -> Map.entry(((ResourceKey)x.getKey()).m_135782_(), ((ConfiguredPower)x.getValue()).getPowerType())).collect(Collectors.toSet());
    }

    public static Iterable<PowerType<?>> values() {
        return ApoliAPI.getPowers().m_123024_().map(ConfiguredPower::getPowerType).collect(Collectors.toSet());
    }

    public static PowerType<?> get(ResourceLocation id) {
        return ApoliAPI.getPowers().m_6612_(id).map(ConfiguredPower::getPowerType).orElseThrow(() -> new IllegalArgumentException("Could not get power type from id '" + id + "', as it was not registered!"));
    }

    public static ResourceLocation getId(PowerType<?> powerType) {
        return powerType.getIdentifier();
    }

    public static boolean contains(ResourceLocation id) {
        return ApoliAPI.getPowers().m_7804_(id);
    }

    public static void clear() {
    }

    public static void reset() {
        PowerTypeRegistry.clear();
    }
}

