/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.advancements.CriteriaTriggers
 *  net.minecraft.advancements.CriterionTrigger
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.fml.DistExecutor
 *  net.minecraftforge.fml.ModLoadingContext
 *  net.minecraftforge.fml.common.Mod
 *  net.minecraftforge.fml.config.IConfigSpec
 *  net.minecraftforge.fml.config.ModConfig$Type
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package io.github.apace100.apoli;

import io.github.apace100.apoli.ApoliClient;
import io.github.apace100.apoli.util.ApoliConfig;
import io.github.apace100.apoli.util.ApoliConfigs;
import io.github.apace100.apoli.util.GainedPowerCriterion;
import io.github.apace100.apoli.util.Scheduler;
import io.github.edwinmindcraft.apoli.common.ApoliCommon;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.advancements.CriterionTrigger;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.IConfigSpec;
import net.minecraftforge.fml.config.ModConfig;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(value="apoli")
public class Apoli {
    public static final Scheduler SCHEDULER = new Scheduler();
    public static final String MODID = "apoli";
    public static final Logger LOGGER = LogManager.getLogger(Apoli.class);
    public static final boolean PERFORM_VERSION_CHECK = false;
    public static ApoliConfig config;

    public static ResourceLocation identifier(String path) {
        return new ResourceLocation(MODID, path);
    }

    public Apoli() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, (IConfigSpec)ApoliConfigs.COMMON_SPECS);
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, (IConfigSpec)ApoliConfigs.CLIENT_SPECS);
        ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, (IConfigSpec)ApoliConfigs.SERVER_SPECS);
        CriteriaTriggers.m_10595_((CriterionTrigger)GainedPowerCriterion.INSTANCE);
        ApoliCommon.initialize();
        DistExecutor.unsafeRunWhenOn((Dist)Dist.CLIENT, () -> ApoliClient::initialize);
        LOGGER.info("Apoli " + ModLoadingContext.get().getActiveContainer().getModInfo().getVersion() + " has initialized. Ready to power up your game!");
    }
}

