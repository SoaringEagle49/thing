/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.commands.arguments.SlotArgument
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.gen.Accessor
 */
package io.github.apace100.apoli.mixin;

import java.util.Map;
import net.minecraft.commands.arguments.SlotArgument;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={SlotArgument.class})
public interface ItemSlotArgumentTypeAccessor {
    @Accessor(value="SLOTS")
    public Map<String, Integer> getSlotNamesToSlotCommandId();
}

