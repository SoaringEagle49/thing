/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.renderer.LightTexture
 *  net.minecraft.world.entity.Entity
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.ModifyVariable
 */
package io.github.apace100.apoli.mixin;

import io.github.edwinmindcraft.apoli.api.power.INightVisionPower;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@OnlyIn(value=Dist.CLIENT)
@Mixin(value={LightTexture.class})
public abstract class LightmapTextureManagerMixin
implements AutoCloseable {
    @Shadow
    @Final
    private Minecraft f_109876_;

    @ModifyVariable(method={"updateLightTexture"}, at=@At(value="STORE"), ordinal=7)
    private float nightVisionPowerEffect(float value) {
        return INightVisionPower.getNightVisionStrength((Entity)this.f_109876_.f_91074_).map(x -> Float.valueOf(Math.max(x.floatValue(), value))).orElse(Float.valueOf(value)).floatValue();
    }
}

