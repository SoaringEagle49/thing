/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.renderer.chunk.RenderChunkRegion
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Holder
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.level.material.FluidState
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  net.minecraftforge.common.util.NonNullSupplier
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package io.github.apace100.apoli.mixin;

import com.google.common.collect.ImmutableList;
import io.github.edwinmindcraft.apoli.api.component.IPowerContainer;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.apoli.common.power.ModifyBlockRenderPower;
import io.github.edwinmindcraft.apoli.common.power.ModifyFluidRenderPower;
import io.github.edwinmindcraft.apoli.common.power.configuration.ModifyBlockRenderConfiguration;
import io.github.edwinmindcraft.apoli.common.power.configuration.ModifyFluidRenderConfiguration;
import io.github.edwinmindcraft.apoli.common.registry.ApoliPowers;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.chunk.RenderChunkRegion;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.common.util.NonNullSupplier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@OnlyIn(value=Dist.CLIENT)
@Mixin(value={RenderChunkRegion.class})
public abstract class ChunkRendererRegionMixin {
    @Unique
    private List<ConfiguredPower<ModifyBlockRenderConfiguration, ModifyBlockRenderPower>> apoli$blockRender;
    @Unique
    private List<ConfiguredPower<ModifyFluidRenderConfiguration, ModifyFluidRenderPower>> apoli$fluidRender;

    @Shadow
    public abstract BlockState m_8055_(BlockPos var1);

    @Inject(method={"getBlockState"}, at={@At(value="RETURN")}, cancellable=true)
    private void modifyBlockRender(BlockPos pos, CallbackInfoReturnable<BlockState> cir) {
        Minecraft client = Minecraft.m_91087_();
        if (client.f_91073_ != null && client.f_91074_ != null) {
            if (this.apoli$blockRender == null) {
                this.apoli$blockRender = (List)IPowerContainer.getPowers((Entity)client.f_91074_, (ModifyBlockRenderPower)ApoliPowers.MODIFY_BLOCK_RENDER.get()).stream().filter(Holder::m_203633_).map(Holder::m_203334_).collect(ImmutableList.toImmutableList());
            }
            if (this.apoli$blockRender.isEmpty()) {
                return;
            }
            this.apoli$blockRender.stream().filter(x -> ((ModifyBlockRenderPower)x.getFactory()).check((ConfiguredPower<ModifyBlockRenderConfiguration, ?>)x, (LevelReader)client.f_91073_, pos, (NonNullSupplier<BlockState>)((NonNullSupplier)() -> ((CallbackInfoReturnable)cir).getReturnValue()))).map(x -> ((ModifyBlockRenderConfiguration)x.getConfiguration()).block().m_49966_()).findFirst().ifPresent(arg_0 -> cir.setReturnValue(arg_0));
        }
    }

    @Inject(method={"getFluidState"}, at={@At(value="RETURN")}, cancellable=true)
    private void modifyFluidRender(BlockPos pos, CallbackInfoReturnable<FluidState> cir) {
        Minecraft client = Minecraft.m_91087_();
        if (client.f_91073_ != null && client.f_91074_ != null) {
            if (this.apoli$fluidRender == null) {
                this.apoli$fluidRender = (List)IPowerContainer.getPowers((Entity)client.f_91074_, (ModifyFluidRenderPower)ApoliPowers.MODIFY_FLUID_RENDER.get()).stream().filter(Holder::m_203633_).map(Holder::m_203334_).collect(ImmutableList.toImmutableList());
            }
            if (this.apoli$fluidRender.isEmpty()) {
                return;
            }
            this.apoli$fluidRender.stream().filter(x -> ((ModifyFluidRenderPower)x.getFactory()).check((ConfiguredPower<ModifyFluidRenderConfiguration, ?>)x, (LevelReader)client.f_91073_, pos, (NonNullSupplier<BlockState>)((NonNullSupplier)() -> this.m_8055_(pos)), (FluidState)cir.getReturnValue())).map(x -> ((ModifyFluidRenderConfiguration)x.getConfiguration()).fluid().m_76145_()).findFirst().ifPresent(arg_0 -> cir.setReturnValue(arg_0));
        }
    }
}

