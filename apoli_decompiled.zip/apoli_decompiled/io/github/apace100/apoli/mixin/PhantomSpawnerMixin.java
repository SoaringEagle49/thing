/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.util.RandomSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.level.levelgen.PhantomSpawner
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.ModifyArg
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 *  org.spongepowered.asm.mixin.injection.callback.LocalCapture
 */
package io.github.apace100.apoli.mixin;

import io.github.edwinmindcraft.apoli.api.ApoliAPI;
import io.github.edwinmindcraft.apoli.api.component.IPowerContainer;
import io.github.edwinmindcraft.apoli.api.power.factory.PowerFactory;
import io.github.edwinmindcraft.apoli.common.power.ModifyValuePower;
import io.github.edwinmindcraft.apoli.common.registry.ApoliPowers;
import java.util.Iterator;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.levelgen.PhantomSpawner;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(value={PhantomSpawner.class})
public class PhantomSpawnerMixin {
    @Unique
    private Player apoli$cachedPlayer;

    @Inject(method={"tick"}, at={@At(value="INVOKE", target="Lnet/minecraft/world/level/dimension/DimensionType;hasSkyLight()Z", ordinal=1)}, locals=LocalCapture.CAPTURE_FAILHARD)
    private void cachePlayerEntity(ServerLevel world, boolean spawnMonsters, boolean spawnAnimals, CallbackInfoReturnable<Integer> cir, RandomSource random, int i, Iterator var6, ServerPlayer player, BlockPos blockpos) {
        this.apoli$cachedPlayer = player;
    }

    @ModifyArg(method={"tick"}, at=@At(value="INVOKE", target="Lnet/minecraft/util/Mth;clamp(III)I"), index=0)
    private int modifyTicks(int original) {
        if (ApoliAPI.getPowerContainer((Entity)this.apoli$cachedPlayer).hasPower((PowerFactory)ApoliPowers.MODIFY_INSONMIA_TICKS.get())) {
            return (int)IPowerContainer.modify((Entity)this.apoli$cachedPlayer, (ModifyValuePower)ApoliPowers.MODIFY_INSONMIA_TICKS.get(), original);
        }
        return original;
    }
}

