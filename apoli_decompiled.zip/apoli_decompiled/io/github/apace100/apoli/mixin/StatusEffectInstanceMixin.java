/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.effect.MobEffectInstance
 *  org.jetbrains.annotations.Nullable
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 */
package io.github.apace100.apoli.mixin;

import io.github.apace100.apoli.access.HiddenEffectStatus;
import net.minecraft.world.effect.MobEffectInstance;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(value={MobEffectInstance.class})
public class StatusEffectInstanceMixin
implements HiddenEffectStatus {
    @Shadow
    @Nullable
    private MobEffectInstance f_19510_;

    @Override
    @Nullable
    public MobEffectInstance getHiddenEffect() {
        return this.f_19510_;
    }
}

