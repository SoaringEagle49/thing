/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.damagesource.DamageSource
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.ModifyVariable
 */
package io.github.apace100.apoli.mixin;

import io.github.apace100.apoli.access.NameMutableDamageSource;
import net.minecraft.world.damagesource.DamageSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(value={DamageSource.class})
public class DamageSourceMixin
implements NameMutableDamageSource {
    @Unique
    private String apoli$mutableName;

    @Override
    public void setName(String name) {
        this.apoli$mutableName = name;
    }

    @ModifyVariable(method={"getLocalizedDeathMessage"}, at=@At(value="FIELD", opcode=180, target="Lnet/minecraft/world/damagesource/DamageSource;causingEntity:Lnet/minecraft/world/entity/Entity;", ordinal=0))
    private String apoli$modifyDeathMessageString(String value) {
        if (this.apoli$mutableName != null) {
            return "death.attack." + this.apoli$mutableName;
        }
        return value;
    }
}

