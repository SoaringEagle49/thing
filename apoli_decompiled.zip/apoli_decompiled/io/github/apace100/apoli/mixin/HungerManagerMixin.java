/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.protocol.Packet
 *  net.minecraft.network.protocol.game.ClientboundSetHealthPacket
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.food.FoodData
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.ItemStack
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.At$Shift
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package io.github.apace100.apoli.mixin;

import io.github.apace100.apoli.access.ModifiableFoodEntity;
import io.github.edwinmindcraft.apoli.common.power.ModifyFoodPower;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundSetHealthPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.food.FoodData;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={FoodData.class})
public class HungerManagerMixin {
    @Shadow
    private int f_38696_;
    @Shadow
    private float f_38697_;

    @Inject(method={"eat(Lnet/minecraft/world/item/Item;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/LivingEntity;)V"}, at={@At(value="INVOKE", target="Lnet/minecraft/world/food/FoodData;eat(IF)V", shift=At.Shift.AFTER)})
    private void executeAdditionalEatAction(Item item, ItemStack stack, LivingEntity living, CallbackInfo ci) {
        if (living instanceof ModifiableFoodEntity) {
            ModifiableFoodEntity mfe = (ModifiableFoodEntity)living;
            ModifyFoodPower.execute(mfe.getCurrentModifyFoodPowers(), (Entity)living, living.m_9236_(), stack);
            if (mfe.shouldSyncFood() && !living.m_9236_().m_5776_() && living instanceof ServerPlayer) {
                ServerPlayer sp = (ServerPlayer)living;
                sp.f_8906_.m_9829_((Packet)new ClientboundSetHealthPacket(living.m_21223_(), this.f_38696_, this.f_38697_));
                mfe.resetFoodSync();
            }
        }
    }
}

