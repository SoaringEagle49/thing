/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResultHolder
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.BlockItem
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Redirect
 */
package io.github.apace100.apoli.mixin;

import io.github.edwinmindcraft.apoli.common.power.PreventItemActionPower;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value={BlockItem.class})
public class BlockItemMixin {
    @Redirect(method={"useOn"}, at=@At(value="INVOKE", target="Lnet/minecraft/world/item/BlockItem;use(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder;"))
    private InteractionResultHolder<ItemStack> preventItemUseIfBlockItem(BlockItem blockItem, Level world, Player user, InteractionHand hand) {
        ItemStack stackInHand;
        if (user != null && PreventItemActionPower.isUsagePrevented((Entity)user, stackInHand = user.m_21120_(hand))) {
            return InteractionResultHolder.m_19100_((Object)stackInHand);
        }
        return blockItem.m_7203_(world, user, hand);
    }
}

