/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.level.biome.Biome
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 */
package io.github.apace100.apoli.mixin;

import io.github.apace100.apoli.access.BiomeWeatherAccess;
import net.minecraft.world.level.biome.Biome;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(value={Biome.class})
public class BiomeMixin
implements BiomeWeatherAccess {
    @Unique
    private float apoli$downfall;

    @Override
    public float getDownfall() {
        return this.apoli$downfall;
    }

    @Override
    public void setDownfall(float downfall) {
        this.apoli$downfall = downfall;
    }
}

