/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.level.storage.loot.LootContext
 *  net.minecraft.world.level.storage.loot.LootContext$Builder
 *  net.minecraft.world.level.storage.loot.LootParams
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package io.github.apace100.apoli.mixin;

import io.github.apace100.apoli.access.ReplacingLootContext;
import io.github.apace100.apoli.access.ReplacingLootContextParameterSet;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.LootParams;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={LootContext.Builder.class})
public class LootContextBuilderMixin {
    @Shadow
    @Final
    private LootParams f_78956_;

    @Inject(method={"create"}, at={@At(value="RETURN")})
    private void setLootContextType(CallbackInfoReturnable<LootContext> cir) {
        ReplacingLootContextParameterSet rlcps = (ReplacingLootContextParameterSet)this.f_78956_;
        ReplacingLootContext rlc = (ReplacingLootContext)cir.getReturnValue();
        rlc.setType(rlcps.getType());
    }
}

