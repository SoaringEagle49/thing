/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Holder
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResultHolder
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.SlotAccess
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.inventory.ClickAction
 *  net.minecraft.world.inventory.Slot
 *  net.minecraft.world.item.Item
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 *  net.minecraftforge.common.capabilities.CapabilityProvider
 *  org.apache.commons.lang3.mutable.Mutable
 *  org.apache.commons.lang3.mutable.MutableObject
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.Redirect
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package io.github.apace100.apoli.mixin;

import io.github.apace100.apoli.access.EntityLinkedItemStack;
import io.github.edwinmindcraft.apoli.api.ApoliAPI;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.apoli.common.power.ActionOnItemUsePower;
import io.github.edwinmindcraft.apoli.common.power.ItemOnItemPower;
import io.github.edwinmindcraft.apoli.common.power.configuration.ActionOnItemUseConfiguration;
import io.github.edwinmindcraft.apoli.common.registry.ApoliCapabilities;
import io.github.edwinmindcraft.apoli.common.registry.ApoliPowers;
import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.SlotAccess;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickAction;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.capabilities.CapabilityProvider;
import org.apache.commons.lang3.mutable.Mutable;
import org.apache.commons.lang3.mutable.MutableObject;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={ItemStack.class})
public abstract class ItemStackMixin
extends CapabilityProvider<ItemStack> {
    @Shadow
    public abstract int m_41779_();

    @Shadow
    public abstract InteractionResultHolder<ItemStack> m_41682_(Level var1, Player var2, InteractionHand var3);

    protected ItemStackMixin(Class<ItemStack> baseClass) {
        super(baseClass);
    }

    @Inject(method={"overrideOtherStackedOnMe"}, at={@At(value="RETURN")}, cancellable=true)
    public void forgeItem(ItemStack other, Slot slot, ClickAction pAction, Player pPlayer, SlotAccess otherAccess, CallbackInfoReturnable<Boolean> cir) {
        if (((Boolean)cir.getReturnValue()).booleanValue()) {
            return;
        }
        if (pAction != ClickAction.SECONDARY) {
            return;
        }
        if (ItemOnItemPower.execute((Entity)pPlayer, slot, otherAccess)) {
            cir.setReturnValue((Object)true);
        }
    }

    @Redirect(method={"use"}, at=@At(value="INVOKE", target="Lnet/minecraft/world/item/ItemStack;getItem()Lnet/minecraft/world/item/Item;"))
    private Item callActionOnUseInstantBefore(ItemStack original, Level world, Player user, InteractionHand hand) {
        if (ApoliAPI.getPowerContainer((Entity)user) != null && ApoliAPI.getPowerContainer((Entity)user).getPowers((ActionOnItemUsePower)ApoliPowers.ACTION_ON_ITEM_USE.get()).stream().anyMatch(p -> p.m_203633_() && ((ActionOnItemUsePower)((ConfiguredPower)p.m_203334_()).getFactory()).canRun((Holder<ConfiguredPower<ActionOnItemUseConfiguration, ActionOnItemUsePower>>)p, (Entity)user, (ItemStack)this, this.m_41779_() == 0 ? ActionOnItemUseConfiguration.TriggerType.INSTANT : ActionOnItemUseConfiguration.TriggerType.START, ActionOnItemUseConfiguration.PriorityPhase.BEFORE))) {
            MutableObject mutable = new MutableObject((Object)original);
            ActionOnItemUsePower.execute((Entity)user, original, (Mutable<ItemStack>)mutable, this.m_41779_() == 0 ? ActionOnItemUseConfiguration.TriggerType.INSTANT : ActionOnItemUseConfiguration.TriggerType.START, ActionOnItemUseConfiguration.PriorityPhase.BEFORE);
            return ((ItemStack)mutable.getValue()).m_41720_();
        }
        return original.m_41720_();
    }

    @Inject(method={"copy"}, at={@At(value="RETURN")})
    private void copyNewParams(CallbackInfoReturnable<ItemStack> cir) {
        ((ItemStack)cir.getReturnValue()).getCapability(ApoliCapabilities.ENTITY_LINKED_ITEM_STACK).ifPresent(eli -> {
            Optional otherEli = this.getCapability(ApoliCapabilities.ENTITY_LINKED_ITEM_STACK).resolve();
            if (otherEli.isPresent() && ((EntityLinkedItemStack)otherEli.get()).getEntity() != null) {
                eli.setEntity(((EntityLinkedItemStack)otherEli.get()).getEntity());
            }
        });
    }

    @Inject(method={"use"}, at={@At(value="RETURN")}, cancellable=true)
    private void callActionOnUseInstantAfter(Level world, Player user, InteractionHand hand, CallbackInfoReturnable<InteractionResultHolder<ItemStack>> cir) {
        if (((InteractionResultHolder)cir.getReturnValue()).m_19089_().m_19077_() && ApoliAPI.getPowerContainer((Entity)user) != null && ApoliAPI.getPowerContainer((Entity)user).getPowers((ActionOnItemUsePower)ApoliPowers.ACTION_ON_ITEM_USE.get()).stream().anyMatch(p -> p.m_203633_() && ((ActionOnItemUsePower)((ConfiguredPower)p.m_203334_()).getFactory()).canRun((Holder<ConfiguredPower<ActionOnItemUseConfiguration, ActionOnItemUsePower>>)p, (Entity)user, (ItemStack)this, this.m_41779_() == 0 ? ActionOnItemUseConfiguration.TriggerType.INSTANT : ActionOnItemUseConfiguration.TriggerType.START, ActionOnItemUseConfiguration.PriorityPhase.AFTER))) {
            MutableObject mutable = new MutableObject((Object)((ItemStack)((InteractionResultHolder)cir.getReturnValue()).m_19095_()));
            ActionOnItemUsePower.execute((Entity)user, (ItemStack)((InteractionResultHolder)cir.getReturnValue()).m_19095_(), (Mutable<ItemStack>)mutable, this.m_41779_() == 0 ? ActionOnItemUseConfiguration.TriggerType.INSTANT : ActionOnItemUseConfiguration.TriggerType.START, ActionOnItemUseConfiguration.PriorityPhase.AFTER);
            cir.setReturnValue((Object)new InteractionResultHolder(((InteractionResultHolder)cir.getReturnValue()).m_19089_(), (Object)((ItemStack)mutable.getValue())));
        }
    }
}

