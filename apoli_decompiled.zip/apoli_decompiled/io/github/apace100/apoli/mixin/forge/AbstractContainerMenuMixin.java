/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.NonNullList
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.inventory.AbstractContainerMenu
 *  net.minecraft.world.inventory.ClickType
 *  net.minecraft.world.inventory.CraftingContainer
 *  net.minecraft.world.inventory.ResultSlot
 *  net.minecraft.world.inventory.Slot
 *  net.minecraft.world.inventory.TransientCraftingContainer
 *  net.minecraft.world.item.ItemStack
 *  org.apache.commons.lang3.mutable.Mutable
 *  org.apache.commons.lang3.mutable.MutableObject
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.ModifyArg
 *  org.spongepowered.asm.mixin.injection.ModifyVariable
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package io.github.apace100.apoli.mixin.forge;

import io.github.apace100.apoli.access.PowerCraftingInventory;
import io.github.apace100.apoli.access.PowerModifiedGrindstone;
import io.github.apace100.apoli.mixin.forge.ResultSlotAccessor;
import io.github.apace100.apoli.util.ModifiedCraftingRecipe;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.apoli.common.power.ModifyGrindstonePower;
import io.github.edwinmindcraft.apoli.common.power.configuration.ModifyCraftingConfiguration;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.inventory.ResultSlot;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.TransientCraftingContainer;
import net.minecraft.world.item.ItemStack;
import org.apache.commons.lang3.mutable.Mutable;
import org.apache.commons.lang3.mutable.MutableObject;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={AbstractContainerMenu.class})
public class AbstractContainerMenuMixin {
    @Shadow
    @Final
    public NonNullList<Slot> f_38839_;
    @Unique
    private int apoli$cachedMouseX;
    @Unique
    private Player apoli$cachedPlayer;

    @Inject(method={"doClick"}, at={@At(value="HEAD")})
    private void cacheMouseX(int pMouseX, int pMouseY, ClickType pClickType, Player pPlayer, CallbackInfo ci) {
        this.apoli$cachedMouseX = pMouseX;
        this.apoli$cachedPlayer = pPlayer;
    }

    @ModifyVariable(method={"doClick"}, at=@At(value="STORE", ordinal=0), ordinal=0)
    private Optional<ItemStack> handleGrindstoneLateActionsSet(Optional<ItemStack> original) {
        if (original.isPresent()) {
            ResultSlot slot2;
            CraftingContainer craftingContainer;
            AbstractContainerMenu abstractContainerMenu = (AbstractContainerMenu)this;
            if (abstractContainerMenu instanceof PowerModifiedGrindstone) {
                PowerModifiedGrindstone pmg = (PowerModifiedGrindstone)abstractContainerMenu;
                if (this.apoli$cachedMouseX == 2) {
                    MutableObject newStack = new MutableObject((Object)original.get().m_41777_());
                    ModifyGrindstonePower.tryLateExecute(pmg.getAppliedPowers(), (Entity)pmg.getPlayer(), (Mutable<ItemStack>)newStack, pmg.getPos());
                    return Optional.of((ItemStack)newStack.getValue());
                }
            }
            if (!this.apoli$cachedPlayer.m_9236_().f_46443_ && this.f_38839_.stream().anyMatch(slot -> slot instanceof ResultSlot) && (craftingContainer = ((ResultSlotAccessor)(slot2 = (ResultSlot)this.f_38839_.stream().filter(s -> s instanceof ResultSlot).findFirst().get())).getCraftSlots()) instanceof TransientCraftingContainer) {
                Object obj;
                PowerCraftingInventory pci;
                ConfiguredPower<?, ?> power;
                TransientCraftingContainer craftingContainer2 = (TransientCraftingContainer)craftingContainer;
                craftingContainer = ((ResultSlotAccessor)slot2).getCraftSlots();
                if (craftingContainer instanceof PowerCraftingInventory && (power = (pci = (PowerCraftingInventory)craftingContainer).getPower()) != null && (obj = power.getConfiguration()) instanceof ModifyCraftingConfiguration) {
                    ModifyCraftingConfiguration config = (ModifyCraftingConfiguration)obj;
                    Optional<BlockPos> blockPos = ModifiedCraftingRecipe.getBlockFromInventory(craftingContainer2);
                    config.execute((Entity)this.apoli$cachedPlayer, blockPos.orElse(null));
                    MutableObject newStack = new MutableObject((Object)original.get().m_41777_());
                    config.executeAfterCraftingAction(this.apoli$cachedPlayer.m_9236_(), (Mutable<ItemStack>)newStack);
                    return Optional.of((ItemStack)newStack.getValue());
                }
            }
        }
        return original;
    }

    @ModifyVariable(method={"doClick"}, at=@At(value="STORE", ordinal=1), ordinal=0)
    private Optional<ItemStack> handleGrindstoneLateActionsGrow(Optional<ItemStack> original) {
        ResultSlot slot2;
        CraftingContainer craftingContainer;
        AbstractContainerMenu abstractContainerMenu;
        if (original.isPresent() && (abstractContainerMenu = (AbstractContainerMenu)this) instanceof PowerModifiedGrindstone) {
            PowerModifiedGrindstone pmg = (PowerModifiedGrindstone)abstractContainerMenu;
            if (this.apoli$cachedMouseX == 2) {
                MutableObject newStack = new MutableObject((Object)original.get().m_41777_());
                ModifyGrindstonePower.tryLateExecute(pmg.getAppliedPowers(), (Entity)pmg.getPlayer(), (Mutable<ItemStack>)newStack, pmg.getPos());
                return Optional.of((ItemStack)newStack.getValue());
            }
        }
        if (!this.apoli$cachedPlayer.m_9236_().f_46443_ && this.f_38839_.stream().anyMatch(slot -> slot instanceof ResultSlot) && (craftingContainer = ((ResultSlotAccessor)(slot2 = (ResultSlot)this.f_38839_.stream().filter(s -> s instanceof ResultSlot).findFirst().get())).getCraftSlots()) instanceof TransientCraftingContainer) {
            Object obj;
            PowerCraftingInventory pci;
            ConfiguredPower<?, ?> power;
            TransientCraftingContainer craftingContainer2 = (TransientCraftingContainer)craftingContainer;
            craftingContainer = ((ResultSlotAccessor)slot2).getCraftSlots();
            if (craftingContainer instanceof PowerCraftingInventory && (power = (pci = (PowerCraftingInventory)craftingContainer).getPower()) != null && (obj = power.getConfiguration()) instanceof ModifyCraftingConfiguration) {
                ModifyCraftingConfiguration config = (ModifyCraftingConfiguration)obj;
                Optional<BlockPos> blockPos = ModifiedCraftingRecipe.getBlockFromInventory(craftingContainer2);
                config.execute((Entity)this.apoli$cachedPlayer, blockPos.orElse(null));
                MutableObject newStack = new MutableObject((Object)original.get().m_41777_());
                config.executeAfterCraftingAction(this.apoli$cachedPlayer.m_9236_(), (Mutable<ItemStack>)newStack);
                return Optional.of((ItemStack)newStack.getValue());
            }
        }
        return original;
    }

    @ModifyVariable(method={"doClick"}, at=@At(value="STORE", ordinal=2), ordinal=1)
    private ItemStack handleGrindstoneLateActionsSwap(ItemStack original) {
        ResultSlot slot2;
        CraftingContainer craftingContainer;
        AbstractContainerMenu abstractContainerMenu = (AbstractContainerMenu)this;
        if (abstractContainerMenu instanceof PowerModifiedGrindstone) {
            PowerModifiedGrindstone pmg = (PowerModifiedGrindstone)abstractContainerMenu;
            if (this.apoli$cachedMouseX == 2) {
                MutableObject newStack = new MutableObject((Object)original.m_41777_());
                ModifyGrindstonePower.tryLateExecute(pmg.getAppliedPowers(), (Entity)pmg.getPlayer(), (Mutable<ItemStack>)newStack, pmg.getPos());
                return (ItemStack)newStack.getValue();
            }
        }
        if (!this.apoli$cachedPlayer.m_9236_().f_46443_ && this.f_38839_.stream().anyMatch(slot -> slot instanceof ResultSlot) && (craftingContainer = ((ResultSlotAccessor)(slot2 = (ResultSlot)this.f_38839_.stream().filter(s -> s instanceof ResultSlot).findFirst().get())).getCraftSlots()) instanceof TransientCraftingContainer) {
            Object obj;
            PowerCraftingInventory pci;
            ConfiguredPower<?, ?> power;
            TransientCraftingContainer craftingContainer2 = (TransientCraftingContainer)craftingContainer;
            craftingContainer = ((ResultSlotAccessor)slot2).getCraftSlots();
            if (craftingContainer instanceof PowerCraftingInventory && (power = (pci = (PowerCraftingInventory)craftingContainer).getPower()) != null && (obj = power.getConfiguration()) instanceof ModifyCraftingConfiguration) {
                ModifyCraftingConfiguration config = (ModifyCraftingConfiguration)obj;
                Optional<BlockPos> blockPos = ModifiedCraftingRecipe.getBlockFromInventory(craftingContainer2);
                config.execute((Entity)this.apoli$cachedPlayer, blockPos.orElse(null));
                MutableObject newStack = new MutableObject((Object)original.m_41777_());
                config.executeAfterCraftingAction(this.apoli$cachedPlayer.m_9236_(), (Mutable<ItemStack>)newStack);
                return (ItemStack)newStack.getValue();
            }
        }
        return original;
    }

    @ModifyArg(method={"doClick"}, at=@At(value="INVOKE", target="Lnet/minecraft/world/item/ItemStack;isSameItemSameTags(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemStack;)Z", ordinal=0), index=0)
    private ItemStack checkForSameTagsWithNewContextInsert(ItemStack original) {
        ResultSlot slot2;
        CraftingContainer craftingContainer;
        AbstractContainerMenu abstractContainerMenu = (AbstractContainerMenu)this;
        if (abstractContainerMenu instanceof PowerModifiedGrindstone) {
            PowerModifiedGrindstone pmg = (PowerModifiedGrindstone)abstractContainerMenu;
            if (this.apoli$cachedMouseX == 2) {
                MutableObject newStack = new MutableObject((Object)original.m_41777_());
                ModifyGrindstonePower.tryLateExecute(pmg.getAppliedPowers(), (Entity)pmg.getPlayer(), (Mutable<ItemStack>)newStack, pmg.getPos());
                return (ItemStack)newStack.getValue();
            }
        }
        if (!this.apoli$cachedPlayer.m_9236_().f_46443_ && this.f_38839_.stream().anyMatch(slot -> slot instanceof ResultSlot) && (craftingContainer = ((ResultSlotAccessor)(slot2 = (ResultSlot)this.f_38839_.stream().filter(s -> s instanceof ResultSlot).findFirst().get())).getCraftSlots()) instanceof TransientCraftingContainer) {
            Object obj;
            PowerCraftingInventory pci;
            ConfiguredPower<?, ?> power;
            TransientCraftingContainer craftingContainer2 = (TransientCraftingContainer)craftingContainer;
            craftingContainer = ((ResultSlotAccessor)slot2).getCraftSlots();
            if (craftingContainer instanceof PowerCraftingInventory && (power = (pci = (PowerCraftingInventory)craftingContainer).getPower()) != null && (obj = power.getConfiguration()) instanceof ModifyCraftingConfiguration) {
                ModifyCraftingConfiguration config = (ModifyCraftingConfiguration)obj;
                Optional<BlockPos> blockPos = ModifiedCraftingRecipe.getBlockFromInventory(craftingContainer2);
                config.execute((Entity)this.apoli$cachedPlayer, blockPos.orElse(null));
                MutableObject newStack = new MutableObject((Object)original.m_41777_());
                config.executeAfterCraftingAction(this.apoli$cachedPlayer.m_9236_(), (Mutable<ItemStack>)newStack);
                return (ItemStack)newStack.getValue();
            }
        }
        return original;
    }

    @ModifyArg(method={"doClick"}, at=@At(value="INVOKE", target="Lnet/minecraft/world/item/ItemStack;isSameItemSameTags(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemStack;)Z", ordinal=1), index=0)
    private ItemStack checkForSameTagsWithNewContextGrow(ItemStack original) {
        ResultSlot slot2;
        CraftingContainer craftingContainer;
        AbstractContainerMenu abstractContainerMenu = (AbstractContainerMenu)this;
        if (abstractContainerMenu instanceof PowerModifiedGrindstone) {
            PowerModifiedGrindstone pmg = (PowerModifiedGrindstone)abstractContainerMenu;
            if (this.apoli$cachedMouseX == 2) {
                MutableObject newStack = new MutableObject((Object)original.m_41777_());
                ModifyGrindstonePower.tryLateExecute(pmg.getAppliedPowers(), (Entity)pmg.getPlayer(), (Mutable<ItemStack>)newStack, pmg.getPos());
                return (ItemStack)newStack.getValue();
            }
        }
        if (!this.apoli$cachedPlayer.m_9236_().f_46443_ && this.f_38839_.stream().anyMatch(slot -> slot instanceof ResultSlot) && (craftingContainer = ((ResultSlotAccessor)(slot2 = (ResultSlot)this.f_38839_.stream().filter(s -> s instanceof ResultSlot).findFirst().get())).getCraftSlots()) instanceof TransientCraftingContainer) {
            Object obj;
            PowerCraftingInventory pci;
            ConfiguredPower<?, ?> power;
            TransientCraftingContainer craftingContainer2 = (TransientCraftingContainer)craftingContainer;
            craftingContainer = ((ResultSlotAccessor)slot2).getCraftSlots();
            if (craftingContainer instanceof PowerCraftingInventory && (power = (pci = (PowerCraftingInventory)craftingContainer).getPower()) != null && (obj = power.getConfiguration()) instanceof ModifyCraftingConfiguration) {
                ModifyCraftingConfiguration config = (ModifyCraftingConfiguration)obj;
                Optional<BlockPos> blockPos = ModifiedCraftingRecipe.getBlockFromInventory(craftingContainer2);
                config.execute((Entity)this.apoli$cachedPlayer, blockPos.orElse(null));
                MutableObject newStack = new MutableObject((Object)original.m_41777_());
                config.executeAfterCraftingAction(this.apoli$cachedPlayer.m_9236_(), (Mutable<ItemStack>)newStack);
                return (ItemStack)newStack.getValue();
            }
        }
        return original;
    }
}

