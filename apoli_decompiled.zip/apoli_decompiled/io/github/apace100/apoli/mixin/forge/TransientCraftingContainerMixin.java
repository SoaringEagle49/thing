/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.world.inventory.TransientCraftingContainer
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 */
package io.github.apace100.apoli.mixin.forge;

import io.github.apace100.apoli.access.PowerCraftingInventory;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import javax.annotation.Nullable;
import net.minecraft.world.inventory.TransientCraftingContainer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(value={TransientCraftingContainer.class})
public class TransientCraftingContainerMixin
implements PowerCraftingInventory {
    @Unique
    private ConfiguredPower<?, ?> apoli$cachedPower;

    @Override
    public void setPower(ConfiguredPower<?, ?> power) {
        this.apoli$cachedPower = power;
    }

    @Override
    @Nullable
    public ConfiguredPower<?, ?> getPower() {
        return this.apoli$cachedPower;
    }
}

