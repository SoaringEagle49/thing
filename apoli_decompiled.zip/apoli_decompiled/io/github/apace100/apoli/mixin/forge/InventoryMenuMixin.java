/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.inventory.CraftingContainer
 *  net.minecraft.world.inventory.InventoryMenu
 *  net.minecraft.world.inventory.TransientCraftingContainer
 *  net.minecraft.world.item.ItemStack
 *  org.apache.commons.lang3.mutable.Mutable
 *  org.apache.commons.lang3.mutable.MutableObject
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.ModifyVariable
 */
package io.github.apace100.apoli.mixin.forge;

import io.github.apace100.apoli.access.PowerCraftingInventory;
import io.github.apace100.apoli.util.ModifiedCraftingRecipe;
import io.github.edwinmindcraft.apoli.common.power.configuration.ModifyCraftingConfiguration;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.inventory.TransientCraftingContainer;
import net.minecraft.world.item.ItemStack;
import org.apache.commons.lang3.mutable.Mutable;
import org.apache.commons.lang3.mutable.MutableObject;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(value={InventoryMenu.class})
public class InventoryMenuMixin {
    @Shadow
    @Final
    public Player f_39703_;
    @Shadow
    @Final
    private CraftingContainer f_39701_;

    @ModifyVariable(method={"quickMoveStack"}, at=@At(value="INVOKE", target="Lnet/minecraft/world/item/ItemStack;copy()Lnet/minecraft/world/item/ItemStack;"), ordinal=1)
    private ItemStack modifyOutputItems(ItemStack stack) {
        Object object = this.f_39701_;
        if (object instanceof TransientCraftingContainer) {
            PowerCraftingInventory pci;
            TransientCraftingContainer craftingContainer = (TransientCraftingContainer)object;
            if (!this.f_39703_.m_9236_().f_46443_ && (object = this.f_39701_) instanceof PowerCraftingInventory && (pci = (PowerCraftingInventory)object).getPower() != null && (object = pci.getPower().getConfiguration()) instanceof ModifyCraftingConfiguration) {
                ModifyCraftingConfiguration config = (ModifyCraftingConfiguration)object;
                Optional<BlockPos> blockPos = ModifiedCraftingRecipe.getBlockFromInventory(craftingContainer);
                MutableObject newStack = new MutableObject((Object)stack);
                config.execute((Entity)this.f_39703_, blockPos.orElse(null));
                config.executeAfterCraftingAction(this.f_39703_.m_9236_(), (Mutable<ItemStack>)newStack);
                return (ItemStack)newStack.getValue();
            }
        }
        return stack;
    }
}

