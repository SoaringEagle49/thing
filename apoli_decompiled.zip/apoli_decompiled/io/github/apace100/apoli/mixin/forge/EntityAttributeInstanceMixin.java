/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.ai.attributes.Attribute
 *  net.minecraft.world.entity.ai.attributes.AttributeInstance
 *  net.minecraftforge.common.ForgeMod
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package io.github.apace100.apoli.mixin.forge;

import io.github.apace100.apoli.access.EntityAttributeInstanceAccess;
import io.github.edwinmindcraft.apoli.api.component.IPowerContainer;
import io.github.edwinmindcraft.apoli.common.power.ModifyFallingPower;
import io.github.edwinmindcraft.apoli.common.registry.ApoliPowers;
import javax.annotation.Nullable;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraftforge.common.ForgeMod;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={AttributeInstance.class})
public abstract class EntityAttributeInstanceMixin
implements EntityAttributeInstanceAccess {
    @Shadow
    @Final
    private Attribute f_22088_;
    @Unique
    @Nullable
    private Entity apoli$entity;

    @Override
    public void setEntity(Entity entity) {
        this.apoli$entity = entity;
    }

    @Override
    @Nullable
    public Entity getEntity() {
        return this.apoli$entity;
    }

    @Inject(method={"getValue"}, at={@At(value="RETURN")}, cancellable=true)
    private void apoli$modifyAttributeValue(CallbackInfoReturnable<Double> cir) {
        if (this.apoli$entity != null && this.f_22088_ == ForgeMod.ENTITY_GRAVITY.get() && this.apoli$entity.m_20184_().f_82480_ <= 0.0 && IPowerContainer.hasPower(this.apoli$entity, (ModifyFallingPower)ApoliPowers.MODIFY_FALLING.get())) {
            double original = cir.getReturnValueD();
            cir.setReturnValue((Object)ModifyFallingPower.apply(this.apoli$entity, original));
        }
    }
}

