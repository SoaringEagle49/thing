/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.Gui
 *  net.minecraft.client.renderer.entity.ItemRenderer
 *  net.minecraft.core.Holder
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.Entity
 *  net.minecraftforge.client.gui.overlay.ForgeGui
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.ModifyArg
 */
package io.github.apace100.apoli.mixin.forge;

import io.github.edwinmindcraft.apoli.api.component.IPowerContainer;
import io.github.edwinmindcraft.apoli.api.configuration.FieldConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.apoli.common.power.OverrideHudTexturePower;
import io.github.edwinmindcraft.apoli.common.registry.ApoliPowers;
import java.util.Optional;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(value={ForgeGui.class})
public abstract class ForgeGuiMixin
extends Gui {
    public ForgeGuiMixin(Minecraft minecraft, ItemRenderer itemRenderer) {
        super(minecraft, itemRenderer);
    }

    @ModifyArg(method={"renderArmor"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/gui/GuiGraphics;blit(Lnet/minecraft/resources/ResourceLocation;IIIIII)V"), index=0)
    public ResourceLocation changeArmorBarTextures(ResourceLocation original) {
        Optional<Holder> first;
        if (Gui.f_279580_.equals((Object)original) && (first = IPowerContainer.getPowers((Entity)this.f_92986_.f_91074_, (OverrideHudTexturePower)ApoliPowers.STATUS_BAR_TEXTURE.get()).stream().filter(Holder::m_203633_).findFirst()).isPresent()) {
            return ((Optional)((FieldConfiguration)((ConfiguredPower)first.get().m_203334_()).getConfiguration()).value()).orElse(original);
        }
        return original;
    }

    @ModifyArg(method={"renderAir"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/gui/GuiGraphics;blit(Lnet/minecraft/resources/ResourceLocation;IIIIII)V"), index=0)
    public ResourceLocation changeAirBarTextures(ResourceLocation original) {
        Optional<Holder> first;
        if (Gui.f_279580_.equals((Object)original) && (first = IPowerContainer.getPowers((Entity)this.f_92986_.f_91074_, (OverrideHudTexturePower)ApoliPowers.STATUS_BAR_TEXTURE.get()).stream().filter(Holder::m_203633_).findFirst()).isPresent()) {
            return ((Optional)((FieldConfiguration)((ConfiguredPower)first.get().m_203334_()).getConfiguration()).value()).orElse(original);
        }
        return original;
    }

    @ModifyArg(method={"renderFood"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/gui/GuiGraphics;blit(Lnet/minecraft/resources/ResourceLocation;IIIIII)V"), index=0)
    public ResourceLocation changeFoodBarTextures(ResourceLocation original) {
        Optional<Holder> first;
        if (Gui.f_279580_.equals((Object)original) && (first = IPowerContainer.getPowers((Entity)this.f_92986_.f_91074_, (OverrideHudTexturePower)ApoliPowers.STATUS_BAR_TEXTURE.get()).stream().filter(Holder::m_203633_).findFirst()).isPresent()) {
            return ((Optional)((FieldConfiguration)((ConfiguredPower)first.get().m_203334_()).getConfiguration()).value()).orElse(original);
        }
        return original;
    }

    @ModifyArg(method={"renderHealthMount"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/gui/GuiGraphics;blit(Lnet/minecraft/resources/ResourceLocation;IIIIII)V"), index=0)
    public ResourceLocation changeHealthMountBarTextures(ResourceLocation original) {
        Optional<Holder> first;
        if (Gui.f_279580_.equals((Object)original) && (first = IPowerContainer.getPowers((Entity)this.f_92986_.f_91074_, (OverrideHudTexturePower)ApoliPowers.STATUS_BAR_TEXTURE.get()).stream().filter(Holder::m_203633_).findFirst()).isPresent()) {
            return ((Optional)((FieldConfiguration)((ConfiguredPower)first.get().m_203334_()).getConfiguration()).value()).orElse(original);
        }
        return original;
    }
}

