/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 *  top.theillusivec4.caelus.common.CaelusApiImpl
 */
package io.github.apace100.apoli.mixin.forge;

import io.github.edwinmindcraft.apoli.common.power.EntityActionPower;
import io.github.edwinmindcraft.apoli.common.registry.ApoliPowers;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import top.theillusivec4.caelus.common.CaelusApiImpl;

@Mixin(value={CaelusApiImpl.class})
public class CaelusMixin {
    @Inject(method={"canFly"}, at={@At(value="HEAD")}, cancellable=true, remap=false)
    public void elytraFlightHook(LivingEntity living, CallbackInfoReturnable<Boolean> cir) {
        if (EntityActionPower.execute((EntityActionPower)ApoliPowers.PREVENT_ELYTRA_FLIGHT.get(), (Entity)living)) {
            cir.setReturnValue((Object)false);
        }
    }
}

