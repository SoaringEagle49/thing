/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.renderer.LevelRenderer
 *  net.minecraft.world.entity.Entity
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Redirect
 */
package io.github.apace100.apoli.mixin.forge;

import io.github.edwinmindcraft.apoli.common.power.EntityGlowPower;
import io.github.edwinmindcraft.apoli.common.power.configuration.ColorConfiguration;
import java.util.Optional;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@OnlyIn(value=Dist.CLIENT)
@Mixin(value={LevelRenderer.class})
public class ChangeGlowColorMixin {
    @Shadow
    @Final
    private Minecraft f_109461_;

    @Redirect(method={"renderLevel"}, at=@At(value="INVOKE", target="Lnet/minecraft/world/entity/Entity;getTeamColor()I"))
    private int setColors(Entity instance) {
        if (this.f_109461_.m_91288_() == null) {
            return instance.m_19876_();
        }
        Optional<ColorConfiguration> glowColor = EntityGlowPower.getGlowColor(this.f_109461_.m_91288_(), instance);
        return glowColor.map(ColorConfiguration::asRGB).orElseGet(() -> ((Entity)instance).m_19876_());
    }
}

