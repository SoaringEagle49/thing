/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  org.jetbrains.annotations.Nullable
 */
package io.github.apace100.apoli.action.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.util.ResourceOperation;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import java.util.Optional;
import org.jetbrains.annotations.Nullable;

public record ModifyBlockStateConfiguration(String property, ResourceOperation operation, @Nullable Integer change, @Nullable Boolean value, @Nullable String enumValue, boolean cycle) implements IDynamicFeatureConfiguration
{
    public static final Codec<ModifyBlockStateConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)Codec.STRING.fieldOf("property").forGetter(ModifyBlockStateConfiguration::property), (App)CalioCodecHelper.optionalField(ApoliDataTypes.RESOURCE_OPERATION, (String)"operation", (Object)((Object)ResourceOperation.ADD)).forGetter(ModifyBlockStateConfiguration::operation), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.INT, (String)"change").forGetter(x -> Optional.ofNullable(x.change())), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.BOOL, (String)"value").forGetter(x -> Optional.ofNullable(x.value())), (App)CalioCodecHelper.optionalField((Codec)Codec.STRING, (String)"enum").forGetter(x -> Optional.ofNullable(x.enumValue())), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.BOOL, (String)"change", (Object)false).forGetter(ModifyBlockStateConfiguration::cycle)).apply((Applicative)instance, (t1, t2, t3, t4, t5, t6) -> new ModifyBlockStateConfiguration((String)t1, (ResourceOperation)((Object)((Object)t2)), t3.orElse(null), t4.orElse(null), t5.orElse(null), (boolean)t6)));
}

