/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.MapCodec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  javax.annotation.Nullable
 *  net.minecraft.core.Holder
 */
package io.github.apace100.apoli.action.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.apoli.configuration.RaycastSettingsConfiguration;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiEntityAction;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiEntityCondition;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBlockAction;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredEntityAction;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.core.Holder;

public record RaycastConfiguration(RaycastSettingsConfiguration settings, Holder<ConfiguredEntityAction<?, ?>> beforeAction, Holder<ConfiguredBiEntityCondition<?, ?>> biEntityCondition, CommandInfo commandInfo, HitAction action) implements IDynamicFeatureConfiguration
{
    public static final Codec<RaycastConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)RaycastSettingsConfiguration.MAP_CODEC.forGetter(RaycastConfiguration::settings), (App)ConfiguredEntityAction.optional("before_action").forGetter(RaycastConfiguration::beforeAction), (App)ConfiguredBiEntityCondition.optional("bientity_condition").forGetter(RaycastConfiguration::biEntityCondition), (App)CommandInfo.MAP_CODEC.forGetter(RaycastConfiguration::commandInfo), (App)HitAction.MAP_CODEC.forGetter(RaycastConfiguration::action)).apply((Applicative)instance, RaycastConfiguration::new));

    public record CommandInfo(@Nullable String commandAtHit, @Nullable Double commandHitOffset, @Nullable String commandAlongRay, double commandStep, boolean commandAlongRayOnlyOnHit) implements IDynamicFeatureConfiguration
    {
        private static final MapCodec<CommandInfo> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group((App)CalioCodecHelper.optionalField((Codec)Codec.STRING, (String)"command_at_hit").forGetter(x -> Optional.ofNullable(x.commandAtHit())), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.DOUBLE, (String)"command_hit_offset").forGetter(x -> Optional.ofNullable(x.commandHitOffset())), (App)CalioCodecHelper.optionalField((Codec)Codec.STRING, (String)"command_along_ray").forGetter(x -> Optional.ofNullable(x.commandAlongRay())), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.DOUBLE, (String)"command_step", (Object)1.0).forGetter(CommandInfo::commandStep), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.BOOL, (String)"command_along_ray_only_on_hit", (Object)false).forGetter(CommandInfo::commandAlongRayOnlyOnHit)).apply((Applicative)instance, (t1, t2, t3, t4, t5) -> new CommandInfo(t1.orElse(null), t2.orElse(null), t3.orElse(null), (double)t4, (boolean)t5)));
    }

    public record HitAction(Holder<ConfiguredBlockAction<?, ?>> blockAction, Holder<ConfiguredEntityAction<?, ?>> hitAction, Holder<ConfiguredEntityAction<?, ?>> missAction, Holder<ConfiguredBiEntityAction<?, ?>> biEntityAction) implements IDynamicFeatureConfiguration
    {
        private static final MapCodec<HitAction> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group((App)ConfiguredBlockAction.optional("block_action").forGetter(HitAction::blockAction), (App)ConfiguredEntityAction.optional("hit_action").forGetter(HitAction::hitAction), (App)ConfiguredEntityAction.optional("miss_action").forGetter(HitAction::missAction), (App)ConfiguredBiEntityAction.optional("bientity_action").forGetter(HitAction::biEntityAction)).apply((Applicative)instance, HitAction::new));
    }
}

