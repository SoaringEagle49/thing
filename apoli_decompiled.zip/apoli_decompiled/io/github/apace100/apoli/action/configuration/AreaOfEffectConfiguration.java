/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.MapCodec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataType
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.core.Holder
 */
package io.github.apace100.apoli.action.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.apoli.util.Shape;
import io.github.apace100.calio.data.SerializableDataType;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.ConfiguredCondition;
import io.github.edwinmindcraft.apoli.api.power.ConfiguredFactory;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import net.minecraft.core.Holder;

public record AreaOfEffectConfiguration<A extends ConfiguredFactory<?, ?, ?>, C extends ConfiguredCondition<?, ?, ?>>(double radius, Holder<A> action, Holder<C> condition, Shape shape, boolean includeTarget) implements IDynamicFeatureConfiguration
{
    public static <A extends ConfiguredFactory<?, ?, ?>, C extends ConfiguredCondition<?, ?, ?>> Codec<AreaOfEffectConfiguration<A, C>> createCodec(MapCodec<Holder<A>> actionCodec, MapCodec<Holder<C>> conditionCodec) {
        return RecordCodecBuilder.create(instance -> instance.group((App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.DOUBLE, (String)"radius", (Object)16.0).forGetter(AreaOfEffectConfiguration::radius), (App)actionCodec.forGetter(AreaOfEffectConfiguration::action), (App)conditionCodec.forGetter(AreaOfEffectConfiguration::condition), (App)CalioCodecHelper.optionalField((Codec)SerializableDataType.enumValue(Shape.class), (String)"shape", (Object)((Object)Shape.CUBE)).forGetter(AreaOfEffectConfiguration::shape), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.BOOL, (String)"include_target", (Object)false).forGetter(AreaOfEffectConfiguration::includeTarget)).apply((Applicative)instance, AreaOfEffectConfiguration::new));
    }
}

