/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.Mth
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.phys.AABB
 *  net.minecraft.world.phys.Vec3
 *  org.jetbrains.annotations.NotNull
 */
package io.github.apace100.apoli.action.entity;

import io.github.apace100.apoli.action.configuration.AreaOfEffectConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiEntityAction;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiEntityCondition;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;

public class AreaOfEffectAction
extends EntityAction<AreaOfEffectConfiguration<ConfiguredBiEntityAction<?, ?>, ConfiguredBiEntityCondition<?, ?>>> {
    public AreaOfEffectAction() {
        super(AreaOfEffectConfiguration.createCodec(ConfiguredBiEntityAction.required("bientity_action"), ConfiguredBiEntityCondition.optional("bientity_condition")));
    }

    @Override
    public void execute(@NotNull AreaOfEffectConfiguration<ConfiguredBiEntityAction<?, ?>, ConfiguredBiEntityCondition<?, ?>> configuration, @NotNull Entity entity) {
        double diameter = configuration.radius() * 2.0;
        for (Entity check : entity.m_9236_().m_45976_(Entity.class, AABB.m_165882_((Vec3)entity.m_20318_(1.0f), (double)diameter, (double)diameter, (double)diameter))) {
            if (check == entity && !configuration.includeTarget() || !ConfiguredBiEntityCondition.check(configuration.condition(), entity, check) || !(check.m_20280_(entity) < Mth.m_144952_((double)configuration.radius()))) continue;
            ((ConfiguredBiEntityAction)configuration.action().m_203334_()).execute(entity, check);
        }
    }
}

