/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.network.chat.Component
 *  net.minecraft.stats.Stats
 *  net.minecraft.world.MenuProvider
 *  net.minecraft.world.SimpleMenuProvider
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.inventory.ContainerLevelAccess
 *  net.minecraft.world.inventory.CraftingMenu
 *  net.minecraft.world.level.Level
 */
package io.github.apace100.apoli.action.entity;

import io.github.edwinmindcraft.apoli.common.action.entity.SimpleEntityAction;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.stats.Stats;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.CraftingMenu;
import net.minecraft.world.level.Level;

public class CraftingTableAction
extends SimpleEntityAction {
    private static final Component TITLE = Component.m_237115_((String)"container.crafting");

    public static void action(Entity entity) {
        if (!(entity instanceof Player)) {
            return;
        }
        Player player = (Player)entity;
        player.m_5893_((MenuProvider)new SimpleMenuProvider((syncId, inventory, _player) -> new CraftingMenu(syncId, inventory, ContainerLevelAccess.m_39289_((Level)_player.m_9236_(), (BlockPos)_player.m_20183_())), TITLE));
        player.m_36220_(Stats.f_12967_);
    }

    public CraftingTableAction() {
        super(CraftingTableAction::action);
    }
}

