/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.chat.Component
 *  net.minecraft.stats.Stats
 *  net.minecraft.world.Container
 *  net.minecraft.world.MenuProvider
 *  net.minecraft.world.SimpleMenuProvider
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Inventory
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.inventory.ChestMenu
 *  net.minecraft.world.inventory.PlayerEnderChestContainer
 */
package io.github.apace100.apoli.action.entity;

import io.github.edwinmindcraft.apoli.common.action.entity.SimpleEntityAction;
import net.minecraft.network.chat.Component;
import net.minecraft.stats.Stats;
import net.minecraft.world.Container;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.PlayerEnderChestContainer;

public class EnderChestAction
extends SimpleEntityAction {
    private static final Component TITLE = Component.m_237115_((String)"container.enderchest");

    public static void action(Entity entity) {
        if (!(entity instanceof Player)) {
            return;
        }
        Player player = (Player)entity;
        PlayerEnderChestContainer enderChestInventory = player.m_36327_();
        player.m_5893_((MenuProvider)new SimpleMenuProvider((syncId, inventory, _player) -> ChestMenu.m_39237_((int)syncId, (Inventory)inventory, (Container)enderChestInventory), TITLE));
        player.m_36220_(Stats.f_12963_);
    }

    public EnderChestAction() {
        super(EnderChestAction::action);
    }
}

