/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.world.item.BoneMealItem
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.BlockGetter
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.block.state.BlockState
 *  org.jetbrains.annotations.NotNull
 */
package io.github.apace100.apoli.action.block;

import io.github.edwinmindcraft.apoli.api.configuration.FieldConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.BlockAction;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.NotNull;

public class BonemealAction
extends BlockAction<FieldConfiguration<Boolean>> {
    public BonemealAction() {
        super(FieldConfiguration.codec(CalioCodecHelper.BOOL, "effects", true));
    }

    @Override
    public void execute(@NotNull FieldConfiguration<Boolean> configuration, @NotNull Level world, @NotNull BlockPos pos, @NotNull Direction direction) {
        BlockPos blockPos2 = pos.m_121945_(direction);
        boolean spawnEffects = configuration.value();
        if (BoneMealItem.m_40627_((ItemStack)ItemStack.f_41583_, (Level)world, (BlockPos)pos)) {
            if (spawnEffects && !world.m_5776_()) {
                world.m_6798_(1505, pos, 0);
            }
        } else {
            BlockState blockState = world.m_8055_(pos);
            boolean bl = blockState.m_60783_((BlockGetter)world, pos, direction);
            if (bl && BoneMealItem.m_40631_((ItemStack)ItemStack.f_41583_, (Level)world, (BlockPos)blockPos2, (Direction)direction) && spawnEffects && !world.m_5776_()) {
                world.m_6798_(1505, blockPos2, 0);
            }
        }
    }
}

