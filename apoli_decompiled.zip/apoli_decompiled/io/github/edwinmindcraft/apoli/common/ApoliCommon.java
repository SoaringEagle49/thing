/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.edwinmindcraft.calio.api.event.CalioDynamicRegistryEvent$Initialize
 *  io.github.edwinmindcraft.calio.api.registry.DynamicEntryFactory
 *  io.github.edwinmindcraft.calio.api.registry.DynamicEntryValidator
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.common.crafting.CraftingHelper
 *  net.minecraftforge.common.crafting.conditions.IConditionSerializer
 *  net.minecraftforge.eventbus.api.IEventBus
 *  net.minecraftforge.eventbus.api.SubscribeEvent
 *  net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent
 *  net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext
 *  net.minecraftforge.network.NetworkDirection
 *  net.minecraftforge.network.NetworkRegistry$ChannelBuilder
 *  net.minecraftforge.network.simple.SimpleChannel
 */
package io.github.edwinmindcraft.apoli.common;

import io.github.apace100.apoli.Apoli;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiEntityAction;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiEntityCondition;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiomeCondition;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBlockAction;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBlockCondition;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredDamageCondition;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredEntityAction;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredEntityCondition;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredFluidCondition;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredItemAction;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredItemCondition;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredModifier;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.apoli.api.registry.ApoliBuiltinRegistries;
import io.github.edwinmindcraft.apoli.api.registry.ApoliDynamicRegistries;
import io.github.edwinmindcraft.apoli.common.data.GlobalPowerSetLoader;
import io.github.edwinmindcraft.apoli.common.data.PowerLoader;
import io.github.edwinmindcraft.apoli.common.global.GlobalPowerSet;
import io.github.edwinmindcraft.apoli.common.network.C2SFetchActiveSpawnPowerPacket;
import io.github.edwinmindcraft.apoli.common.network.C2SUseActivePowers;
import io.github.edwinmindcraft.apoli.common.network.S2CActiveSpawnPowerPacket;
import io.github.edwinmindcraft.apoli.common.network.S2CCachedSpawnsPacket;
import io.github.edwinmindcraft.apoli.common.network.S2CPlayerDismount;
import io.github.edwinmindcraft.apoli.common.network.S2CPlayerMount;
import io.github.edwinmindcraft.apoli.common.network.S2CResetSpawnCachePacket;
import io.github.edwinmindcraft.apoli.common.network.S2CSyncAttacker;
import io.github.edwinmindcraft.apoli.common.network.S2CSynchronizePowerContainer;
import io.github.edwinmindcraft.apoli.common.registry.ApoliArgumentTypes;
import io.github.edwinmindcraft.apoli.common.registry.ApoliDynamicRegisters;
import io.github.edwinmindcraft.apoli.common.registry.ApoliLootConditions;
import io.github.edwinmindcraft.apoli.common.registry.ApoliLootFunctions;
import io.github.edwinmindcraft.apoli.common.registry.ApoliModifierOperations;
import io.github.edwinmindcraft.apoli.common.registry.ApoliPowers;
import io.github.edwinmindcraft.apoli.common.registry.ApoliRecipeSerializers;
import io.github.edwinmindcraft.apoli.common.registry.ApoliRegisters;
import io.github.edwinmindcraft.apoli.common.registry.action.ApoliBiEntityActions;
import io.github.edwinmindcraft.apoli.common.registry.action.ApoliBlockActions;
import io.github.edwinmindcraft.apoli.common.registry.action.ApoliDefaultActions;
import io.github.edwinmindcraft.apoli.common.registry.action.ApoliEntityActions;
import io.github.edwinmindcraft.apoli.common.registry.action.ApoliItemActions;
import io.github.edwinmindcraft.apoli.common.registry.condition.ApoliBiEntityConditions;
import io.github.edwinmindcraft.apoli.common.registry.condition.ApoliBiomeConditions;
import io.github.edwinmindcraft.apoli.common.registry.condition.ApoliBlockConditions;
import io.github.edwinmindcraft.apoli.common.registry.condition.ApoliDamageConditions;
import io.github.edwinmindcraft.apoli.common.registry.condition.ApoliDefaultConditions;
import io.github.edwinmindcraft.apoli.common.registry.condition.ApoliEntityConditions;
import io.github.edwinmindcraft.apoli.common.registry.condition.ApoliFluidConditions;
import io.github.edwinmindcraft.apoli.common.registry.condition.ApoliItemConditions;
import io.github.edwinmindcraft.apoli.common.util.AllNamespacesLoadedCondition;
import io.github.edwinmindcraft.apoli.common.util.AnyNamespacesLoadedCondition;
import io.github.edwinmindcraft.apoli.compat.ApoliCompat;
import io.github.edwinmindcraft.calio.api.event.CalioDynamicRegistryEvent;
import io.github.edwinmindcraft.calio.api.registry.DynamicEntryFactory;
import io.github.edwinmindcraft.calio.api.registry.DynamicEntryValidator;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.common.crafting.CraftingHelper;
import net.minecraftforge.common.crafting.conditions.IConditionSerializer;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class ApoliCommon {
    public static final String NETWORK_VERSION = "1.3";
    public static final SimpleChannel CHANNEL = NetworkRegistry.ChannelBuilder.named((ResourceLocation)Apoli.identifier("channel")).networkProtocolVersion(() -> "1.3").clientAcceptedVersions("1.3"::equals).serverAcceptedVersions("1.3"::equals).simpleChannel();
    public static final ResourceLocation POWER_SOURCE = Apoli.identifier("power_source");

    private static void initializeNetwork() {
        int messageId = 0;
        CHANNEL.messageBuilder(C2SUseActivePowers.class, messageId++, NetworkDirection.PLAY_TO_SERVER).encoder(C2SUseActivePowers::encode).decoder(C2SUseActivePowers::decode).consumerNetworkThread(C2SUseActivePowers::handle).add();
        CHANNEL.messageBuilder(S2CSynchronizePowerContainer.class, messageId++, NetworkDirection.PLAY_TO_CLIENT).encoder(S2CSynchronizePowerContainer::encode).decoder(S2CSynchronizePowerContainer::decode).consumerNetworkThread(S2CSynchronizePowerContainer::handle).add();
        CHANNEL.messageBuilder(S2CPlayerDismount.class, messageId++, NetworkDirection.PLAY_TO_CLIENT).encoder(S2CPlayerDismount::encode).decoder(S2CPlayerDismount::decode).consumerNetworkThread(S2CPlayerDismount::handle).add();
        CHANNEL.messageBuilder(S2CPlayerMount.class, messageId++, NetworkDirection.PLAY_TO_CLIENT).encoder(S2CPlayerMount::encode).decoder(S2CPlayerMount::decode).consumerNetworkThread(S2CPlayerMount::handle).add();
        CHANNEL.messageBuilder(S2CSyncAttacker.class, messageId++, NetworkDirection.PLAY_TO_CLIENT).encoder(S2CSyncAttacker::encode).decoder(S2CSyncAttacker::decode).consumerNetworkThread(S2CSyncAttacker::handle).add();
        CHANNEL.messageBuilder(S2CCachedSpawnsPacket.class, messageId++, NetworkDirection.PLAY_TO_CLIENT).encoder(S2CCachedSpawnsPacket::encode).decoder(S2CCachedSpawnsPacket::decode).consumerNetworkThread(S2CCachedSpawnsPacket::handle).add();
        CHANNEL.messageBuilder(S2CActiveSpawnPowerPacket.class, messageId++, NetworkDirection.PLAY_TO_CLIENT).encoder(S2CActiveSpawnPowerPacket::encode).decoder(S2CActiveSpawnPowerPacket::decode).consumerNetworkThread(S2CActiveSpawnPowerPacket::handle).add();
        CHANNEL.messageBuilder(C2SFetchActiveSpawnPowerPacket.class, messageId++, NetworkDirection.PLAY_TO_SERVER).encoder(C2SFetchActiveSpawnPowerPacket::encode).decoder(C2SFetchActiveSpawnPowerPacket::decode).consumerNetworkThread(C2SFetchActiveSpawnPowerPacket::handle).add();
        CHANNEL.messageBuilder(S2CResetSpawnCachePacket.class, messageId++, NetworkDirection.PLAY_TO_CLIENT).encoder(S2CResetSpawnCachePacket::encode).decoder(S2CResetSpawnCachePacket::decode).consumerNetworkThread(S2CResetSpawnCachePacket::handle).add();
        Apoli.LOGGER.debug("Registered {} newtork messages.", (Object)messageId);
    }

    public static void initialize() {
        ApoliRegisters.initialize();
        ApoliDynamicRegisters.initialize();
        ApoliRecipeSerializers.bootstrap();
        ApoliArgumentTypes.bootstrap();
        ApoliPowers.bootstrap();
        ApoliLootFunctions.bootstrap();
        ApoliLootConditions.bootstrap();
        ApoliBlockActions.bootstrap();
        ApoliEntityActions.bootstrap();
        ApoliItemActions.bootstrap();
        ApoliBiEntityActions.bootstrap();
        ApoliBiomeConditions.bootstrap();
        ApoliBlockConditions.bootstrap();
        ApoliDamageConditions.bootstrap();
        ApoliEntityConditions.bootstrap();
        ApoliFluidConditions.bootstrap();
        ApoliItemConditions.bootstrap();
        ApoliBiEntityConditions.bootstrap();
        ApoliModifierOperations.bootstrap();
        ApoliDefaultActions.bootstrap();
        ApoliDefaultConditions.bootstrap();
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        bus.addListener(ApoliCommon::commonSetup);
        bus.addListener(ApoliCommon::initalizeDynamicRegistries);
    }

    public static void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(ApoliArgumentTypes::initialize);
        ApoliCompat.apply();
        ApoliCommon.initializeNetwork();
        CraftingHelper.register((IConditionSerializer)AnyNamespacesLoadedCondition.Serializer.INSTANCE);
        CraftingHelper.register((IConditionSerializer)AllNamespacesLoadedCondition.Serializer.INSTANCE);
    }

    @SubscribeEvent
    public static void initalizeDynamicRegistries(CalioDynamicRegistryEvent.Initialize event) {
        event.getRegistryManager().addForge(ApoliDynamicRegistries.CONFIGURED_POWER_KEY, ApoliBuiltinRegistries.CONFIGURED_POWERS, ConfiguredPower.CODEC);
        event.getRegistryManager().addForge(ApoliDynamicRegistries.GLOBAL_POWER_SET, ApoliBuiltinRegistries.GLOBAL_POWER_SET, GlobalPowerSet.CODEC);
        event.getRegistryManager().addForge(ApoliDynamicRegistries.CONFIGURED_BIENTITY_ACTION_KEY, ApoliBuiltinRegistries.CONFIGURED_BIENTITY_ACTIONS, ConfiguredBiEntityAction.CODEC);
        event.getRegistryManager().addForge(ApoliDynamicRegistries.CONFIGURED_BLOCK_ACTION_KEY, ApoliBuiltinRegistries.CONFIGURED_BLOCK_ACTIONS, ConfiguredBlockAction.CODEC);
        event.getRegistryManager().addForge(ApoliDynamicRegistries.CONFIGURED_ENTITY_ACTION_KEY, ApoliBuiltinRegistries.CONFIGURED_ENTITY_ACTIONS, ConfiguredEntityAction.CODEC);
        event.getRegistryManager().addForge(ApoliDynamicRegistries.CONFIGURED_ITEM_ACTION_KEY, ApoliBuiltinRegistries.CONFIGURED_ITEM_ACTIONS, ConfiguredItemAction.CODEC);
        event.getRegistryManager().addForge(ApoliDynamicRegistries.CONFIGURED_BIENTITY_CONDITION_KEY, ApoliBuiltinRegistries.CONFIGURED_BIENTITY_CONDITIONS, ConfiguredBiEntityCondition.CODEC);
        event.getRegistryManager().addForge(ApoliDynamicRegistries.CONFIGURED_BIOME_CONDITION_KEY, ApoliBuiltinRegistries.CONFIGURED_BIOME_CONDITIONS, ConfiguredBiomeCondition.CODEC);
        event.getRegistryManager().addForge(ApoliDynamicRegistries.CONFIGURED_BLOCK_CONDITION_KEY, ApoliBuiltinRegistries.CONFIGURED_BLOCK_CONDITIONS, ConfiguredBlockCondition.CODEC);
        event.getRegistryManager().addForge(ApoliDynamicRegistries.CONFIGURED_DAMAGE_CONDITION_KEY, ApoliBuiltinRegistries.CONFIGURED_DAMAGE_CONDITIONS, ConfiguredDamageCondition.CODEC);
        event.getRegistryManager().addForge(ApoliDynamicRegistries.CONFIGURED_ENTITY_CONDITION_KEY, ApoliBuiltinRegistries.CONFIGURED_ENTITY_CONDITIONS, ConfiguredEntityCondition.CODEC);
        event.getRegistryManager().addForge(ApoliDynamicRegistries.CONFIGURED_FLUID_CONDITION_KEY, ApoliBuiltinRegistries.CONFIGURED_FLUID_CONDITIONS, ConfiguredFluidCondition.CODEC);
        event.getRegistryManager().addForge(ApoliDynamicRegistries.CONFIGURED_ITEM_CONDITION_KEY, ApoliBuiltinRegistries.CONFIGURED_ITEM_CONDITIONS, ConfiguredItemCondition.CODEC);
        event.getRegistryManager().addForge(ApoliDynamicRegistries.CONFIGURED_MODIFIER_KEY, ApoliBuiltinRegistries.CONFIGURED_MODIFIERS, ConfiguredModifier.CODEC);
        event.getRegistryManager().addReload(ApoliDynamicRegistries.CONFIGURED_POWER_KEY, "powers", (DynamicEntryFactory)PowerLoader.INSTANCE);
        event.getRegistryManager().addValidation(ApoliDynamicRegistries.CONFIGURED_POWER_KEY, (DynamicEntryValidator)PowerLoader.INSTANCE, ApoliBuiltinRegistries.CONFIGURED_POWER_CLASS, new ResourceKey[0]);
        event.getRegistryManager().addReload(ApoliDynamicRegistries.GLOBAL_POWER_SET, "global_powers", (DynamicEntryFactory)GlobalPowerSetLoader.INSTANCE);
        event.getRegistryManager().addValidation(ApoliDynamicRegistries.GLOBAL_POWER_SET, (DynamicEntryValidator)GlobalPowerSetLoader.INSTANCE, new ResourceKey[]{ApoliDynamicRegistries.CONFIGURED_POWER_KEY});
    }
}

