/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  net.minecraft.core.Holder
 */
package io.github.edwinmindcraft.apoli.common.condition.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.apoli.util.Comparison;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.configuration.IntegerComparisonConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBlockCondition;
import net.minecraft.core.Holder;

public record InBlockAnywhereConfiguration(Holder<ConfiguredBlockCondition<?, ?>> blockCondition, IntegerComparisonConfiguration comparison) implements IDynamicFeatureConfiguration
{
    public static final Codec<InBlockAnywhereConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)ConfiguredBlockCondition.required("block_condition").forGetter(InBlockAnywhereConfiguration::blockCondition), (App)IntegerComparisonConfiguration.withDefaults(Comparison.GREATER_THAN_OR_EQUAL, 1).forGetter(InBlockAnywhereConfiguration::comparison)).apply((Applicative)instance, InBlockAnywhereConfiguration::new));

    public InBlockAnywhereConfiguration(ConfiguredBlockCondition<?, ?> condition) {
        this(Holder.m_205709_(condition), new IntegerComparisonConfiguration(Comparison.GREATER_THAN_OR_EQUAL, 1));
    }
}

