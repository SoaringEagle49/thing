/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Holder
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.level.biome.Biome
 */
package io.github.edwinmindcraft.apoli.common.condition.entity;

import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiomeCondition;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityCondition;
import io.github.edwinmindcraft.apoli.common.condition.configuration.BiomeConfiguration;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.biome.Biome;

public class BiomeCondition
extends EntityCondition<BiomeConfiguration> {
    public BiomeCondition() {
        super(BiomeConfiguration.CODEC);
    }

    @Override
    public boolean check(BiomeConfiguration configuration, Entity entity) {
        Holder biome = entity.m_9236_().m_204166_(entity.m_20183_());
        if (!ConfiguredBiomeCondition.check(configuration.condition(), (Holder<Biome>)biome)) {
            return false;
        }
        if (configuration.biomes().getContent().isEmpty()) {
            return true;
        }
        return biome.m_203543_().map(x -> configuration.biomes().getContent().stream().anyMatch(arg_0 -> ((ResourceKey)x).equals(arg_0))).orElse(false);
    }
}

