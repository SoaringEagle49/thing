/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Holder
 *  net.minecraft.world.entity.Entity
 */
package io.github.edwinmindcraft.apoli.common.condition.entity;

import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiEntityCondition;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityCondition;
import io.github.edwinmindcraft.apoli.common.condition.configuration.IntComparingBiEntityConfiguration;
import java.util.function.ToIntBiFunction;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.Entity;

public class IntComparingBECEntityCondition
extends EntityCondition<IntComparingBiEntityConfiguration> {
    private final ToIntBiFunction<Holder<ConfiguredBiEntityCondition<?, ?>>, Entity> function;

    public static int ridingRecursive(Holder<ConfiguredBiEntityCondition<?, ?>> biEntityCondition, Entity entity) {
        int count = 0;
        if (entity.m_20159_()) {
            for (Entity vehicle = entity.m_20202_(); vehicle != null; vehicle = vehicle.m_20202_()) {
                if (!ConfiguredBiEntityCondition.check(biEntityCondition, entity, vehicle)) continue;
                ++count;
            }
        }
        return count;
    }

    public static int passenger(Holder<ConfiguredBiEntityCondition<?, ?>> biEntityCondition, Entity entity) {
        int count = 0;
        if (entity.m_20160_()) {
            for (Entity passenger : entity.m_20197_()) {
                if (!ConfiguredBiEntityCondition.check(biEntityCondition, passenger, entity)) continue;
                ++count;
            }
        }
        return count;
    }

    public static int passengerRecursive(Holder<ConfiguredBiEntityCondition<?, ?>> biEntityCondition, Entity entity) {
        int count = 0;
        if (entity.m_20160_()) {
            count = (int)entity.m_20197_().stream().flatMap(Entity::m_20199_).filter(passenger -> ConfiguredBiEntityCondition.check(biEntityCondition, passenger, entity)).count();
        }
        return count;
    }

    public IntComparingBECEntityCondition(ToIntBiFunction<Holder<ConfiguredBiEntityCondition<?, ?>>, Entity> function) {
        super(IntComparingBiEntityConfiguration.CODEC);
        this.function = function;
    }

    @Override
    protected boolean check(IntComparingBiEntityConfiguration configuration, Entity entity) {
        int check = this.function.applyAsInt(configuration.biEntityCondition(), entity);
        return configuration.comparison().check(check);
    }
}

