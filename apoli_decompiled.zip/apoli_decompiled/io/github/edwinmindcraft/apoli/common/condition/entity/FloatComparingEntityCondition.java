/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 */
package io.github.edwinmindcraft.apoli.common.condition.entity;

import io.github.edwinmindcraft.apoli.api.configuration.FloatComparisonConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityCondition;
import java.util.function.Function;
import net.minecraft.world.entity.Entity;

public class FloatComparingEntityCondition
extends EntityCondition<FloatComparisonConfiguration> {
    private final Function<Entity, Float> function;

    public FloatComparingEntityCondition(Function<Entity, Float> function) {
        super(FloatComparisonConfiguration.CODEC);
        this.function = function;
    }

    @Override
    public boolean check(FloatComparisonConfiguration configuration, Entity entity) {
        Float apply = this.function.apply(entity);
        return apply != null && configuration.check(apply.floatValue());
    }
}

