/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  net.minecraft.world.entity.ai.attributes.Attribute
 */
package io.github.edwinmindcraft.apoli.common.condition.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.configuration.DoubleComparisonConfiguration;
import net.minecraft.world.entity.ai.attributes.Attribute;

public record AttributeComparisonConfiguration(Attribute attribute, DoubleComparisonConfiguration comparison) implements IDynamicFeatureConfiguration
{
    public static Codec<AttributeComparisonConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)SerializableDataTypes.ATTRIBUTE.fieldOf("attribute").forGetter(AttributeComparisonConfiguration::attribute), (App)DoubleComparisonConfiguration.MAP_CODEC.forGetter(AttributeComparisonConfiguration::comparison)).apply((Applicative)instance, AttributeComparisonConfiguration::new));
}

