/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.level.LevelReader
 */
package io.github.edwinmindcraft.apoli.common.condition.entity;

import io.github.edwinmindcraft.apoli.api.configuration.HolderConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBlockCondition;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityCondition;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelReader;

public class OnBlockCondition
extends EntityCondition<HolderConfiguration<ConfiguredBlockCondition<?, ?>>> {
    public OnBlockCondition() {
        super(HolderConfiguration.optional(ConfiguredBlockCondition.optional("block_condition")));
    }

    @Override
    public boolean check(HolderConfiguration<ConfiguredBlockCondition<?, ?>> configuration, Entity entity) {
        return entity.m_20096_() && ConfiguredBlockCondition.check(configuration.holder(), (LevelReader)entity.m_9236_(), new BlockPos((int)entity.m_20185_(), (int)(entity.m_20191_().f_82289_ - 0.5000001), (int)entity.m_20189_()));
    }
}

