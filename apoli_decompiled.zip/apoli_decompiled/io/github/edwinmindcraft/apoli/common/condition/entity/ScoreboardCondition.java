/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.scores.Objective
 *  net.minecraft.world.scores.Scoreboard
 */
package io.github.edwinmindcraft.apoli.common.condition.entity;

import io.github.edwinmindcraft.apoli.api.power.factory.EntityCondition;
import io.github.edwinmindcraft.apoli.common.condition.configuration.ScoreboardComparisonConfiguration;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.Scoreboard;

public class ScoreboardCondition
extends EntityCondition<ScoreboardComparisonConfiguration> {
    public ScoreboardCondition() {
        super(ScoreboardComparisonConfiguration.CODEC);
    }

    @Override
    public boolean check(ScoreboardComparisonConfiguration configuration, Entity entity) {
        if (entity instanceof Player) {
            Player player = (Player)entity;
            Scoreboard scoreboard = player.m_36329_();
            Objective objective = scoreboard.m_83469_(configuration.objective());
            String playerName = player.m_6302_();
            if (scoreboard.m_83461_(playerName, objective)) {
                int value = scoreboard.m_83471_(playerName, objective).m_83400_();
                return configuration.comparison().check(value);
            }
        }
        return false;
    }
}

