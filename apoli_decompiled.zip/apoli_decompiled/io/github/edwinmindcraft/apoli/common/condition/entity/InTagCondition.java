/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityType
 */
package io.github.edwinmindcraft.apoli.common.condition.entity;

import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.configuration.TagConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityCondition;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;

public class InTagCondition
extends EntityCondition<TagConfiguration<EntityType<?>>> {
    public InTagCondition() {
        super(TagConfiguration.codec(SerializableDataTypes.ENTITY_TAG, "tag"));
    }

    @Override
    public boolean check(TagConfiguration<EntityType<?>> configuration, Entity entity) {
        return entity.m_6095_().m_204039_(configuration.value());
    }
}

