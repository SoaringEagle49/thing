/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.core.Holder
 *  net.minecraft.world.phys.Vec3
 */
package io.github.edwinmindcraft.apoli.common.condition.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBlockCondition;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import net.minecraft.core.Holder;
import net.minecraft.world.phys.Vec3;

public record BlockCollisionConfiguration(Vec3 offset, Holder<ConfiguredBlockCondition<?, ?>> blockCondition) implements IDynamicFeatureConfiguration
{
    public static final Codec<BlockCollisionConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)CalioCodecHelper.vec3d((String)"offset_").forGetter(BlockCollisionConfiguration::offset), (App)ConfiguredBlockCondition.optional("block_condition").forGetter(BlockCollisionConfiguration::blockCondition)).apply((Applicative)instance, BlockCollisionConfiguration::new));
}

