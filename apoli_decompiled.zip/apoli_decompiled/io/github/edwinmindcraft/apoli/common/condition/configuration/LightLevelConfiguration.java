/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataType
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.core.BlockPos
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.level.LightLayer
 *  org.jetbrains.annotations.Nullable
 */
package io.github.edwinmindcraft.apoli.common.condition.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.calio.data.SerializableDataType;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.configuration.IntegerComparisonConfiguration;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.LightLayer;
import org.jetbrains.annotations.Nullable;

public record LightLevelConfiguration(IntegerComparisonConfiguration comparison, @Nullable LightLayer type) implements IDynamicFeatureConfiguration
{
    public static final Codec<LightLevelConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)IntegerComparisonConfiguration.MAP_CODEC.forGetter(LightLevelConfiguration::comparison), (App)CalioCodecHelper.optionalField((Codec)SerializableDataType.enumValue(LightLayer.class), (String)"light_type").forGetter(x -> Optional.ofNullable(x.type()))).apply((Applicative)instance, (comparison, lightType) -> new LightLevelConfiguration((IntegerComparisonConfiguration)comparison, lightType.orElse(null))));

    public int getLightLevel(LevelReader world, BlockPos pos) {
        return this.type() == null ? world.m_46803_(pos) : world.m_45517_(this.type(), pos);
    }
}

