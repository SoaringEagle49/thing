/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 *  org.jetbrains.annotations.Nullable
 */
package io.github.edwinmindcraft.apoli.common.condition.item;

import io.github.edwinmindcraft.apoli.api.configuration.IntegerComparisonConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.ItemCondition;
import java.util.function.ToIntFunction;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public class ComparingItemCondition
extends ItemCondition<IntegerComparisonConfiguration> {
    private final ToIntFunction<ItemStack> function;

    public ComparingItemCondition(ToIntFunction<ItemStack> function) {
        super(IntegerComparisonConfiguration.CODEC);
        this.function = function;
    }

    @Override
    public boolean check(IntegerComparisonConfiguration configuration, @Nullable Level level, ItemStack stack) {
        return configuration.check(this.function.applyAsInt(stack));
    }
}

