/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.multiplayer.MultiPlayerGameMode
 *  net.minecraft.client.player.AbstractClientPlayer
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.server.level.ServerPlayerGameMode
 *  net.minecraft.world.entity.Entity
 *  net.minecraftforge.api.distmarker.Dist
 *  net.minecraftforge.api.distmarker.OnlyIn
 */
package io.github.edwinmindcraft.apoli.common.condition.entity;

import io.github.edwinmindcraft.apoli.api.configuration.NoConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityCondition;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerPlayerGameMode;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class UsingEffectiveToolCondition
extends EntityCondition<NoConfiguration> {
    public UsingEffectiveToolCondition() {
        super(NoConfiguration.CODEC);
    }

    protected boolean checkClient(Entity entity) {
        return false;
    }

    @Override
    public boolean check(NoConfiguration configuration, Entity entity) {
        if (entity instanceof ServerPlayer) {
            ServerPlayer spe = (ServerPlayer)entity;
            ServerPlayerGameMode interactionMngr = spe.f_8941_;
            if (interactionMngr.f_9249_) {
                return spe.m_36298_(entity.m_9236_().m_8055_(interactionMngr.f_9251_));
            }
        }
        return this.checkClient(entity);
    }

    @OnlyIn(value=Dist.CLIENT)
    public static class Client
    extends UsingEffectiveToolCondition {
        @Override
        protected boolean checkClient(Entity entity) {
            if (entity instanceof AbstractClientPlayer) {
                AbstractClientPlayer cpe = (AbstractClientPlayer)entity;
                MultiPlayerGameMode interactionMngr = Minecraft.m_91087_().f_91072_;
                if (interactionMngr != null && interactionMngr.m_105296_()) {
                    return cpe.m_36298_(entity.m_9236_().m_8055_(interactionMngr.f_105191_));
                }
            }
            return false;
        }
    }
}

