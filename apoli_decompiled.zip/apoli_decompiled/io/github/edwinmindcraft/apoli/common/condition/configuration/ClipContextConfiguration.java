/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.world.level.ClipContext$Block
 *  net.minecraft.world.level.ClipContext$Fluid
 */
package io.github.edwinmindcraft.apoli.common.condition.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import net.minecraft.world.level.ClipContext;

public record ClipContextConfiguration(ClipContext.Block block, ClipContext.Fluid fluid) implements IDynamicFeatureConfiguration
{
    public static final Codec<ClipContextConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)CalioCodecHelper.optionalField((Codec)SerializableDataTypes.SHAPE_TYPE, (String)"shape_type", (Object)ClipContext.Block.VISUAL).forGetter(ClipContextConfiguration::block), (App)CalioCodecHelper.optionalField((Codec)SerializableDataTypes.FLUID_HANDLING, (String)"fluid_handling", (Object)ClipContext.Fluid.NONE).forGetter(ClipContextConfiguration::fluid)).apply((Applicative)instance, ClipContextConfiguration::new));
}

