/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 */
package io.github.edwinmindcraft.apoli.common.condition.entity;

import io.github.edwinmindcraft.apoli.api.component.IPowerContainer;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityCondition;
import io.github.edwinmindcraft.apoli.common.condition.configuration.ResourceComparisonConfiguration;
import java.util.OptionalInt;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public class ResourceCondition
extends EntityCondition<ResourceComparisonConfiguration> {
    public ResourceCondition() {
        super(ResourceComparisonConfiguration.CODEC);
    }

    @Override
    public boolean check(ResourceComparisonConfiguration configuration, Entity entity) {
        return IPowerContainer.get(entity).resolve().map(x -> x.getPower(configuration.resource().power())).map(power -> {
            if (entity instanceof LivingEntity) {
                LivingEntity living = (LivingEntity)entity;
                OptionalInt value = ((ConfiguredPower)power.m_203334_()).getValue((Entity)living);
                return value.isPresent() && configuration.comparison().check(value.getAsInt());
            }
            return false;
        }).orElse(false);
    }
}

