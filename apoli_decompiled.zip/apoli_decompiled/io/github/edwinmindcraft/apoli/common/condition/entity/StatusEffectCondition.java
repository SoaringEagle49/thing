/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.effect.MobEffectInstance
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 */
package io.github.edwinmindcraft.apoli.common.condition.entity;

import io.github.edwinmindcraft.apoli.api.power.factory.EntityCondition;
import io.github.edwinmindcraft.apoli.common.condition.configuration.StatusEffectConfiguration;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public class StatusEffectCondition
extends EntityCondition<StatusEffectConfiguration> {
    public StatusEffectCondition() {
        super(StatusEffectConfiguration.CODEC);
    }

    @Override
    public boolean check(StatusEffectConfiguration configuration, Entity entity) {
        LivingEntity living;
        if (!(entity instanceof LivingEntity) || !(living = (LivingEntity)entity).m_21023_(configuration.effect())) {
            return false;
        }
        MobEffectInstance instance = living.m_21124_(configuration.effect());
        assert (instance != null);
        return instance.m_19557_() <= configuration.maxDuration() && instance.m_19557_() >= configuration.minDuration() && instance.m_19564_() <= configuration.maxAmplifier() && instance.m_19564_() >= configuration.minAmplifier();
    }
}

