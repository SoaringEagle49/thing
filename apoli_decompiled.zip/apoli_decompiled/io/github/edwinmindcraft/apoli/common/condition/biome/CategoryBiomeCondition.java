/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  net.minecraft.core.Holder
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.tags.TagKey
 *  net.minecraft.world.level.biome.Biome
 */
package io.github.edwinmindcraft.apoli.common.condition.biome;

import io.github.apace100.apoli.Apoli;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.configuration.FieldConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.BiomeCondition;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.biome.Biome;

@Deprecated
public class CategoryBiomeCondition
extends BiomeCondition<FieldConfiguration<TagKey<Biome>>> {
    public CategoryBiomeCondition() {
        super(FieldConfiguration.codec(SerializableDataTypes.STRING.xmap(s -> TagKey.m_203882_((ResourceKey)Registries.f_256952_, (ResourceLocation)Apoli.identifier("category/" + s)), tagKey -> tagKey.f_203868_().m_135815_().replaceFirst("category/", "")), "category"));
    }

    @Override
    public boolean check(FieldConfiguration<TagKey<Biome>> configuration, Holder<Biome> biome) {
        return biome.m_203633_() && biome.m_203656_(configuration.value());
    }
}

