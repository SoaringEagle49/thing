/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  io.github.edwinmindcraft.calio.api.network.OptionalFuncs
 *  net.minecraft.world.entity.EquipmentSlot
 *  org.jetbrains.annotations.Nullable
 */
package io.github.edwinmindcraft.apoli.common.condition.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.configuration.IntegerComparisonConfiguration;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import io.github.edwinmindcraft.calio.api.network.OptionalFuncs;
import net.minecraft.world.entity.EquipmentSlot;
import org.jetbrains.annotations.Nullable;

public record PowerCountConfiguration(@Nullable EquipmentSlot slot, IntegerComparisonConfiguration comparison) implements IDynamicFeatureConfiguration
{
    public static final Codec<PowerCountConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)CalioCodecHelper.optionalField((Codec)SerializableDataTypes.EQUIPMENT_SLOT, (String)"slot").forGetter(OptionalFuncs.opt(PowerCountConfiguration::slot)), (App)IntegerComparisonConfiguration.MAP_CODEC.forGetter(PowerCountConfiguration::comparison)).apply((Applicative)instance, (equipmentSlot, integerComparisonConfiguration) -> new PowerCountConfiguration(equipmentSlot.orElse(null), (IntegerComparisonConfiguration)integerComparisonConfiguration)));

    public EquipmentSlot[] target() {
        EquipmentSlot[] equipmentSlotArray;
        if (this.slot() == null) {
            equipmentSlotArray = EquipmentSlot.values();
        } else {
            EquipmentSlot[] equipmentSlotArray2 = new EquipmentSlot[1];
            equipmentSlotArray = equipmentSlotArray2;
            equipmentSlotArray2[0] = this.slot();
        }
        return equipmentSlotArray;
    }
}

