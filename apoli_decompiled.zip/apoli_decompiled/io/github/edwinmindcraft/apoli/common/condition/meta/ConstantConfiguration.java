/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 */
package io.github.edwinmindcraft.apoli.common.condition.meta;

import com.mojang.serialization.Codec;
import io.github.edwinmindcraft.apoli.common.condition.meta.IDelegatedConditionConfiguration;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;

public record ConstantConfiguration<T>(boolean value) implements IDelegatedConditionConfiguration<T>
{
    public static <T> Codec<ConstantConfiguration<T>> codec() {
        return CalioCodecHelper.BOOL.fieldOf("value").xmap(ConstantConfiguration::new, ConstantConfiguration::value).codec();
    }

    @Override
    public boolean check(T parameters) {
        return this.value;
    }
}

