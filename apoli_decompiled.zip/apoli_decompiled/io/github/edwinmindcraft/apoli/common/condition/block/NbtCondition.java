/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  net.minecraft.core.BlockPos
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.nbt.NbtUtils
 *  net.minecraft.nbt.Tag
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.level.block.entity.BlockEntity
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraftforge.common.util.NonNullSupplier
 */
package io.github.edwinmindcraft.apoli.common.condition.block;

import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.configuration.FieldConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.BlockCondition;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.util.NonNullSupplier;

public class NbtCondition
extends BlockCondition<FieldConfiguration<CompoundTag>> {
    public NbtCondition() {
        super(FieldConfiguration.codec(SerializableDataTypes.NBT, "nbt"));
    }

    @Override
    protected boolean check(FieldConfiguration<CompoundTag> configuration, LevelReader reader, BlockPos position, NonNullSupplier<BlockState> stateGetter) {
        CompoundTag nbt = new CompoundTag();
        BlockEntity blockEntity = reader.m_7702_(position);
        if (blockEntity != null) {
            nbt = blockEntity.serializeNBT();
        }
        return NbtUtils.m_129235_((Tag)((Tag)configuration.value()), (Tag)nbt, (boolean)true);
    }
}

