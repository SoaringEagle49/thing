/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  net.minecraft.world.damagesource.DamageSource
 */
package io.github.edwinmindcraft.apoli.common.condition.damage;

import com.mojang.serialization.Codec;
import io.github.edwinmindcraft.apoli.api.configuration.FieldConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.DamageCondition;
import net.minecraft.world.damagesource.DamageSource;

public class NameCondition
extends DamageCondition<FieldConfiguration<String>> {
    public NameCondition() {
        super(FieldConfiguration.codec(Codec.STRING, "name"));
    }

    @Override
    public boolean check(FieldConfiguration<String> configuration, DamageSource source, float amount) {
        return configuration.value().equals(source.m_19385_());
    }
}

