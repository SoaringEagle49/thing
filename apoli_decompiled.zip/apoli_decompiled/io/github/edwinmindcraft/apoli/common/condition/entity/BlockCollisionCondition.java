/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.BlockPos$MutableBlockPos
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.phys.AABB
 *  net.minecraftforge.common.util.NonNullSupplier
 */
package io.github.edwinmindcraft.apoli.common.condition.entity;

import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBlockCondition;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityCondition;
import io.github.edwinmindcraft.apoli.common.condition.configuration.BlockCollisionConfiguration;
import io.github.edwinmindcraft.apoli.common.registry.condition.ApoliDefaultConditions;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.common.util.NonNullSupplier;

public class BlockCollisionCondition
extends EntityCondition<BlockCollisionConfiguration> {
    public BlockCollisionCondition() {
        super(BlockCollisionConfiguration.CODEC);
    }

    @Override
    public boolean check(BlockCollisionConfiguration configuration, Entity entity) {
        AABB boundingBox = entity.m_20191_();
        boundingBox = boundingBox.m_82383_(configuration.offset().m_82542_(boundingBox.m_82362_(), boundingBox.m_82376_(), boundingBox.m_82385_()));
        if (configuration.blockCondition().m_203373_(ApoliDefaultConditions.BLOCK_DEFAULT.getId())) {
            return entity.m_9236_().m_186434_(entity, boundingBox).iterator().hasNext();
        }
        BlockPos minBlockPos = BlockPos.m_274561_((double)(boundingBox.f_82288_ + 0.001), (double)(boundingBox.f_82289_ + 0.001), (double)(boundingBox.f_82290_ + 0.001));
        BlockPos maxBlockPos = BlockPos.m_274561_((double)(boundingBox.f_82291_ - 0.001), (double)(boundingBox.f_82292_ - 0.001), (double)(boundingBox.f_82293_ - 0.001));
        BlockPos.MutableBlockPos mutable = new BlockPos.MutableBlockPos();
        for (int x = minBlockPos.m_123341_(); x <= maxBlockPos.m_123341_(); ++x) {
            for (int y = minBlockPos.m_123342_(); y <= maxBlockPos.m_123342_(); ++y) {
                for (int z = minBlockPos.m_123343_(); z <= maxBlockPos.m_123343_(); ++z) {
                    mutable.m_122178_(x, y, z);
                    if (!ConfiguredBlockCondition.check(configuration.blockCondition(), (LevelReader)entity.m_9236_(), (BlockPos)mutable, (NonNullSupplier<BlockState>)((NonNullSupplier)() -> entity.m_9236_().m_8055_((BlockPos)mutable)))) continue;
                    return true;
                }
            }
        }
        return false;
    }
}

