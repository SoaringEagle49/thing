/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.calio.api.network.CodecSet
 *  net.minecraft.core.Holder
 *  net.minecraft.core.HolderSet
 */
package io.github.edwinmindcraft.apoli.common.condition.meta;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.edwinmindcraft.apoli.api.configuration.IStreamConfiguration;
import io.github.edwinmindcraft.apoli.common.condition.meta.IDelegatedConditionConfiguration;
import io.github.edwinmindcraft.calio.api.network.CodecSet;
import java.util.List;
import java.util.function.BiPredicate;
import java.util.function.Predicate;
import java.util.stream.Stream;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderSet;

public record ConditionStreamConfiguration<T, V>(List<HolderSet<T>> entries, String name, BiPredicate<T, V> predicate, Predicate<Stream<Boolean>> check) implements IDelegatedConditionConfiguration<V>,
IStreamConfiguration<HolderSet<T>>
{
    public static <T, V> Codec<ConditionStreamConfiguration<T, V>> codec(CodecSet<T> codec, String name, BiPredicate<T, V> predicate, Predicate<Stream<Boolean>> check) {
        return RecordCodecBuilder.create(instance -> instance.group((App)codec.set().fieldOf("conditions").forGetter(ConditionStreamConfiguration::entries)).apply((Applicative)instance, c -> new ConditionStreamConfiguration(c, name, predicate, check)));
    }

    public static <T, V> ConditionStreamConfiguration<T, V> and(List<HolderSet<T>> entries, BiPredicate<T, V> predicate) {
        return new ConditionStreamConfiguration<T, V>(entries, "And", predicate, x -> x.allMatch(y -> y));
    }

    public static <T, V> ConditionStreamConfiguration<T, V> or(List<HolderSet<T>> entries, BiPredicate<T, V> predicate) {
        return new ConditionStreamConfiguration<T, V>(entries, "And", predicate, x -> x.anyMatch(y -> y));
    }

    public static <T, V> Codec<ConditionStreamConfiguration<T, V>> andCodec(CodecSet<T> codec, BiPredicate<T, V> predicate) {
        return ConditionStreamConfiguration.codec(codec, "And", predicate, x -> x.allMatch(y -> y));
    }

    public static <T, V> Codec<ConditionStreamConfiguration<T, V>> orCodec(CodecSet<T> codec, BiPredicate<T, V> predicate) {
        return ConditionStreamConfiguration.codec(codec, "Or", predicate, x -> x.anyMatch(y -> y));
    }

    @Override
    public boolean check(V parameters) {
        return this.check().test(this.entries().stream().flatMap(HolderSet::m_203614_).filter(Holder::m_203633_).map(Holder::m_203334_).map(x -> this.predicate().test(x, parameters)));
    }
}

