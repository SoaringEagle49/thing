/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 */
package io.github.edwinmindcraft.apoli.common.condition.damage;

import io.github.edwinmindcraft.apoli.api.configuration.FieldConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredEntityCondition;
import io.github.edwinmindcraft.apoli.api.power.factory.DamageCondition;
import java.util.Optional;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public class AttackerCondition
extends DamageCondition<FieldConfiguration<Optional<ConfiguredEntityCondition<?, ?>>>> {
    public AttackerCondition() {
        super(FieldConfiguration.optionalCodec(ConfiguredEntityCondition.CODEC, "entity_condition"));
    }

    @Override
    protected boolean check(FieldConfiguration<Optional<ConfiguredEntityCondition<?, ?>>> configuration, DamageSource source, float amount) {
        boolean bl;
        Entity attacker = source.m_7639_();
        if (attacker instanceof LivingEntity) {
            LivingEntity le = (LivingEntity)attacker;
            bl = configuration.value().map(x -> x.check((Entity)le)).orElse(true);
        } else {
            bl = false;
        }
        return bl;
    }
}

