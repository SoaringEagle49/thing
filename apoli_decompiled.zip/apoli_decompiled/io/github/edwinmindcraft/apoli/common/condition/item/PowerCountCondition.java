/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 *  org.jetbrains.annotations.Nullable
 */
package io.github.edwinmindcraft.apoli.common.condition.item;

import io.github.apace100.apoli.util.StackPowerUtil;
import io.github.edwinmindcraft.apoli.api.power.factory.ItemCondition;
import io.github.edwinmindcraft.apoli.common.condition.configuration.PowerCountConfiguration;
import java.util.Arrays;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public class PowerCountCondition
extends ItemCondition<PowerCountConfiguration> {
    public PowerCountCondition() {
        super(PowerCountConfiguration.CODEC);
    }

    @Override
    protected boolean check(PowerCountConfiguration configuration, @Nullable Level level, ItemStack stack) {
        int count = Arrays.stream(configuration.target()).mapToInt(x -> StackPowerUtil.getPowers(stack, x).size()).sum();
        return configuration.comparison().check(count);
    }
}

