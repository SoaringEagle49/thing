/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.level.ClipContext
 *  net.minecraft.world.phys.HitResult$Type
 *  net.minecraft.world.phys.Vec3
 */
package io.github.edwinmindcraft.apoli.common.condition.bientity;

import io.github.edwinmindcraft.apoli.api.power.factory.BiEntityCondition;
import io.github.edwinmindcraft.apoli.common.condition.configuration.ClipContextConfiguration;
import java.util.Objects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class LineOfSightCondition
extends BiEntityCondition<ClipContextConfiguration> {
    public LineOfSightCondition() {
        super(ClipContextConfiguration.CODEC);
    }

    @Override
    protected boolean check(ClipContextConfiguration configuration, Entity actor, Entity target) {
        if (!Objects.equals(actor.m_9236_(), target.m_9236_())) {
            return false;
        }
        Vec3 vec3d = new Vec3(actor.m_20185_(), actor.m_20188_(), actor.m_20189_());
        Vec3 vec3d2 = new Vec3(target.m_20185_(), target.m_20188_(), target.m_20189_());
        if (vec3d2.m_82554_(vec3d) > 128.0) {
            return false;
        }
        return actor.m_9236_().m_45547_(new ClipContext(vec3d, vec3d2, configuration.block(), configuration.fluid(), actor)).m_6662_() == HitResult.Type.MISS;
    }
}

