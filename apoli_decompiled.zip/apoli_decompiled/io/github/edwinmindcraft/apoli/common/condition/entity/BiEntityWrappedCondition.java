/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Holder
 *  net.minecraft.world.entity.Entity
 */
package io.github.edwinmindcraft.apoli.common.condition.entity;

import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiEntityCondition;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityCondition;
import io.github.edwinmindcraft.apoli.common.power.configuration.BiEntityConditionConfiguration;
import java.util.function.BiPredicate;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.Entity;

public class BiEntityWrappedCondition
extends EntityCondition<BiEntityConditionConfiguration> {
    private final BiPredicate<Holder<ConfiguredBiEntityCondition<?, ?>>, Entity> predicate;

    public static boolean riding(Holder<ConfiguredBiEntityCondition<?, ?>> configuration, Entity entity) {
        return entity.m_20159_() && ConfiguredBiEntityCondition.check(configuration, entity, entity.m_20202_());
    }

    public static boolean ridingRoot(Holder<ConfiguredBiEntityCondition<?, ?>> configuration, Entity entity) {
        return entity.m_20159_() && ConfiguredBiEntityCondition.check(configuration, entity, entity.m_20201_());
    }

    public BiEntityWrappedCondition(BiPredicate<Holder<ConfiguredBiEntityCondition<?, ?>>, Entity> predicate) {
        super(BiEntityConditionConfiguration.CODEC);
        this.predicate = predicate;
    }

    @Override
    protected boolean check(BiEntityConditionConfiguration configuration, Entity entity) {
        return this.predicate.test(configuration.biEntityCondition(), entity);
    }
}

