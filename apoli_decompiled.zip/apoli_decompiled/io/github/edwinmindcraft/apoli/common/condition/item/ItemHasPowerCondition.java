/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 *  org.jetbrains.annotations.Nullable
 */
package io.github.edwinmindcraft.apoli.common.condition.item;

import io.github.apace100.apoli.util.StackPowerUtil;
import io.github.edwinmindcraft.apoli.api.power.factory.ItemCondition;
import io.github.edwinmindcraft.apoli.common.action.configuration.ItemHasPowerConfiguration;
import java.util.Arrays;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public class ItemHasPowerCondition
extends ItemCondition<ItemHasPowerConfiguration> {
    public ItemHasPowerCondition() {
        super(ItemHasPowerConfiguration.CODEC);
    }

    @Override
    protected boolean check(ItemHasPowerConfiguration configuration, @Nullable Level level, ItemStack stack) {
        return Arrays.stream(configuration.target()).flatMap(x -> StackPowerUtil.getPowers(stack, x).stream()).anyMatch(x -> configuration.power().equals((Object)x.powerId));
    }
}

