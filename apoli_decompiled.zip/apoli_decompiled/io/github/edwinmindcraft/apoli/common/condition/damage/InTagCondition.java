/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.apace100.calio.data.SerializableDataType
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.tags.TagKey
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.damagesource.DamageType
 */
package io.github.edwinmindcraft.apoli.common.condition.damage;

import io.github.apace100.calio.data.SerializableDataType;
import io.github.edwinmindcraft.apoli.api.configuration.FieldConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.DamageCondition;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.tags.TagKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;

public class InTagCondition
extends DamageCondition<FieldConfiguration<TagKey<DamageType>>> {
    public InTagCondition() {
        super(FieldConfiguration.codec(SerializableDataType.tag((ResourceKey)Registries.f_268580_), "tag"));
    }

    @Override
    protected boolean check(FieldConfiguration<TagKey<DamageType>> configuration, DamageSource source, float amount) {
        return source.m_269533_(configuration.value());
    }
}

