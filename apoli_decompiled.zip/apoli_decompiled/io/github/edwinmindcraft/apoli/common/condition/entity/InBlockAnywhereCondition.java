/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.BlockPos$MutableBlockPos
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.phys.AABB
 */
package io.github.edwinmindcraft.apoli.common.condition.entity;

import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBlockCondition;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityCondition;
import io.github.edwinmindcraft.apoli.common.condition.configuration.InBlockAnywhereConfiguration;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.phys.AABB;

public class InBlockAnywhereCondition
extends EntityCondition<InBlockAnywhereConfiguration> {
    public InBlockAnywhereCondition() {
        super(InBlockAnywhereConfiguration.CODEC);
    }

    @Override
    public boolean check(InBlockAnywhereConfiguration configuration, Entity entity) {
        int stopAt = configuration.comparison().getOptimalStoppingPoint();
        int count = 0;
        AABB box = entity.m_20191_();
        BlockPos blockPos = new BlockPos((int)(box.f_82288_ + 0.001), (int)(box.f_82289_ + 0.001), (int)(box.f_82290_ + 0.001));
        BlockPos blockPos2 = new BlockPos((int)(box.f_82291_ - 0.001), (int)Math.min(box.f_82292_ - 0.001, (double)entity.m_9236_().m_141928_()), (int)(box.f_82293_ - 0.001));
        BlockPos.MutableBlockPos mutable = new BlockPos.MutableBlockPos();
        for (int i = blockPos.m_123341_(); i <= blockPos2.m_123341_() && count < stopAt; ++i) {
            for (int j = blockPos.m_123342_(); j <= blockPos2.m_123342_() && count < stopAt; ++j) {
                for (int k = blockPos.m_123343_(); k <= blockPos2.m_123343_() && count < stopAt; ++k) {
                    mutable.m_122178_(i, j, k);
                    if (!ConfiguredBlockCondition.check(configuration.blockCondition(), (LevelReader)entity.m_9236_(), (BlockPos)mutable)) continue;
                    ++count;
                }
            }
        }
        return configuration.comparison().check(count);
    }
}

