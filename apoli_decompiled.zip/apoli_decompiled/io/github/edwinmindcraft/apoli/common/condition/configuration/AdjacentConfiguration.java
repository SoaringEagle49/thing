/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  net.minecraft.core.Holder
 */
package io.github.edwinmindcraft.apoli.common.condition.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.configuration.IntegerComparisonConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBlockCondition;
import net.minecraft.core.Holder;

public record AdjacentConfiguration(IntegerComparisonConfiguration comparison, Holder<ConfiguredBlockCondition<?, ?>> condition) implements IDynamicFeatureConfiguration
{
    public static final Codec<AdjacentConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)IntegerComparisonConfiguration.MAP_CODEC.forGetter(AdjacentConfiguration::comparison), (App)ConfiguredBlockCondition.required("adjacent_condition").forGetter(AdjacentConfiguration::condition)).apply((Applicative)instance, AdjacentConfiguration::new));
}

