/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  net.minecraft.world.damagesource.DamageSource
 *  org.apache.commons.lang3.tuple.Pair
 */
package io.github.edwinmindcraft.apoli.common.condition.damage;

import com.mojang.serialization.Codec;
import io.github.edwinmindcraft.apoli.api.power.factory.DamageCondition;
import io.github.edwinmindcraft.apoli.common.condition.meta.IDelegatedConditionConfiguration;
import net.minecraft.world.damagesource.DamageSource;
import org.apache.commons.lang3.tuple.Pair;

public class DelegatedDamageCondition<T extends IDelegatedConditionConfiguration<Pair<DamageSource, Float>>>
extends DamageCondition<T> {
    public DelegatedDamageCondition(Codec<T> codec) {
        super(codec);
    }

    @Override
    protected boolean check(T configuration, DamageSource source, float amount) {
        return configuration.check((Pair)Pair.of((Object)source, (Object)Float.valueOf(amount)));
    }
}

