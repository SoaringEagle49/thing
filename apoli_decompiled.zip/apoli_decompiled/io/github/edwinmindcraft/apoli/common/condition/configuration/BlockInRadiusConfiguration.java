/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataType
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.core.Holder
 */
package io.github.edwinmindcraft.apoli.common.condition.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.apoli.util.Comparison;
import io.github.apace100.apoli.util.Shape;
import io.github.apace100.calio.data.SerializableDataType;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.configuration.IntegerComparisonConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBlockCondition;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import net.minecraft.core.Holder;

public record BlockInRadiusConfiguration(Holder<ConfiguredBlockCondition<?, ?>> blockCondition, int radius, Shape shape, IntegerComparisonConfiguration comparison) implements IDynamicFeatureConfiguration
{
    public static final Codec<BlockInRadiusConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)ConfiguredBlockCondition.required("block_condition").forGetter(BlockInRadiusConfiguration::blockCondition), (App)CalioCodecHelper.INT.fieldOf("radius").forGetter(BlockInRadiusConfiguration::radius), (App)SerializableDataType.enumValue(Shape.class).optionalFieldOf("shape", (Object)Shape.CUBE).forGetter(BlockInRadiusConfiguration::shape), (App)IntegerComparisonConfiguration.withDefaults(Comparison.GREATER_THAN_OR_EQUAL, 1).forGetter(BlockInRadiusConfiguration::comparison)).apply((Applicative)instance, BlockInRadiusConfiguration::new));

    public BlockInRadiusConfiguration inverse() {
        return new BlockInRadiusConfiguration(this.blockCondition(), this.radius(), this.shape(), this.comparison().inverse());
    }
}

