/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.damagesource.DamageSource
 */
package io.github.edwinmindcraft.apoli.common.condition.damage;

import io.github.edwinmindcraft.apoli.api.configuration.NoConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.DamageCondition;
import java.util.function.BiPredicate;
import java.util.function.Predicate;
import net.minecraft.world.damagesource.DamageSource;

public class SimpleDamageCondition
extends DamageCondition<NoConfiguration> {
    private final BiPredicate<DamageSource, Float> predicate;

    public SimpleDamageCondition(Predicate<DamageSource> predicate) {
        this((DamageSource source, Float amount) -> predicate.test((DamageSource)source));
    }

    public SimpleDamageCondition(BiPredicate<DamageSource, Float> predicate) {
        super(NoConfiguration.CODEC);
        this.predicate = predicate;
    }

    @Override
    public boolean check(NoConfiguration configuration, DamageSource source, float amount) {
        return this.predicate.test(source, Float.valueOf(amount));
    }
}

