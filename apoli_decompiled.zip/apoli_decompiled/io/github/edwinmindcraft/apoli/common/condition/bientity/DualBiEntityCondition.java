/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Holder
 *  net.minecraft.world.entity.Entity
 */
package io.github.edwinmindcraft.apoli.common.condition.bientity;

import io.github.edwinmindcraft.apoli.api.configuration.HolderConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiEntityCondition;
import io.github.edwinmindcraft.apoli.api.power.factory.BiEntityCondition;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.Entity;

public class DualBiEntityCondition
extends BiEntityCondition<HolderConfiguration<ConfiguredBiEntityCondition<?, ?>>> {
    private final Operator operator;

    public static DualBiEntityCondition invert() {
        return new DualBiEntityCondition((condition, actor, target) -> ConfiguredBiEntityCondition.check(condition, target, actor));
    }

    public static DualBiEntityCondition undirected() {
        return new DualBiEntityCondition((condition, actor, target) -> ConfiguredBiEntityCondition.check(condition, actor, target) || ConfiguredBiEntityCondition.check(condition, target, actor));
    }

    private DualBiEntityCondition(Operator operator) {
        super(HolderConfiguration.required(ConfiguredBiEntityCondition.required("condition")));
        this.operator = operator;
    }

    @Override
    protected boolean check(HolderConfiguration<ConfiguredBiEntityCondition<?, ?>> configuration, Entity actor, Entity target) {
        return this.operator.check(configuration.holder(), actor, target);
    }

    @FunctionalInterface
    public static interface Operator {
        public boolean check(Holder<ConfiguredBiEntityCondition<?, ?>> var1, Entity var2, Entity var3);
    }
}

