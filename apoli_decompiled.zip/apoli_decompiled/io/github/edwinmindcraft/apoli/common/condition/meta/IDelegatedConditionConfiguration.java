/*
 * Decompiled with CFR 0.152.
 */
package io.github.edwinmindcraft.apoli.common.condition.meta;

import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;

public interface IDelegatedConditionConfiguration<V>
extends IDynamicFeatureConfiguration {
    public boolean check(V var1);
}

