/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 */
package io.github.edwinmindcraft.apoli.common.condition.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.configuration.IntegerComparisonConfiguration;
import io.github.edwinmindcraft.apoli.common.action.configuration.CommandConfiguration;

public record CommandComparisonConfiguration(CommandConfiguration command, IntegerComparisonConfiguration comparison) implements IDynamicFeatureConfiguration
{
    public static final Codec<CommandComparisonConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)CommandConfiguration.MAP_CODEC.forGetter(CommandComparisonConfiguration::command), (App)IntegerComparisonConfiguration.MAP_CODEC.forGetter(CommandComparisonConfiguration::comparison)).apply((Applicative)instance, CommandComparisonConfiguration::new));
}

