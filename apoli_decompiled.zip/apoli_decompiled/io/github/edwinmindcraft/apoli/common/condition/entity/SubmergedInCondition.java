/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.level.material.Fluid
 */
package io.github.edwinmindcraft.apoli.common.condition.entity;

import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.configuration.TagConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityCondition;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.material.Fluid;

public class SubmergedInCondition
extends EntityCondition<TagConfiguration<Fluid>> {
    public SubmergedInCondition() {
        super(TagConfiguration.codec(SerializableDataTypes.FLUID_TAG, "fluid"));
    }

    @Override
    public boolean check(TagConfiguration<Fluid> configuration, Entity entity) {
        return entity.m_204029_(configuration.value());
    }
}

