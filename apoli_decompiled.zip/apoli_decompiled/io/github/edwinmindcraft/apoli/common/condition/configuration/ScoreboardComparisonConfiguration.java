/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 */
package io.github.edwinmindcraft.apoli.common.condition.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.configuration.DoubleComparisonConfiguration;

public record ScoreboardComparisonConfiguration(DoubleComparisonConfiguration comparison, String objective) implements IDynamicFeatureConfiguration
{
    public static Codec<ScoreboardComparisonConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)DoubleComparisonConfiguration.MAP_CODEC.forGetter(ScoreboardComparisonConfiguration::comparison), (App)Codec.STRING.fieldOf("objective").forGetter(ScoreboardComparisonConfiguration::objective)).apply((Applicative)instance, ScoreboardComparisonConfiguration::new));
}

