/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 */
package io.github.edwinmindcraft.apoli.common.condition.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.configuration.IntegerComparisonConfiguration;
import io.github.edwinmindcraft.apoli.api.configuration.PowerReference;

public record ResourceComparisonConfiguration(IntegerComparisonConfiguration comparison, PowerReference resource) implements IDynamicFeatureConfiguration
{
    public static Codec<ResourceComparisonConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)IntegerComparisonConfiguration.MAP_CODEC.forGetter(ResourceComparisonConfiguration::comparison), (App)PowerReference.mapCodec("resource").forGetter(ResourceComparisonConfiguration::resource)).apply((Applicative)instance, ResourceComparisonConfiguration::new));
}

