/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.world.level.BlockGetter
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraftforge.common.util.NonNullSupplier
 */
package io.github.edwinmindcraft.apoli.common.condition.block;

import com.mojang.serialization.Codec;
import io.github.edwinmindcraft.apoli.api.configuration.NoConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.BlockCondition;
import java.util.Arrays;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.util.NonNullSupplier;

public class AttachableCondition
extends BlockCondition<NoConfiguration> {
    public static final Codec<AttachableCondition> CODEC = Codec.unit((Object)new AttachableCondition());

    public AttachableCondition() {
        super(NoConfiguration.CODEC);
    }

    @Override
    protected boolean check(NoConfiguration configuration, LevelReader reader, BlockPos position, NonNullSupplier<BlockState> stateGetter) {
        return Arrays.stream(Direction.values()).anyMatch(d -> reader.m_8055_(position.m_121945_(d)).m_60783_((BlockGetter)reader, position, d.m_122424_()));
    }
}

