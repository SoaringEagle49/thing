/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.Container
 *  net.minecraft.world.SimpleContainer
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.crafting.AbstractCookingRecipe
 *  net.minecraft.world.item.crafting.RecipeType
 *  net.minecraft.world.level.Level
 *  org.jetbrains.annotations.Nullable
 */
package io.github.edwinmindcraft.apoli.common.condition.item;

import io.github.edwinmindcraft.apoli.api.configuration.NoConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.ItemCondition;
import java.util.function.BiPredicate;
import java.util.function.Predicate;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.AbstractCookingRecipe;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public class SimpleItemCondition
extends ItemCondition<NoConfiguration> {
    private final BiPredicate<Level, ItemStack> predicate;

    public static boolean forCookingRecipeType(Level level, ItemStack stack, RecipeType<? extends AbstractCookingRecipe> type) {
        if (level == null) {
            return false;
        }
        return level.m_7465_().m_44015_(type, (Container)new SimpleContainer(new ItemStack[]{stack}), level).isPresent();
    }

    public SimpleItemCondition(Predicate<ItemStack> predicate) {
        this((Level level, ItemStack stack) -> predicate.test((ItemStack)stack));
    }

    public SimpleItemCondition(BiPredicate<Level, ItemStack> predicate) {
        super(NoConfiguration.CODEC);
        this.predicate = predicate;
    }

    @Override
    public boolean check(NoConfiguration configuration, @Nullable Level level, ItemStack stack) {
        return this.predicate.test(level, stack);
    }
}

