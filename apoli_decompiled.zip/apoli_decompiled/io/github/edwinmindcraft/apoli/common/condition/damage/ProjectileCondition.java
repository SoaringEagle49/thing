/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.tags.DamageTypeTags
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.Entity
 */
package io.github.edwinmindcraft.apoli.common.condition.damage;

import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredEntityCondition;
import io.github.edwinmindcraft.apoli.api.power.factory.DamageCondition;
import io.github.edwinmindcraft.apoli.common.condition.configuration.ProjectileConfiguration;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;

public class ProjectileCondition
extends DamageCondition<ProjectileConfiguration> {
    public ProjectileCondition() {
        super(ProjectileConfiguration.CODEC);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    protected boolean check(ProjectileConfiguration configuration, DamageSource source, float amount) {
        if (!source.m_269533_(DamageTypeTags.f_268524_)) return false;
        Entity projectile = source.m_7640_();
        if (projectile == null) return false;
        if (configuration.projectile().map(projectile.m_6095_()::equals).orElse(true) == false) return false;
        if (!ConfiguredEntityCondition.check(configuration.projectileCondition(), projectile)) return false;
        return true;
    }
}

