/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.util.ArgumentWrapper
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.core.Holder
 *  net.minecraft.resources.ResourceKey
 */
package io.github.edwinmindcraft.apoli.common.condition.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.util.Comparison;
import io.github.apace100.apoli.util.InventoryUtil;
import io.github.apace100.calio.util.ArgumentWrapper;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.configuration.IntegerComparisonConfiguration;
import io.github.edwinmindcraft.apoli.api.configuration.ListConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredItemCondition;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.apoli.api.registry.ApoliDynamicRegistries;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import java.util.EnumSet;
import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceKey;

public record InventoryConfiguration(EnumSet<InventoryUtil.InventoryType> inventoryTypes, InventoryUtil.ProcessMode processMode, Holder<ConfiguredItemCondition<?, ?>> itemCondition, ListConfiguration<ArgumentWrapper<Integer>> slots, Optional<ResourceKey<ConfiguredPower<?, ?>>> power, IntegerComparisonConfiguration comparison) implements IDynamicFeatureConfiguration
{
    public static final Codec<InventoryConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)CalioCodecHelper.optionalField(ApoliDataTypes.INVENTORY_TYPE_SET, (String)"inventory_types", EnumSet.of(InventoryUtil.InventoryType.INVENTORY)).forGetter(InventoryConfiguration::inventoryTypes), (App)CalioCodecHelper.optionalField(ApoliDataTypes.PROCESS_MODE, (String)"process_mode", (Object)((Object)InventoryUtil.ProcessMode.ITEMS)).forGetter(InventoryConfiguration::processMode), (App)ConfiguredItemCondition.optional("item_condition").forGetter(InventoryConfiguration::itemCondition), (App)ListConfiguration.mapCodec(ApoliDataTypes.ITEM_SLOT, "slot", "slots").forGetter(InventoryConfiguration::slots), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.resourceKey(ApoliDynamicRegistries.CONFIGURED_POWER_KEY), (String)"power").forGetter(InventoryConfiguration::power), (App)IntegerComparisonConfiguration.withDefaults(Comparison.GREATER_THAN_OR_EQUAL, 0).forGetter(InventoryConfiguration::comparison)).apply((Applicative)instance, InventoryConfiguration::new));
}

