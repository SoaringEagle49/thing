/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Vec3i
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraft.world.phys.Vec3
 *  net.minecraftforge.common.util.NonNullSupplier
 */
package io.github.edwinmindcraft.apoli.common.condition.block;

import com.mojang.serialization.Codec;
import io.github.edwinmindcraft.apoli.api.power.factory.BlockCondition;
import io.github.edwinmindcraft.apoli.common.action.configuration.DistanceFromPointConfiguration;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.util.NonNullSupplier;

public class DistanceFromPointBlockCondition
extends BlockCondition<DistanceFromPointConfiguration> {
    public DistanceFromPointBlockCondition(Codec<DistanceFromPointConfiguration> codec) {
        super(codec);
    }

    @Override
    protected boolean check(DistanceFromPointConfiguration configuration, LevelReader reader, BlockPos position, NonNullSupplier<BlockState> stateGetter) {
        boolean bl;
        if (reader instanceof Level) {
            Level level = (Level)reader;
            bl = configuration.test(null, Vec3.m_82528_((Vec3i)position), level);
        } else {
            bl = configuration.comparison().check(Double.POSITIVE_INFINITY);
        }
        return bl;
    }
}

