/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraftforge.common.util.NonNullSupplier
 */
package io.github.edwinmindcraft.apoli.common.condition.block;

import io.github.edwinmindcraft.apoli.api.power.factory.BlockCondition;
import io.github.edwinmindcraft.apoli.common.condition.configuration.BlockStateConfiguration;
import java.util.Collection;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.util.NonNullSupplier;

public class BlockStateCondition
extends BlockCondition<BlockStateConfiguration> {
    public BlockStateCondition() {
        super(BlockStateConfiguration.CODEC);
    }

    @Override
    protected boolean check(BlockStateConfiguration configuration, LevelReader reader, BlockPos position, NonNullSupplier<BlockState> stateGetter) {
        BlockState state = (BlockState)stateGetter.get();
        Collection properties = state.m_61147_();
        return properties.stream().filter(p -> configuration.property().equals(p.m_61708_())).findFirst().map(property -> configuration.checkProperty(state.m_61143_(property))).orElse(false);
    }
}

