/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.tags.TagKey
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.damagesource.DamageType
 */
package io.github.edwinmindcraft.apoli.common.condition.damage;

import io.github.edwinmindcraft.apoli.common.condition.damage.SimpleDamageCondition;
import net.minecraft.tags.TagKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;

public class SimpleTagCondition
extends SimpleDamageCondition {
    public SimpleTagCondition(TagKey<DamageType> tagKey) {
        super((DamageSource source, Float aFloat) -> source.m_269533_(tagKey));
    }
}

