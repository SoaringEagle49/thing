/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.world.level.BlockGetter
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.level.block.LiquidBlockContainer
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraftforge.common.util.NonNullSupplier
 */
package io.github.edwinmindcraft.apoli.common.condition.block;

import io.github.edwinmindcraft.apoli.api.configuration.NoConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.BlockCondition;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.LiquidBlockContainer;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.util.NonNullSupplier;

public class SimpleBlockCondition
extends BlockCondition<NoConfiguration> {
    public static final BlockCondition.BlockPredicate REPLACEABLE = (reader, pos, stateGetter) -> ((BlockState)stateGetter.get()).m_247087_();
    public static final BlockCondition.BlockPredicate MOVEMENT_BLOCKING = (reader, pos, stateGetter) -> ((BlockState)stateGetter.get()).m_280555_() && !((BlockState)stateGetter.get()).m_60812_((BlockGetter)reader, pos).m_83281_();
    public static final BlockCondition.BlockPredicate LIGHT_BLOCKING = (reader, pos, stateGetter) -> ((BlockState)stateGetter.get()).m_60815_();
    public static final BlockCondition.BlockPredicate WATER_LOGGABLE = (reader, pos, stateGetter) -> ((BlockState)stateGetter.get()).m_60734_() instanceof LiquidBlockContainer;
    public static final BlockCondition.BlockPredicate EXPOSED_TO_SKY = (reader, pos, stateGetter) -> reader.m_45527_(pos);
    public static final BlockCondition.BlockPredicate BLOCK_ENTITY = (reader, pos, stateGetter) -> reader.m_7702_(pos) != null;
    private final BlockCondition.BlockPredicate blockPredicate;

    public SimpleBlockCondition(BlockCondition.BlockPredicate blockPredicate) {
        super(NoConfiguration.CODEC);
        this.blockPredicate = blockPredicate;
    }

    @Override
    protected boolean check(NoConfiguration configuration, LevelReader reader, BlockPos position, NonNullSupplier<BlockState> stateGetter) {
        return this.blockPredicate.test(reader, position, stateGetter);
    }
}

