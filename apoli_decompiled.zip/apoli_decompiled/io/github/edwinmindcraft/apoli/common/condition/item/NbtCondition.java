/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.nbt.NbtUtils
 *  net.minecraft.nbt.Tag
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 *  org.jetbrains.annotations.Nullable
 */
package io.github.edwinmindcraft.apoli.common.condition.item;

import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.configuration.FieldConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.ItemCondition;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public class NbtCondition
extends ItemCondition<FieldConfiguration<CompoundTag>> {
    public NbtCondition() {
        super(FieldConfiguration.codec(SerializableDataTypes.NBT, "nbt"));
    }

    @Override
    protected boolean check(FieldConfiguration<CompoundTag> configuration, @Nullable Level level, ItemStack stack) {
        return NbtUtils.m_129235_((Tag)((Tag)configuration.value()), (Tag)stack.m_41783_(), (boolean)true);
    }
}

