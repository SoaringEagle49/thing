/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.core.Holder
 *  net.minecraft.core.registries.Registries
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.world.level.biome.Biome
 */
package io.github.edwinmindcraft.apoli.common.condition.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.configuration.ListConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiomeCondition;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.biome.Biome;

public record BiomeConfiguration(ListConfiguration<ResourceKey<Biome>> biomes, Holder<ConfiguredBiomeCondition<?, ?>> condition) implements IDynamicFeatureConfiguration
{
    public static final Codec<BiomeConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)ListConfiguration.mapCodec(CalioCodecHelper.resourceKey((ResourceKey)Registries.f_256952_), "biome", "biomes").forGetter(BiomeConfiguration::biomes), (App)ConfiguredBiomeCondition.optional("condition").forGetter(BiomeConfiguration::condition)).apply((Applicative)instance, BiomeConfiguration::new));
}

