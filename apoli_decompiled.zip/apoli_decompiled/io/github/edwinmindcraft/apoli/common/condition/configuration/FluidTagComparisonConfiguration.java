/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  net.minecraft.tags.TagKey
 *  net.minecraft.world.level.material.Fluid
 */
package io.github.edwinmindcraft.apoli.common.condition.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.configuration.DoubleComparisonConfiguration;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.material.Fluid;

public record FluidTagComparisonConfiguration(DoubleComparisonConfiguration comparison, TagKey<Fluid> tag) implements IDynamicFeatureConfiguration
{
    public static Codec<FluidTagComparisonConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)DoubleComparisonConfiguration.MAP_CODEC.forGetter(FluidTagComparisonConfiguration::comparison), (App)SerializableDataTypes.FLUID_TAG.fieldOf("fluid").forGetter(FluidTagComparisonConfiguration::tag)).apply((Applicative)instance, FluidTagComparisonConfiguration::new));
}

