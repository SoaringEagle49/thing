/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 */
package io.github.edwinmindcraft.apoli.common.condition.entity;

import io.github.edwinmindcraft.apoli.api.power.factory.EntityCondition;
import io.github.edwinmindcraft.apoli.common.condition.configuration.EnchantmentConfiguration;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public class EnchantmentCondition
extends EntityCondition<EnchantmentConfiguration> {
    public EnchantmentCondition() {
        super(EnchantmentConfiguration.CODEC);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public boolean check(EnchantmentConfiguration configuration, Entity entity) {
        if (!(entity instanceof LivingEntity)) return false;
        LivingEntity living = (LivingEntity)entity;
        if (!configuration.enchantment().isPresent()) return false;
        if (!configuration.applyCheck(configuration.enchantment().get().m_44684_(living).values())) return false;
        return true;
    }
}

