/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  net.minecraft.core.Holder
 */
package io.github.edwinmindcraft.apoli.common.condition.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.apoli.util.Comparison;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.configuration.IntegerComparisonConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiEntityCondition;
import net.minecraft.core.Holder;

public record IntComparingBiEntityConfiguration(IntegerComparisonConfiguration comparison, Holder<ConfiguredBiEntityCondition<?, ?>> biEntityCondition) implements IDynamicFeatureConfiguration
{
    public static final Codec<IntComparingBiEntityConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)IntegerComparisonConfiguration.withDefaults(Comparison.GREATER_THAN_OR_EQUAL, 1).forGetter(IntComparingBiEntityConfiguration::comparison), (App)ConfiguredBiEntityCondition.optional("bientity_condition").forGetter(IntComparingBiEntityConfiguration::biEntityCondition)).apply((Applicative)instance, IntComparingBiEntityConfiguration::new));
}

