/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.stats.ServerStatsCounter
 *  net.minecraft.world.entity.Entity
 */
package io.github.edwinmindcraft.apoli.common.action.entity;

import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredModifier;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import io.github.edwinmindcraft.apoli.common.action.configuration.ModifyStatConfiguration;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.ServerStatsCounter;
import net.minecraft.world.entity.Entity;

public class ModifyStatAction
extends EntityAction<ModifyStatConfiguration> {
    public ModifyStatAction() {
        super(ModifyStatConfiguration.CODEC);
    }

    @Override
    public void execute(ModifyStatConfiguration configuration, Entity entity) {
        if (!(entity instanceof ServerPlayer)) {
            return;
        }
        ServerPlayer serverPlayerEntity = (ServerPlayer)entity;
        ServerStatsCounter serverStatHandler = serverPlayerEntity.m_8951_();
        int originalValue = serverStatHandler.m_13015_(configuration.stat());
        serverPlayerEntity.m_7166_(configuration.stat());
        int newValue = (int)ConfiguredModifier.apply(configuration.modifier(), entity, originalValue);
        serverPlayerEntity.m_6278_(configuration.stat(), newValue);
    }
}

