/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataType
 *  io.github.edwinmindcraft.calio.api.network.CodecSet
 *  net.minecraft.core.Holder
 */
package io.github.edwinmindcraft.apoli.common.action.meta;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.calio.data.SerializableDataType;
import io.github.edwinmindcraft.apoli.common.action.meta.IDelegatedActionConfiguration;
import io.github.edwinmindcraft.calio.api.network.CodecSet;
import java.util.function.BiConsumer;
import java.util.function.Predicate;
import net.minecraft.core.Holder;

public record SideConfiguration<T, V>(Side side, Holder<T> action, Predicate<V> serverCheck, BiConsumer<T, V> executor) implements IDelegatedActionConfiguration<V>
{
    public static <T, V> Codec<SideConfiguration<T, V>> codec(CodecSet<T> codec, Predicate<V> serverCheck, BiConsumer<T, V> executor) {
        return RecordCodecBuilder.create(instance -> instance.group((App)SerializableDataType.enumValue(Side.class).fieldOf("side").forGetter(SideConfiguration::side), (App)codec.holder().fieldOf("action").forGetter(SideConfiguration::action)).apply((Applicative)instance, (side, action) -> new SideConfiguration((Side)((Object)((Object)side)), action, serverCheck, executor)));
    }

    @Override
    public void execute(V parameters) {
        boolean isServer = this.serverCheck.test(parameters);
        if (this.action().m_203633_() && this.side() == Side.CLIENT != isServer) {
            this.executor().accept(this.action().m_203334_(), parameters);
        }
    }

    public static enum Side {
        CLIENT,
        SERVER;

    }
}

