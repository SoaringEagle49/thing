/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 */
package io.github.edwinmindcraft.apoli.common.action.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;

public record ExperienceConfiguration(int points, int levels) implements IDynamicFeatureConfiguration
{
    public static final Codec<ExperienceConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.INT, (String)"points", (Object)0).forGetter(ExperienceConfiguration::points), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.INT, (String)"levels", (Object)0).forGetter(ExperienceConfiguration::levels)).apply((Applicative)instance, ExperienceConfiguration::new));
}

