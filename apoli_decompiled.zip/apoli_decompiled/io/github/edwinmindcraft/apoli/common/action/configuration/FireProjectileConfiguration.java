/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.core.Holder
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.world.entity.EntityType
 */
package io.github.edwinmindcraft.apoli.common.action.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredEntityAction;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.EntityType;

public record FireProjectileConfiguration(EntityType<?> entityType, float divergence, float speed, int count, Optional<CompoundTag> tag, Holder<ConfiguredEntityAction<?, ?>> projectileAction) implements IDynamicFeatureConfiguration
{
    public static final Codec<FireProjectileConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)SerializableDataTypes.ENTITY_TYPE.fieldOf("entity_type").forGetter(FireProjectileConfiguration::entityType), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.FLOAT, (String)"divergence", (Object)Float.valueOf(1.0f)).forGetter(FireProjectileConfiguration::divergence), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.FLOAT, (String)"speed", (Object)Float.valueOf(1.5f)).forGetter(FireProjectileConfiguration::speed), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.INT, (String)"count", (Object)1).forGetter(FireProjectileConfiguration::count), (App)CalioCodecHelper.optionalField((Codec)SerializableDataTypes.NBT, (String)"tag").forGetter(FireProjectileConfiguration::tag), (App)ConfiguredEntityAction.optional("projectile_action").forGetter(FireProjectileConfiguration::projectileAction)).apply((Applicative)instance, FireProjectileConfiguration::new));
}

