/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 */
package io.github.edwinmindcraft.apoli.common.action.entity;

import com.mojang.serialization.Codec;
import io.github.apace100.apoli.util.ResourceOperation;
import io.github.edwinmindcraft.apoli.api.ApoliAPI;
import io.github.edwinmindcraft.apoli.api.component.IPowerContainer;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import io.github.edwinmindcraft.apoli.common.action.configuration.ChangeResourceConfiguration;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public class ChangeResourceAction
extends EntityAction<ChangeResourceConfiguration> {
    public ChangeResourceAction(Codec<ChangeResourceConfiguration> codec) {
        super(codec);
    }

    @Override
    public void execute(ChangeResourceConfiguration configuration, Entity entity) {
        if (entity instanceof LivingEntity) {
            LivingEntity living = (LivingEntity)entity;
            if (configuration.resource().m_203633_()) {
                ConfiguredPower power = (ConfiguredPower)configuration.resource().m_203334_();
                if (IPowerContainer.get(entity).resolve().flatMap(x -> configuration.resource().m_203543_().map(x::hasPower)).orElse(false).booleanValue()) {
                    if (configuration.operation() == ResourceOperation.ADD) {
                        power.change((Entity)living, configuration.amount());
                    } else if (configuration.operation() == ResourceOperation.SET) {
                        power.assign((Entity)living, configuration.amount());
                    }
                    ApoliAPI.synchronizePowerContainer((Entity)living);
                }
            }
        }
    }
}

