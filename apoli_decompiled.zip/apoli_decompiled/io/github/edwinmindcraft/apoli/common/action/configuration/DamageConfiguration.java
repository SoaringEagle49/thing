/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.world.damagesource.DamageType
 */
package io.github.edwinmindcraft.apoli.common.action.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.data.DamageSourceDescription;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import java.util.Optional;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.damagesource.DamageType;

public record DamageConfiguration(Optional<ResourceKey<DamageType>> damageType, Optional<DamageSourceDescription> source, float amount) implements IDynamicFeatureConfiguration
{
    public static final Codec<DamageConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)CalioCodecHelper.optionalField((Codec)SerializableDataTypes.DAMAGE_TYPE, (String)"damage_type").forGetter(DamageConfiguration::damageType), (App)CalioCodecHelper.optionalField(ApoliDataTypes.DAMAGE_SOURCE_DESCRIPTION, (String)"source").forGetter(DamageConfiguration::source), (App)CalioCodecHelper.FLOAT.fieldOf("amount").forGetter(DamageConfiguration::amount)).apply((Applicative)instance, DamageConfiguration::new));
}

