/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.level.Explosion
 *  net.minecraft.world.level.Explosion$BlockInteraction
 *  net.minecraft.world.level.ExplosionDamageCalculator
 *  net.minecraft.world.level.Level
 *  org.jetbrains.annotations.NotNull
 */
package io.github.edwinmindcraft.apoli.common.action.entity;

import io.github.apace100.apoli.action.configuration.ExplodeConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import io.github.edwinmindcraft.apoli.common.registry.condition.ApoliDefaultConditions;
import javax.annotation.Nullable;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.ExplosionDamageCalculator;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;

public class ExplodeAction
extends EntityAction<ExplodeConfiguration> {
    public ExplodeAction() {
        super(ExplodeConfiguration.CODEC);
    }

    @Override
    public void execute(@NotNull ExplodeConfiguration configuration, @NotNull Entity entity) {
        if (entity.m_9236_().m_5776_()) {
            return;
        }
        ExplosionDamageCalculator calculator = !configuration.indestructible().m_203373_(ApoliDefaultConditions.BLOCK_DEFAULT.getId()) ? configuration.calculator() : null;
        ExplodeAction.explode(entity.m_9236_(), configuration.damageSelf() ? null : entity, entity.m_9236_().m_269111_().m_269093_(null), calculator, entity.m_20185_(), entity.m_20186_(), entity.m_20189_(), configuration.power(), configuration.createFire(), configuration.destructionType());
    }

    private static void explode(Level world, @Nullable Entity entity, DamageSource damageSource, ExplosionDamageCalculator behavior, double x, double y, double z, float power, boolean createFire, Explosion.BlockInteraction destructionType) {
        Explosion explosion = new Explosion(world, entity, damageSource, behavior, x, y, z, power, createFire, destructionType);
        explosion.m_46061_();
        explosion.m_46075_(true);
    }
}

