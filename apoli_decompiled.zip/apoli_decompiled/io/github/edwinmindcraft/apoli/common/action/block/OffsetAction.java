/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.core.Vec3i
 *  net.minecraft.world.level.Level
 */
package io.github.edwinmindcraft.apoli.common.action.block;

import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBlockAction;
import io.github.edwinmindcraft.apoli.api.power.factory.BlockAction;
import io.github.edwinmindcraft.apoli.common.action.configuration.OffsetConfiguration;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.world.level.Level;

public class OffsetAction
extends BlockAction<OffsetConfiguration<ConfiguredBlockAction<?, ?>>> {
    public OffsetAction() {
        super(OffsetConfiguration.codec(ConfiguredBlockAction.required("action")));
    }

    @Override
    public void execute(OffsetConfiguration<ConfiguredBlockAction<?, ?>> configuration, Level world, BlockPos pos, Direction direction) {
        ConfiguredBlockAction.execute(configuration.value(), world, pos.m_121955_((Vec3i)configuration.asBlockPos()), direction);
    }
}

