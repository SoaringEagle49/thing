/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.core.Holder
 *  net.minecraft.core.Holder$Reference
 */
package io.github.edwinmindcraft.apoli.common.action.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.util.ResourceOperation;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import net.minecraft.core.Holder;

public record ChangeResourceConfiguration(Holder<ConfiguredPower<?, ?>> resource, int amount, ResourceOperation operation) implements IDynamicFeatureConfiguration
{
    public static final Codec<ChangeResourceConfiguration> ANY_CODEC = RecordCodecBuilder.create(instance -> instance.group((App)ConfiguredPower.CODEC_SET.holderRef().fieldOf("resource").forGetter(ChangeResourceConfiguration::resource), (App)CalioCodecHelper.INT.fieldOf("change").forGetter(ChangeResourceConfiguration::amount), (App)CalioCodecHelper.optionalField(ApoliDataTypes.RESOURCE_OPERATION, (String)"operation", (Object)((Object)ResourceOperation.ADD)).forGetter(ChangeResourceConfiguration::operation)).apply((Applicative)instance, ChangeResourceConfiguration::new));
    public static final Codec<ChangeResourceConfiguration> SET_CODEC = RecordCodecBuilder.create(instance -> instance.group((App)ConfiguredPower.CODEC_SET.holderRef().fieldOf("resource").forGetter(ChangeResourceConfiguration::resource), (App)CalioCodecHelper.INT.fieldOf("value").forGetter(ChangeResourceConfiguration::amount)).apply((Applicative)instance, (resource, amount) -> new ChangeResourceConfiguration((Holder<ConfiguredPower<?, ?>>)resource, (int)amount, ResourceOperation.SET)));

    @Override
    public boolean isConfigurationValid() {
        return this.amount() != 0;
    }

    @Override
    public String toString() {
        Holder.Reference ref;
        Holder<ConfiguredPower<?, ?>> holder = this.resource();
        return "ChangeResourceConfiguration{resource=" + (Comparable)(holder instanceof Holder.Reference ? ((ref = (Holder.Reference)holder).m_203633_() ? ref.m_205785_() : "Unbound") : "Unsupported") + ", amount=" + this.amount + ", operation=" + this.operation + "}";
    }
}

