/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  javax.annotation.Nullable
 *  net.minecraft.core.Holder
 *  net.minecraft.world.entity.EquipmentSlot
 *  net.minecraft.world.item.ItemStack
 */
package io.github.edwinmindcraft.apoli.common.action.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredItemAction;
import io.github.edwinmindcraft.apoli.common.registry.action.ApoliDefaultActions;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

public record GiveConfiguration(ItemStack stack, Holder<ConfiguredItemAction<?, ?>> action, @Nullable EquipmentSlot slot) implements IDynamicFeatureConfiguration
{
    public static final Codec<GiveConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)SerializableDataTypes.ITEM_STACK.fieldOf("stack").forGetter(GiveConfiguration::stack), (App)ConfiguredItemAction.optional("item_action").forGetter(GiveConfiguration::action), (App)CalioCodecHelper.optionalField((Codec)SerializableDataTypes.EQUIPMENT_SLOT, (String)"preferred_slot").forGetter(x -> Optional.ofNullable(x.slot()))).apply((Applicative)instance, (t1, t2, t3) -> new GiveConfiguration((ItemStack)t1, (Holder<ConfiguredItemAction<?, ?>>)t2, t3.orElse(null))));

    public GiveConfiguration(ItemStack stack) {
        this(stack, (Holder)ApoliDefaultActions.ITEM_DEFAULT.getHolder().orElseThrow(), null);
    }
}

