/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.apace100.calio.util.ArgumentWrapper
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.core.Holder
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.item.ItemStack
 */
package io.github.edwinmindcraft.apoli.common.action.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.util.InventoryUtil;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.apace100.calio.util.ArgumentWrapper;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.configuration.ListConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredEntityAction;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredItemAction;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredItemCondition;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

public record ReplaceInventoryConfiguration(InventoryUtil.InventoryType inventoryType, Holder<ConfiguredEntityAction<?, ?>> entityAction, Holder<ConfiguredItemAction<?, ?>> itemAction, Holder<ConfiguredItemCondition<?, ?>> itemCondition, ListConfiguration<ArgumentWrapper<Integer>> slots, Optional<ResourceLocation> power, ItemStack stack, boolean mergeNbt) implements IDynamicFeatureConfiguration
{
    public static final Codec<ReplaceInventoryConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)CalioCodecHelper.optionalField(ApoliDataTypes.INVENTORY_TYPE, (String)"inventory_type", (Object)((Object)InventoryUtil.InventoryType.INVENTORY)).forGetter(ReplaceInventoryConfiguration::inventoryType), (App)ConfiguredEntityAction.optional("entity_action").forGetter(ReplaceInventoryConfiguration::entityAction), (App)ConfiguredItemAction.optional("item_action").forGetter(ReplaceInventoryConfiguration::itemAction), (App)ConfiguredItemCondition.optional("item_condition").forGetter(ReplaceInventoryConfiguration::itemCondition), (App)ListConfiguration.mapCodec(ApoliDataTypes.ITEM_SLOT, "slot", "slots").forGetter(ReplaceInventoryConfiguration::slots), (App)CalioCodecHelper.optionalField((Codec)SerializableDataTypes.IDENTIFIER, (String)"power").forGetter(ReplaceInventoryConfiguration::power), (App)SerializableDataTypes.ITEM_STACK.fieldOf("stack").forGetter(ReplaceInventoryConfiguration::stack), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.BOOL, (String)"merge_nbt", (Object)false).forGetter(ReplaceInventoryConfiguration::mergeNbt)).apply((Applicative)instance, ReplaceInventoryConfiguration::new));
}

