/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  io.github.edwinmindcraft.calio.api.network.OptionalFuncs
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.EquipmentSlot
 *  org.jetbrains.annotations.Nullable
 */
package io.github.edwinmindcraft.apoli.common.action.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import io.github.edwinmindcraft.calio.api.network.OptionalFuncs;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import org.jetbrains.annotations.Nullable;

public record ItemHasPowerConfiguration(@Nullable EquipmentSlot slot, ResourceLocation power) implements IDynamicFeatureConfiguration
{
    public static final Codec<ItemHasPowerConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)CalioCodecHelper.optionalField((Codec)SerializableDataTypes.EQUIPMENT_SLOT, (String)"slot").forGetter(OptionalFuncs.opt(ItemHasPowerConfiguration::slot)), (App)SerializableDataTypes.IDENTIFIER.fieldOf("power").forGetter(ItemHasPowerConfiguration::power)).apply((Applicative)instance, (equipmentSlot, integerComparisonConfiguration) -> new ItemHasPowerConfiguration(equipmentSlot.orElse(null), (ResourceLocation)integerComparisonConfiguration)));

    public EquipmentSlot[] target() {
        EquipmentSlot[] equipmentSlotArray;
        if (this.slot() == null) {
            equipmentSlotArray = EquipmentSlot.values();
        } else {
            EquipmentSlot[] equipmentSlotArray2 = new EquipmentSlot[1];
            equipmentSlotArray = equipmentSlotArray2;
            equipmentSlotArray2[0] = this.slot();
        }
        return equipmentSlotArray;
    }
}

