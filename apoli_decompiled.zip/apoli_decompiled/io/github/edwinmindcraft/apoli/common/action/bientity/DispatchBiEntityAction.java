/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 */
package io.github.edwinmindcraft.apoli.common.action.bientity;

import io.github.edwinmindcraft.apoli.api.configuration.HolderConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredEntityAction;
import io.github.edwinmindcraft.apoli.api.power.factory.BiEntityAction;
import java.util.function.BinaryOperator;
import net.minecraft.world.entity.Entity;

public class DispatchBiEntityAction
extends BiEntityAction<HolderConfiguration<ConfiguredEntityAction<?, ?>>> {
    private final BinaryOperator<Entity> selector;

    public static DispatchBiEntityAction target() {
        return new DispatchBiEntityAction((actor, target) -> target);
    }

    public static DispatchBiEntityAction actor() {
        return new DispatchBiEntityAction((actor, target) -> actor);
    }

    private DispatchBiEntityAction(BinaryOperator<Entity> selector) {
        super(HolderConfiguration.required(ConfiguredEntityAction.required("action")));
        this.selector = selector;
    }

    @Override
    public void execute(HolderConfiguration<ConfiguredEntityAction<?, ?>> configuration, Entity actor, Entity target) {
        ConfiguredEntityAction.execute(configuration.holder(), (Entity)this.selector.apply(actor, target));
    }
}

