/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.sounds.SoundSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.monster.Monster
 *  net.minecraft.world.entity.player.Player
 */
package io.github.edwinmindcraft.apoli.common.action.entity;

import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import io.github.edwinmindcraft.apoli.common.action.configuration.PlaySoundConfiguration;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;

public class PlaySoundAction
extends EntityAction<PlaySoundConfiguration> {
    public PlaySoundAction() {
        super(PlaySoundConfiguration.CODEC);
    }

    @Override
    public void execute(PlaySoundConfiguration configuration, Entity entity) {
        SoundSource source = entity instanceof Player ? SoundSource.PLAYERS : (entity instanceof Monster ? SoundSource.HOSTILE : SoundSource.NEUTRAL);
        entity.m_9236_().m_6263_(null, entity.m_20185_(), entity.m_20186_(), entity.m_20189_(), configuration.sound(), source, configuration.volume(), configuration.pitch());
    }
}

