/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  io.github.edwinmindcraft.calio.api.network.OptionalFuncs
 *  net.minecraft.resources.ResourceLocation
 *  org.jetbrains.annotations.UnknownNullability
 */
package io.github.edwinmindcraft.apoli.common.action.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.configuration.PowerReference;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import io.github.edwinmindcraft.calio.api.network.OptionalFuncs;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.UnknownNullability;

public record PowerSourceConfiguration(PowerReference power, @UnknownNullability ResourceLocation source) implements IDynamicFeatureConfiguration
{
    public static final Codec<PowerSourceConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)PowerReference.mapCodec("power").forGetter(PowerSourceConfiguration::power), (App)SerializableDataTypes.IDENTIFIER.fieldOf("source").forGetter(PowerSourceConfiguration::source)).apply((Applicative)instance, PowerSourceConfiguration::new));
    public static final Codec<PowerSourceConfiguration> OPTIONAL_CODEC = RecordCodecBuilder.create(instance -> instance.group((App)PowerReference.mapCodec("power").forGetter(PowerSourceConfiguration::power), (App)CalioCodecHelper.optionalField((Codec)SerializableDataTypes.IDENTIFIER, (String)"source").forGetter(OptionalFuncs.opt(PowerSourceConfiguration::source))).apply((Applicative)instance, (power1, source1) -> new PowerSourceConfiguration((PowerReference)power1, source1.orElse(null))));
}

