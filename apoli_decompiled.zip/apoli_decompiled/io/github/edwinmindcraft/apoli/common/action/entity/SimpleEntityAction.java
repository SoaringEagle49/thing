/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.player.Player
 */
package io.github.edwinmindcraft.apoli.common.action.entity;

import io.github.edwinmindcraft.apoli.api.configuration.NoConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import java.util.function.Consumer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

public class SimpleEntityAction
extends EntityAction<NoConfiguration> {
    private final Consumer<Entity> action;

    public static SimpleEntityAction ofLiving(Consumer<LivingEntity> action) {
        return new SimpleEntityAction(e -> {
            if (e instanceof LivingEntity) {
                LivingEntity le = (LivingEntity)e;
                action.accept(le);
            }
        });
    }

    public static SimpleEntityAction ofPlayer(Consumer<Player> action) {
        return new SimpleEntityAction(e -> {
            if (e instanceof Player) {
                Player le = (Player)e;
                action.accept(le);
            }
        });
    }

    public SimpleEntityAction(Consumer<Entity> action) {
        super(NoConfiguration.CODEC);
        this.action = action;
    }

    @Override
    public void execute(NoConfiguration configuration, Entity entity) {
        this.action.accept(entity);
    }
}

