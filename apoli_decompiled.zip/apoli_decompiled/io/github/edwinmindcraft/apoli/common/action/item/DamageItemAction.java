/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.RandomSource
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.enchantment.DigDurabilityEnchantment
 *  net.minecraft.world.item.enchantment.Enchantment
 *  net.minecraft.world.item.enchantment.EnchantmentHelper
 *  net.minecraft.world.item.enchantment.Enchantments
 *  net.minecraft.world.level.Level
 *  org.apache.commons.lang3.mutable.Mutable
 */
package io.github.edwinmindcraft.apoli.common.action.item;

import io.github.edwinmindcraft.apoli.api.power.factory.ItemAction;
import io.github.edwinmindcraft.apoli.common.action.configuration.DamageItemConfiguration;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.DigDurabilityEnchantment;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import org.apache.commons.lang3.mutable.Mutable;

public class DamageItemAction
extends ItemAction<DamageItemConfiguration> {
    public DamageItemAction() {
        super(DamageItemConfiguration.CODEC);
    }

    @Override
    public void execute(DamageItemConfiguration configuration, Level level, Mutable<ItemStack> stack) {
        ItemStack is = (ItemStack)stack.getValue();
        if (is.m_41763_()) {
            int i;
            int amount = configuration.amount();
            if (amount > 0 && !configuration.ignoreUnbreaking()) {
                i = EnchantmentHelper.m_44843_((Enchantment)Enchantments.f_44986_, (ItemStack)is);
                int j = 0;
                for (int k = 0; i > 0 && k < amount; ++k) {
                    if (!DigDurabilityEnchantment.m_220282_((ItemStack)is, (int)i, (RandomSource)level.f_46441_)) continue;
                    ++j;
                }
                if ((amount -= j) <= 0) {
                    return;
                }
            }
            i = is.m_41773_() + amount;
            is.m_41721_(i);
            if (i >= is.m_41776_()) {
                is.m_41774_(1);
                is.m_41721_(0);
            }
        }
    }
}

