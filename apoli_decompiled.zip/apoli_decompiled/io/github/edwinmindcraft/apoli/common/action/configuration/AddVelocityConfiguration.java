/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  org.joml.Vector3f
 */
package io.github.edwinmindcraft.apoli.common.action.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.util.Space;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import org.joml.Vector3f;

public record AddVelocityConfiguration(Vector3f direction, Space space, boolean set, boolean client, boolean server) implements IDynamicFeatureConfiguration
{
    public static final Codec<AddVelocityConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)CalioCodecHelper.VEC3F.forGetter(AddVelocityConfiguration::direction), (App)CalioCodecHelper.optionalField(ApoliDataTypes.SPACE, (String)"space", (Object)((Object)Space.WORLD)).forGetter(AddVelocityConfiguration::space), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.BOOL, (String)"set", (Object)false).forGetter(AddVelocityConfiguration::set), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.BOOL, (String)"client", (Object)true).forGetter(AddVelocityConfiguration::client), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.BOOL, (String)"server", (Object)true).forGetter(AddVelocityConfiguration::server)).apply((Applicative)instance, AddVelocityConfiguration::new));
}

