/*
 * Decompiled with CFR 0.152.
 */
package io.github.edwinmindcraft.apoli.common.action.meta;

import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;

public interface IDelegatedActionConfiguration<V>
extends IDynamicFeatureConfiguration {
    public void execute(V var1);
}

