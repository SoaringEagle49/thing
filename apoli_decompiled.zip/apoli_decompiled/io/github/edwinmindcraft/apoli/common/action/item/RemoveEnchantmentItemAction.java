/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.item.enchantment.Enchantment
 *  net.minecraft.world.item.enchantment.EnchantmentHelper
 *  net.minecraft.world.level.Level
 *  org.apache.commons.lang3.mutable.Mutable
 */
package io.github.edwinmindcraft.apoli.common.action.item;

import io.github.edwinmindcraft.apoli.api.power.factory.ItemAction;
import io.github.edwinmindcraft.apoli.common.action.configuration.RemoveEnchantmentConfiguration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;
import org.apache.commons.lang3.mutable.Mutable;

public class RemoveEnchantmentItemAction
extends ItemAction<RemoveEnchantmentConfiguration> {
    public RemoveEnchantmentItemAction() {
        super(RemoveEnchantmentConfiguration.CODEC);
    }

    @Override
    public void execute(RemoveEnchantmentConfiguration configuration, Level level, Mutable<ItemStack> stack) {
        if (!((ItemStack)stack.getValue()).m_41782_()) {
            return;
        }
        int levels = configuration.levels().isPresent() ? configuration.levels().get() : -1;
        List<Enchantment> enchs = configuration.enchantments().entries();
        LinkedHashMap<Enchantment, Integer> enchants = EnchantmentHelper.m_44831_((ItemStack)((ItemStack)stack.getValue()));
        if (enchs.size() > 0) {
            for (Enchantment ench : enchs) {
                int newLevel;
                int n = newLevel = levels == -1 ? 0 : (Integer)enchants.get(ench) - levels;
                if (newLevel <= 0) {
                    enchants.remove(ench);
                    continue;
                }
                enchants.put(ench, newLevel);
            }
        } else {
            LinkedHashMap<Enchantment, Integer> newEnchants = new LinkedHashMap<Enchantment, Integer>();
            for (Enchantment e : enchants.keySet()) {
                int newLevel = levels == -1 ? 0 : (Integer)enchants.get(e) - levels;
                if (newLevel <= 0) continue;
                newEnchants.put(e, newLevel);
            }
            enchants = newEnchants;
        }
        EnchantmentHelper.m_44865_((Map)enchants, (ItemStack)((ItemStack)stack.getValue()));
        if (configuration.resetRepairCost() && !((ItemStack)stack.getValue()).m_41793_()) {
            ((ItemStack)stack.getValue()).m_41742_(0);
        }
    }
}

