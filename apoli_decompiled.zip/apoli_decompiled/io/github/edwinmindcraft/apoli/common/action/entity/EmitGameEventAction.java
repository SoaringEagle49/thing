/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.level.gameevent.GameEvent
 */
package io.github.edwinmindcraft.apoli.common.action.entity;

import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.configuration.FieldConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.gameevent.GameEvent;

public class EmitGameEventAction
extends EntityAction<FieldConfiguration<GameEvent>> {
    public EmitGameEventAction() {
        super(FieldConfiguration.codec(SerializableDataTypes.GAME_EVENT, "event"));
    }

    @Override
    public void execute(FieldConfiguration<GameEvent> configuration, Entity entity) {
        entity.m_146850_(configuration.value());
    }
}

