/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 */
package io.github.edwinmindcraft.apoli.common.action.entity;

import io.github.edwinmindcraft.apoli.api.ApoliAPI;
import io.github.edwinmindcraft.apoli.api.component.IPowerContainer;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredModifier;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import io.github.edwinmindcraft.apoli.common.action.configuration.ModifyResourceConfiguration;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

public class ModifyResourceAction
extends EntityAction<ModifyResourceConfiguration> {
    public ModifyResourceAction() {
        super(ModifyResourceConfiguration.CODEC);
    }

    @Override
    public void execute(ModifyResourceConfiguration configuration, Entity entity) {
        if (entity instanceof Player) {
            Player player = (Player)entity;
            if (configuration.resource().m_203633_()) {
                ConfiguredPower power = (ConfiguredPower)configuration.resource().m_203334_();
                if (IPowerContainer.get(entity).resolve().flatMap(x -> configuration.resource().m_203543_().map(x::hasPower)).orElse(false).booleanValue()) {
                    power.assign(entity, (int)ConfiguredModifier.apply(configuration.modifier(), entity, power.getValue(entity).orElse(0)));
                    ApoliAPI.synchronizePowerContainer((Entity)player);
                }
            }
        }
    }
}

