/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.util.Mth
 *  net.minecraft.util.RandomSource
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.projectile.AbstractHurtingProjectile
 *  net.minecraft.world.entity.projectile.Projectile
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.phys.Vec3
 */
package io.github.edwinmindcraft.apoli.common.action.entity;

import io.github.apace100.apoli.util.MiscUtil;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredEntityAction;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import io.github.edwinmindcraft.apoli.common.action.configuration.FireProjectileConfiguration;
import java.util.Optional;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.AbstractHurtingProjectile;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class FireProjectileAction
extends EntityAction<FireProjectileConfiguration> {
    public FireProjectileAction() {
        super(FireProjectileConfiguration.CODEC);
    }

    @Override
    public void execute(FireProjectileConfiguration configuration, Entity entity) {
        if (entity.m_9236_().m_5776_()) {
            return;
        }
        ServerLevel serverWorld = (ServerLevel)entity.m_9236_();
        for (int i = 0; i < configuration.count(); ++i) {
            float yaw = entity.m_146908_();
            float pitch = entity.m_146909_();
            Optional<Entity> opt$entityToSpawn = MiscUtil.getEntityWithPassengers((Level)serverWorld, configuration.entityType(), configuration.tag().orElse(null), entity.m_20182_().m_82520_(0.0, (double)entity.m_20236_(entity.m_20089_()), 0.0), yaw, pitch);
            if (opt$entityToSpawn.isEmpty()) {
                return;
            }
            Vec3 rotationVector = entity.m_20154_();
            Vec3 velocity = entity.m_20184_();
            Entity entityToSpawn = opt$entityToSpawn.get();
            if (entityToSpawn instanceof Projectile) {
                Projectile projectileToSpawn = (Projectile)entityToSpawn;
                if (projectileToSpawn instanceof AbstractHurtingProjectile) {
                    AbstractHurtingProjectile ahp = (AbstractHurtingProjectile)projectileToSpawn;
                    ahp.f_36813_ = rotationVector.f_82479_ * (double)configuration.speed();
                    ahp.f_36814_ = rotationVector.f_82480_ * (double)configuration.speed();
                    ahp.f_36815_ = rotationVector.f_82481_ * (double)configuration.speed();
                }
                projectileToSpawn.m_5602_(entity);
                projectileToSpawn.m_37251_(entity, pitch, yaw, 0.0f, configuration.speed(), configuration.divergence());
            } else {
                float j = (float)Math.PI / 180;
                double k = 0.0075f;
                float l = -Mth.m_14031_((float)(yaw * j)) * Mth.m_14089_((float)(pitch * j));
                float m = -Mth.m_14031_((float)(pitch * j));
                float n = Mth.m_14089_((float)(yaw * j)) * Mth.m_14089_((float)(pitch * j));
                RandomSource random = serverWorld.m_213780_();
                Vec3 vec3d = new Vec3((double)l, (double)m, (double)n).m_82541_().m_82520_(random.m_188583_() * k * (double)configuration.divergence(), random.m_188583_() * k * (double)configuration.divergence(), random.m_188583_() * k * (double)configuration.divergence()).m_82490_((double)configuration.speed());
                entityToSpawn.m_20256_(vec3d);
                entityToSpawn.m_20256_(entity.m_20184_().m_82520_(velocity.f_82479_, entity.m_20096_() ? 0.0 : velocity.f_82480_, velocity.f_82481_));
            }
            serverWorld.m_8860_(entityToSpawn);
            ConfiguredEntityAction.execute(configuration.projectileAction(), entityToSpawn);
        }
    }
}

