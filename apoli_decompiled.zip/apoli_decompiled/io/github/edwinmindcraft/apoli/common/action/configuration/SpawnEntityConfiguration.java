/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.ImmutableList$Builder
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  io.github.edwinmindcraft.calio.api.registry.ICalioDynamicRegistryManager
 *  net.minecraft.core.Holder
 *  net.minecraft.nbt.CompoundTag
 *  net.minecraft.world.entity.EntityType
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 */
package io.github.edwinmindcraft.apoli.common.action.configuration;

import com.google.common.collect.ImmutableList;
import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredEntityAction;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import io.github.edwinmindcraft.calio.api.registry.ICalioDynamicRegistryManager;
import java.util.List;
import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.EntityType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public record SpawnEntityConfiguration(EntityType<?> type, @Nullable CompoundTag tag, Holder<ConfiguredEntityAction<?, ?>> action) implements IDynamicFeatureConfiguration
{
    public static final Codec<SpawnEntityConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)SerializableDataTypes.ENTITY_TYPE.fieldOf("entity_type").forGetter(SpawnEntityConfiguration::type), (App)CalioCodecHelper.optionalField((Codec)SerializableDataTypes.NBT, (String)"tag").forGetter(x -> Optional.ofNullable(x.tag())), (App)ConfiguredEntityAction.optional("entity_action").forGetter(SpawnEntityConfiguration::action)).apply((Applicative)instance, (t1, t2, t3) -> new SpawnEntityConfiguration((EntityType<?>)t1, t2.orElse(null), (Holder<ConfiguredEntityAction<?, ?>>)t3)));

    @Override
    @NotNull
    public List<String> getErrors(@NotNull ICalioDynamicRegistryManager server) {
        ImmutableList.Builder builder = ImmutableList.builder();
        if (this.action().m_203633_()) {
            builder.addAll(((ConfiguredEntityAction)this.action().m_203334_()).getErrors(server).stream().map(arg_0 -> SpawnEntityConfiguration.lambda$getErrors$3("SpawnEntity/%s", arg_0)).toList());
        }
        return builder.build();
    }

    @Override
    @NotNull
    public List<String> getWarnings(@NotNull ICalioDynamicRegistryManager server) {
        ImmutableList.Builder builder = ImmutableList.builder();
        if (this.action().m_203633_()) {
            builder.addAll(((ConfiguredEntityAction)this.action().m_203334_()).getWarnings(server).stream().map(arg_0 -> SpawnEntityConfiguration.lambda$getWarnings$4("SpawnEntity/%s", arg_0)).toList());
        }
        return builder.build();
    }

    private static /* synthetic */ String lambda$getWarnings$4(String rec$, Object xva$0) {
        return "SpawnEntity/%s".formatted(xva$0);
    }

    private static /* synthetic */ String lambda$getErrors$3(String rec$, Object xva$0) {
        return "SpawnEntity/%s".formatted(xva$0);
    }
}

