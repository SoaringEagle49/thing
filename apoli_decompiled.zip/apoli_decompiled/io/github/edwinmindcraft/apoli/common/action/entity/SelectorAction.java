/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.exceptions.CommandSyntaxException
 *  net.minecraft.commands.CommandSource
 *  net.minecraft.commands.CommandSourceStack
 *  net.minecraft.commands.arguments.selector.EntitySelector
 *  net.minecraft.server.MinecraftServer
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.world.entity.Entity
 */
package io.github.edwinmindcraft.apoli.common.action.entity;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiEntityAction;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiEntityCondition;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import io.github.edwinmindcraft.apoli.common.action.configuration.SelectorConfiguration;
import net.minecraft.commands.CommandSource;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.arguments.selector.EntitySelector;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;

public class SelectorAction
extends EntityAction<SelectorConfiguration> {
    public SelectorAction() {
        super(SelectorConfiguration.CODEC);
    }

    @Override
    public void execute(SelectorConfiguration configuration, Entity entity) {
        MinecraftServer server = entity.m_20194_();
        if (server == null) {
            return;
        }
        CommandSourceStack source = new CommandSourceStack(CommandSource.f_80164_, entity.m_20182_(), entity.m_20155_(), (ServerLevel)entity.m_9236_(), 2, entity.m_6302_(), entity.m_7755_(), server, entity);
        try {
            ((EntitySelector)configuration.selector().get()).m_121160_(source).stream().filter(e -> ConfiguredBiEntityCondition.check(configuration.biEntityCondition(), entity, e)).forEach(e -> ConfiguredBiEntityAction.execute(configuration.biEntityAction(), entity, e));
        }
        catch (CommandSyntaxException commandSyntaxException) {
            // empty catch block
        }
    }
}

