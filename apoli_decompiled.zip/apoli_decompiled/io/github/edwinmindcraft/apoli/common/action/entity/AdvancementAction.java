/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  net.minecraft.advancements.Advancement
 *  net.minecraft.advancements.AdvancementProgress
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.server.level.ServerPlayer
 *  net.minecraft.world.entity.Entity
 */
package io.github.edwinmindcraft.apoli.common.action.entity;

import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.configuration.FieldConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import java.util.function.BiConsumer;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

public class AdvancementAction
extends EntityAction<FieldConfiguration<ResourceLocation>> {
    private final BiConsumer<ServerPlayer, Advancement> action;

    public static AdvancementAction grant() {
        return new AdvancementAction((player, advancement) -> {
            AdvancementProgress advancementProgress = player.m_8960_().m_135996_(advancement);
            if (!advancementProgress.m_8193_()) {
                for (String string : advancementProgress.m_8219_()) {
                    player.m_8960_().m_135988_(advancement, string);
                }
            }
        });
    }

    public static AdvancementAction revoke() {
        return new AdvancementAction((player, advancement) -> {
            AdvancementProgress advancementProgress = player.m_8960_().m_135996_(advancement);
            if (advancementProgress.m_8206_()) {
                for (String string : advancementProgress.m_8220_()) {
                    player.m_8960_().m_135998_(advancement, string);
                }
            }
        });
    }

    protected AdvancementAction(BiConsumer<ServerPlayer, Advancement> action) {
        super(FieldConfiguration.codec(SerializableDataTypes.IDENTIFIER, "advancement"));
        this.action = action;
    }

    @Override
    public void execute(FieldConfiguration<ResourceLocation> location, Entity entity) {
        ServerPlayer player;
        if (entity instanceof ServerPlayer && (player = (ServerPlayer)entity).m_20194_() != null) {
            Advancement adv = player.m_20194_().m_129889_().m_136041_(location.value());
            this.action.accept(player, adv);
        }
    }
}

