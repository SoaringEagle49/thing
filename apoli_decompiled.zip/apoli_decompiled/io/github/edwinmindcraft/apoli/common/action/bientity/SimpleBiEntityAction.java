/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.TamableAnimal
 *  net.minecraft.world.entity.animal.Animal
 *  net.minecraft.world.entity.player.Player
 */
package io.github.edwinmindcraft.apoli.common.action.bientity;

import io.github.edwinmindcraft.apoli.api.configuration.NoConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.BiEntityAction;
import java.util.function.BiConsumer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;

public class SimpleBiEntityAction
extends BiEntityAction<NoConfiguration> {
    private final BiConsumer<Entity, Entity> action;

    public static void mount(Entity actor, Entity target) {
        actor.m_7998_(target, true);
    }

    public static void setInLove(Entity actor, Entity target) {
        if (target instanceof Animal) {
            Animal animal = (Animal)target;
            if (actor instanceof Player) {
                Player player = (Player)actor;
                animal.m_27595_(player);
            }
        }
    }

    public static void tame(Entity actor, Entity target) {
        if (target instanceof TamableAnimal) {
            TamableAnimal animal = (TamableAnimal)target;
            if (actor instanceof Player) {
                Player player = (Player)actor;
                if (!animal.m_21824_()) {
                    animal.m_21828_(player);
                }
            }
        }
    }

    public SimpleBiEntityAction(BiConsumer<Entity, Entity> action) {
        super(NoConfiguration.CODEC);
        this.action = action;
    }

    @Override
    public void execute(NoConfiguration configuration, Entity actor, Entity target) {
        this.action.accept(actor, target);
    }
}

