/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.MapCodec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Holder
 */
package io.github.edwinmindcraft.apoli.common.action.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;

public record OffsetConfiguration<T>(Holder<T> value, int x, int y, int z) implements IDynamicFeatureConfiguration
{
    public static <T> Codec<OffsetConfiguration<T>> codec(MapCodec<Holder<T>> codec) {
        return RecordCodecBuilder.create(instance -> instance.group((App)codec.forGetter(OffsetConfiguration::value), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.INT, (String)"x", (Object)0).forGetter(OffsetConfiguration::x), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.INT, (String)"y", (Object)0).forGetter(OffsetConfiguration::y), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.INT, (String)"z", (Object)0).forGetter(OffsetConfiguration::z)).apply((Applicative)instance, OffsetConfiguration::new));
    }

    public BlockPos asBlockPos() {
        return new BlockPos(this.x, this.y, this.z);
    }
}

