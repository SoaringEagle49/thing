/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.damagesource.DamageSource
 *  net.minecraft.world.entity.Entity
 */
package io.github.edwinmindcraft.apoli.common.action.entity;

import io.github.apace100.apoli.util.MiscUtil;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import io.github.edwinmindcraft.apoli.common.action.configuration.DamageConfiguration;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;

public class DamageAction
extends EntityAction<DamageConfiguration> {
    public DamageAction() {
        super(DamageConfiguration.CODEC);
    }

    @Override
    public void execute(DamageConfiguration configuration, Entity entity) {
        DamageSource source = MiscUtil.createDamageSource(entity.m_269291_(), configuration.source(), configuration.damageType());
        entity.m_6469_(source, configuration.amount());
    }
}

