/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  io.github.edwinmindcraft.calio.api.network.CodecSet
 *  net.minecraft.core.Holder
 */
package io.github.edwinmindcraft.apoli.common.action.meta;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.apoli.util.Scheduler;
import io.github.edwinmindcraft.apoli.common.action.meta.IDelegatedActionConfiguration;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import io.github.edwinmindcraft.calio.api.network.CodecSet;
import java.util.function.BiConsumer;
import net.minecraft.core.Holder;

public record DelayAction<T, V>(Holder<T> action, int delay, BiConsumer<T, V> executor) implements IDelegatedActionConfiguration<V>
{
    private static final Scheduler SCHEDULER = new Scheduler();

    public static <T, V> Codec<DelayAction<T, V>> codec(CodecSet<T> codec, BiConsumer<T, V> executor) {
        return RecordCodecBuilder.create(instance -> instance.group((App)codec.holder().fieldOf("action").forGetter(DelayAction::action), (App)CalioCodecHelper.INT.fieldOf("ticks").forGetter(DelayAction::delay)).apply((Applicative)instance, (action, delay) -> new DelayAction(action, (int)delay, executor)));
    }

    @Override
    public void execute(V parameters) {
        SCHEDULER.queue(m -> this.executor().accept(this.action().m_203334_(), parameters), this.delay());
    }
}

