/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 */
package io.github.edwinmindcraft.apoli.common.action.entity;

import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import io.github.edwinmindcraft.apoli.common.action.configuration.ExperienceConfiguration;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

public class AddExperienceAction
extends EntityAction<ExperienceConfiguration> {
    public AddExperienceAction() {
        super(ExperienceConfiguration.CODEC);
    }

    @Override
    public void execute(ExperienceConfiguration configuration, Entity entity) {
        if (entity instanceof Player) {
            if (configuration.points() > 0) {
                ((Player)entity).m_6756_(configuration.points());
            }
            ((Player)entity).m_6749_(configuration.levels());
        }
    }
}

