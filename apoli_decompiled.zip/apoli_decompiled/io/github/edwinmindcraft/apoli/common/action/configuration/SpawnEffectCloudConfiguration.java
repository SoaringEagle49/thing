/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.world.effect.MobEffectInstance
 */
package io.github.edwinmindcraft.apoli.common.action.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.configuration.ListConfiguration;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import net.minecraft.world.effect.MobEffectInstance;

public record SpawnEffectCloudConfiguration(float radius, float radiusOnUse, int waitTime, ListConfiguration<MobEffectInstance> effects) implements IDynamicFeatureConfiguration
{
    public static final Codec<SpawnEffectCloudConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.FLOAT, (String)"radius", (Object)Float.valueOf(3.0f)).forGetter(x -> Float.valueOf(x.radius)), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.FLOAT, (String)"radius_on_use", (Object)Float.valueOf(-0.5f)).forGetter(x -> Float.valueOf(x.radiusOnUse)), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.INT, (String)"wait_time", (Object)10).forGetter(x -> x.waitTime), (App)ListConfiguration.mapCodec(SerializableDataTypes.STATUS_EFFECT_INSTANCE, "effect", "effects").forGetter(x -> x.effects)).apply((Applicative)instance, SpawnEffectCloudConfiguration::new));
}

