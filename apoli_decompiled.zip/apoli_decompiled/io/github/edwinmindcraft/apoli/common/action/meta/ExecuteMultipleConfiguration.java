/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  io.github.edwinmindcraft.calio.api.network.CodecSet
 *  net.minecraft.core.Holder
 *  net.minecraft.core.HolderSet
 *  org.jetbrains.annotations.NotNull
 */
package io.github.edwinmindcraft.apoli.common.action.meta;

import com.mojang.serialization.Codec;
import io.github.edwinmindcraft.apoli.api.configuration.IStreamConfiguration;
import io.github.edwinmindcraft.apoli.common.action.meta.IDelegatedActionConfiguration;
import io.github.edwinmindcraft.calio.api.network.CodecSet;
import java.util.List;
import java.util.function.BiConsumer;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderSet;
import org.jetbrains.annotations.NotNull;

public record ExecuteMultipleConfiguration<T, V>(List<HolderSet<T>> entries, BiConsumer<T, V> consumer) implements IStreamConfiguration<HolderSet<T>>,
IDelegatedActionConfiguration<V>
{
    public static <T, V> Codec<ExecuteMultipleConfiguration<T, V>> codec(CodecSet<T> codecs, BiConsumer<T, V> consumer) {
        return codecs.set().fieldOf("actions").xmap(x -> new ExecuteMultipleConfiguration(x, consumer), ExecuteMultipleConfiguration::entries).codec();
    }

    @Override
    public void execute(V parameters) {
        this.entries().stream().flatMap(HolderSet::m_203614_).filter(Holder::m_203633_).forEach(holder -> this.consumer().accept(holder.m_203334_(), parameters));
    }

    @Override
    @NotNull
    public String name() {
        return "And";
    }
}

