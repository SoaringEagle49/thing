/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.apace100.calio.util.ArgumentWrapper
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.core.Holder
 *  net.minecraft.resources.ResourceLocation
 */
package io.github.edwinmindcraft.apoli.common.action.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.util.InventoryUtil;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.apace100.calio.util.ArgumentWrapper;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.configuration.ListConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredEntityAction;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredItemAction;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredItemCondition;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;

public record DropInventoryConfiguration(InventoryUtil.InventoryType inventoryType, Holder<ConfiguredEntityAction<?, ?>> entityAction, Holder<ConfiguredItemAction<?, ?>> itemAction, Holder<ConfiguredItemCondition<?, ?>> itemCondition, ListConfiguration<ArgumentWrapper<Integer>> slots, Optional<ResourceLocation> power, boolean throwRandomly, boolean retainOwnership, int amount) implements IDynamicFeatureConfiguration
{
    public static final Codec<DropInventoryConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)CalioCodecHelper.optionalField(ApoliDataTypes.INVENTORY_TYPE, (String)"inventory_type", (Object)((Object)InventoryUtil.InventoryType.INVENTORY)).forGetter(DropInventoryConfiguration::inventoryType), (App)ConfiguredEntityAction.optional("entity_action").forGetter(DropInventoryConfiguration::entityAction), (App)ConfiguredItemAction.optional("item_action").forGetter(DropInventoryConfiguration::itemAction), (App)ConfiguredItemCondition.optional("item_condition").forGetter(DropInventoryConfiguration::itemCondition), (App)ListConfiguration.mapCodec(ApoliDataTypes.ITEM_SLOT, "slot", "slots").forGetter(DropInventoryConfiguration::slots), (App)CalioCodecHelper.optionalField((Codec)SerializableDataTypes.IDENTIFIER, (String)"power").forGetter(DropInventoryConfiguration::power), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.BOOL, (String)"throw_randomly", (Object)false).forGetter(DropInventoryConfiguration::throwRandomly), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.BOOL, (String)"retain_ownership", (Object)true).forGetter(DropInventoryConfiguration::retainOwnership), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.INT, (String)"amount", (Object)0).forGetter(DropInventoryConfiguration::amount)).apply((Applicative)instance, DropInventoryConfiguration::new));
}

