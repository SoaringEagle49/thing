/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.phys.Vec3
 *  org.joml.Vector3f
 *  org.joml.Vector3fc
 */
package io.github.edwinmindcraft.apoli.common.action.bientity;

import io.github.apace100.apoli.util.Space;
import io.github.edwinmindcraft.apoli.api.power.factory.BiEntityAction;
import io.github.edwinmindcraft.apoli.common.action.configuration.AddBiEntityVelocityConfiguration;
import java.util.function.Consumer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;
import org.joml.Vector3fc;

public class AddVelocityAction
extends BiEntityAction<AddBiEntityVelocityConfiguration> {
    public AddVelocityAction() {
        super(AddBiEntityVelocityConfiguration.CODEC);
    }

    @Override
    public void execute(AddBiEntityVelocityConfiguration configuration, Entity actor, Entity target) {
        if (target instanceof Player && (target.m_9236_().m_5776_() ? !configuration.client() : !configuration.server())) {
            return;
        }
        Vector3f vec = new Vector3f((Vector3fc)configuration.direction());
        Consumer<Vec3> method = configuration.set() ? arg_0 -> ((Entity)target).m_20256_(arg_0) : arg_0 -> ((Entity)target).m_246865_(arg_0);
        Space.transformVectorToBase(target.m_20182_().m_82546_(actor.m_20182_()), vec, actor.m_146908_(), true);
        method.accept(new Vec3(vec));
        target.f_19864_ = true;
    }
}

