/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.phys.Vec3
 *  org.joml.Vector3f
 *  org.joml.Vector3fc
 */
package io.github.edwinmindcraft.apoli.common.action.entity;

import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import io.github.edwinmindcraft.apoli.common.action.configuration.AddVelocityConfiguration;
import java.util.function.Consumer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;
import org.joml.Vector3fc;

public class AddVelocityAction
extends EntityAction<AddVelocityConfiguration> {
    public AddVelocityAction() {
        super(AddVelocityConfiguration.CODEC);
    }

    @Override
    public void execute(AddVelocityConfiguration configuration, Entity entity) {
        if (entity instanceof Player && (entity.m_9236_().m_5776_() ? !configuration.client() : !configuration.server())) {
            return;
        }
        Vector3f vec = new Vector3f((Vector3fc)configuration.direction());
        Consumer<Vec3> method = configuration.set() ? arg_0 -> ((Entity)entity).m_20256_(arg_0) : arg_0 -> ((Entity)entity).m_246865_(arg_0);
        configuration.space().toGlobal(vec, entity);
        method.accept(new Vec3(vec));
        entity.f_19864_ = true;
    }
}

