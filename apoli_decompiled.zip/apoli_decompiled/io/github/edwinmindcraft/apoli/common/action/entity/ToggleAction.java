/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Holder
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 */
package io.github.edwinmindcraft.apoli.common.action.entity;

import io.github.edwinmindcraft.apoli.api.component.IPowerContainer;
import io.github.edwinmindcraft.apoli.api.configuration.PowerReference;
import io.github.edwinmindcraft.apoli.api.power.ITogglePower;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

public class ToggleAction
extends EntityAction<PowerReference> {
    public ToggleAction() {
        super(PowerReference.codec("power"));
    }

    @Override
    public void execute(PowerReference configuration, Entity entity) {
        Player player;
        ConfiguredPower power;
        Object f;
        if (entity instanceof Player && (f = (power = (ConfiguredPower)IPowerContainer.get((Entity)(player = (Player)entity)).resolve().map(x -> x.getPower(configuration.power())).map(Holder::m_203334_).orElse(null)).getFactory()) instanceof ITogglePower) {
            ITogglePower cp = (ITogglePower)f;
            cp.toggle(power, (Entity)player);
        }
    }
}

