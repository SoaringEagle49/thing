/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.world.item.enchantment.Enchantment
 */
package io.github.edwinmindcraft.apoli.common.action.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.configuration.ListConfiguration;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import java.util.Optional;
import net.minecraft.world.item.enchantment.Enchantment;

public record RemoveEnchantmentConfiguration(ListConfiguration<Enchantment> enchantments, Optional<Integer> levels, boolean resetRepairCost) implements IDynamicFeatureConfiguration
{
    public static final Codec<RemoveEnchantmentConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)ListConfiguration.mapCodec(SerializableDataTypes.ENCHANTMENT, "enchantment", "enchantments").forGetter(RemoveEnchantmentConfiguration::enchantments), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.INT, (String)"levels").forGetter(RemoveEnchantmentConfiguration::levels), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.BOOL, (String)"reset_repair_cost", (Object)false).forGetter(RemoveEnchantmentConfiguration::resetRepairCost)).apply((Applicative)instance, RemoveEnchantmentConfiguration::new));
}

