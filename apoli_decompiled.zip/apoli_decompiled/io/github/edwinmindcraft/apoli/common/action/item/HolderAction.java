/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Holder
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 *  org.apache.commons.lang3.mutable.Mutable
 */
package io.github.edwinmindcraft.apoli.common.action.item;

import io.github.edwinmindcraft.apoli.api.configuration.FieldConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredEntityAction;
import io.github.edwinmindcraft.apoli.api.power.factory.ItemAction;
import io.github.edwinmindcraft.apoli.common.registry.ApoliCapabilities;
import net.minecraft.core.Holder;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.apache.commons.lang3.mutable.Mutable;

public class HolderAction
extends ItemAction<FieldConfiguration<Holder<ConfiguredEntityAction<?, ?>>>> {
    public HolderAction() {
        super(FieldConfiguration.codec(ConfiguredEntityAction.HOLDER, "entity_action"));
    }

    @Override
    public void execute(FieldConfiguration<Holder<ConfiguredEntityAction<?, ?>>> configuration, Level level, Mutable<ItemStack> stack) {
        if (((ItemStack)stack.getValue()).m_41619_()) {
            return;
        }
        ((ItemStack)stack.getValue()).getCapability(ApoliCapabilities.ENTITY_LINKED_ITEM_STACK).ifPresent(eli -> {
            if (eli.getEntity() == null) {
                return;
            }
            ConfiguredEntityAction.execute((Holder)configuration.value(), eli.getEntity());
        });
    }
}

