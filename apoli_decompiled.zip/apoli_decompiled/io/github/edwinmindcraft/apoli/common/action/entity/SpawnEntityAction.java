/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.server.level.ServerLevel
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.level.Level
 */
package io.github.edwinmindcraft.apoli.common.action.entity;

import io.github.apace100.apoli.util.MiscUtil;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredEntityAction;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import io.github.edwinmindcraft.apoli.common.action.configuration.SpawnEntityConfiguration;
import java.util.Optional;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;

public class SpawnEntityAction
extends EntityAction<SpawnEntityConfiguration> {
    public SpawnEntityAction() {
        super(SpawnEntityConfiguration.CODEC);
    }

    @Override
    public void execute(SpawnEntityConfiguration configuration, Entity entity) {
        if (entity.m_9236_().m_5776_()) {
            return;
        }
        ServerLevel serverWorld = (ServerLevel)entity.m_9236_();
        Optional<Entity> opt$entityToSpawn = MiscUtil.getEntityWithPassengers((Level)serverWorld, configuration.type(), configuration.tag(), entity.m_20182_(), entity.m_146908_(), entity.m_146909_());
        if (opt$entityToSpawn.isEmpty()) {
            return;
        }
        Entity entityToSpawn = opt$entityToSpawn.get();
        serverWorld.m_8860_(entityToSpawn);
        ConfiguredEntityAction.execute(configuration.action(), entityToSpawn);
    }
}

