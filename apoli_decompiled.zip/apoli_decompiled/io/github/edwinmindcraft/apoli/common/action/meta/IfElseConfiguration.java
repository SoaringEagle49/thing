/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.MapCodec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.calio.api.network.CodecSet
 *  net.minecraft.core.Holder
 */
package io.github.edwinmindcraft.apoli.common.action.meta;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.edwinmindcraft.apoli.common.action.meta.IDelegatedActionConfiguration;
import io.github.edwinmindcraft.calio.api.network.CodecSet;
import java.util.function.BiConsumer;
import java.util.function.BiPredicate;
import java.util.function.Function;
import net.minecraft.core.Holder;

public record IfElseConfiguration<C, A, V>(Holder<C> condition, Holder<A> ifAction, Holder<A> elseAction, BiPredicate<C, V> predicate, BiConsumer<A, V> executor) implements IDelegatedActionConfiguration<V>
{
    public static <C, A, V> Codec<IfElseConfiguration<C, A, V>> codec(CodecSet<C> conditionCodec, CodecSet<A> actionCodec, Function<String, MapCodec<Holder<A>>> optional, BiPredicate<C, V> predicate, BiConsumer<A, V> executor) {
        return RecordCodecBuilder.create(instance -> instance.group((App)conditionCodec.holder().fieldOf("condition").forGetter(IfElseConfiguration::condition), (App)actionCodec.holder().fieldOf("if_action").forGetter(IfElseConfiguration::ifAction), (App)((MapCodec)optional.apply("else_action")).forGetter(IfElseConfiguration::elseAction)).apply((Applicative)instance, (c, i, e) -> new IfElseConfiguration(c, i, e, predicate, executor)));
    }

    @Override
    public void execute(V parameters) {
        if (this.predicate().test(this.condition().m_203334_(), parameters)) {
            this.executor().accept(this.ifAction().m_203334_(), parameters);
        } else if (this.elseAction().m_203633_()) {
            this.executor().accept(this.elseAction().m_203334_(), parameters);
        }
    }
}

