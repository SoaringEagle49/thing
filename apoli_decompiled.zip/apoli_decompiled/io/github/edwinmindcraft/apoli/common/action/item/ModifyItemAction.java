/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.server.MinecraftServer
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 *  net.minecraft.world.level.storage.loot.LootContext
 *  net.minecraft.world.level.storage.loot.LootContext$Builder
 *  net.minecraft.world.level.storage.loot.LootDataManager
 *  net.minecraft.world.level.storage.loot.LootDataType
 *  net.minecraft.world.level.storage.loot.LootParams
 *  net.minecraft.world.level.storage.loot.LootParams$Builder
 *  net.minecraft.world.level.storage.loot.functions.LootItemFunction
 *  net.minecraft.world.level.storage.loot.parameters.LootContextParamSets
 *  net.minecraft.world.level.storage.loot.parameters.LootContextParams
 *  net.minecraft.world.phys.Vec3
 *  org.apache.commons.lang3.mutable.Mutable
 */
package io.github.edwinmindcraft.apoli.common.action.item;

import io.github.apace100.apoli.Apoli;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.configuration.FieldConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.ItemAction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.LootDataManager;
import net.minecraft.world.level.storage.loot.LootDataType;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.functions.LootItemFunction;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.Vec3;
import org.apache.commons.lang3.mutable.Mutable;

public class ModifyItemAction
extends ItemAction<FieldConfiguration<ResourceLocation>> {
    public ModifyItemAction() {
        super(FieldConfiguration.codec(SerializableDataTypes.IDENTIFIER, "modifier"));
    }

    @Override
    public void execute(FieldConfiguration<ResourceLocation> configuration, Level level, Mutable<ItemStack> stack) {
        MinecraftServer server = level.m_7654_();
        if (server != null) {
            LootDataManager lootFunctionManager = server.m_278653_();
            LootItemFunction lootFunction = (LootItemFunction)lootFunctionManager.m_278789_(LootDataType.f_278496_, configuration.value());
            if (lootFunction == null) {
                Apoli.LOGGER.info("Unknown item modifier used in `modify` action: " + configuration.value());
                return;
            }
            LootParams lootContextParameterSet = new LootParams.Builder(server.m_129783_()).m_287286_(LootContextParams.f_81460_, (Object)new Vec3(0.0, 0.0, 0.0)).m_287235_(LootContextParamSets.f_81412_);
            LootContext lootContext = new LootContext.Builder(lootContextParameterSet).m_287259_(null);
            ItemStack newStack = (ItemStack)lootFunction.apply((Object)((ItemStack)stack.getValue()), (Object)lootContext);
            stack.setValue((Object)newStack);
        }
    }
}

