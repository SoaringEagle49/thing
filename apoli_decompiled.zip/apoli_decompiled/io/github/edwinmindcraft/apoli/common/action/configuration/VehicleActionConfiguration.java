/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.core.Holder
 */
package io.github.edwinmindcraft.apoli.common.action.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiEntityAction;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiEntityCondition;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredEntityAction;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import net.minecraft.core.Holder;

public record VehicleActionConfiguration(Holder<ConfiguredEntityAction<?, ?>> action, Holder<ConfiguredBiEntityAction<?, ?>> biEntityAction, Holder<ConfiguredBiEntityCondition<?, ?>> biEntityCondition, boolean recursive) implements IDynamicFeatureConfiguration
{
    public static final Codec<VehicleActionConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)ConfiguredEntityAction.optional("action").forGetter(VehicleActionConfiguration::action), (App)ConfiguredBiEntityAction.optional("bientity_action").forGetter(VehicleActionConfiguration::biEntityAction), (App)ConfiguredBiEntityCondition.optional("bientity_condition").forGetter(VehicleActionConfiguration::biEntityCondition), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.BOOL, (String)"recursive", (Object)false).forGetter(VehicleActionConfiguration::recursive)).apply((Applicative)instance, VehicleActionConfiguration::new));
}

