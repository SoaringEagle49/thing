/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.player.Player
 */
package io.github.edwinmindcraft.apoli.common.action.entity;

import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import io.github.edwinmindcraft.apoli.common.action.configuration.FoodConfiguration;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

public class FeedAction
extends EntityAction<FoodConfiguration> {
    public FeedAction() {
        super(FoodConfiguration.CODEC);
    }

    @Override
    public void execute(FoodConfiguration configuration, Entity entity) {
        if (entity instanceof Player) {
            Player player = (Player)entity;
            player.m_36324_().m_38707_(configuration.food(), configuration.saturation());
        }
    }
}

