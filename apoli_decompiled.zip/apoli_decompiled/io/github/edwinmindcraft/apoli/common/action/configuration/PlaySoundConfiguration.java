/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.sounds.SoundEvent
 */
package io.github.edwinmindcraft.apoli.common.action.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import net.minecraft.sounds.SoundEvent;

public record PlaySoundConfiguration(SoundEvent sound, float volume, float pitch) implements IDynamicFeatureConfiguration
{
    public static final Codec<PlaySoundConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)SerializableDataTypes.SOUND_EVENT.fieldOf("sound").forGetter(PlaySoundConfiguration::sound), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.FLOAT, (String)"volume", (Object)Float.valueOf(1.0f)).forGetter(PlaySoundConfiguration::volume), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.FLOAT, (String)"pitch", (Object)Float.valueOf(1.0f)).forGetter(PlaySoundConfiguration::pitch)).apply((Applicative)instance, PlaySoundConfiguration::new));
}

