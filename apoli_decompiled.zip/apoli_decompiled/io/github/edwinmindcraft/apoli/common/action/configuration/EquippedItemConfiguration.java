/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  net.minecraft.core.Holder
 *  net.minecraft.world.entity.EquipmentSlot
 */
package io.github.edwinmindcraft.apoli.common.action.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredItemAction;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.EquipmentSlot;

public record EquippedItemConfiguration(EquipmentSlot slot, Holder<ConfiguredItemAction<?, ?>> action) implements IDynamicFeatureConfiguration
{
    public static final Codec<EquippedItemConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)SerializableDataTypes.EQUIPMENT_SLOT.fieldOf("equipment_slot").forGetter(EquippedItemConfiguration::slot), (App)ConfiguredItemAction.required("action").forGetter(EquippedItemConfiguration::action)).apply((Applicative)instance, EquippedItemConfiguration::new));
}

