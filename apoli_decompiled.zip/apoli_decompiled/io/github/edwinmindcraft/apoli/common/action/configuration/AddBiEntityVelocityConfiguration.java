/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  org.joml.Vector3f
 */
package io.github.edwinmindcraft.apoli.common.action.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import org.joml.Vector3f;

public record AddBiEntityVelocityConfiguration(Vector3f direction, boolean client, boolean server, boolean set) implements IDynamicFeatureConfiguration
{
    public static final Codec<AddBiEntityVelocityConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)CalioCodecHelper.VEC3F.forGetter(AddBiEntityVelocityConfiguration::direction), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.BOOL, (String)"client", (Object)true).forGetter(AddBiEntityVelocityConfiguration::client), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.BOOL, (String)"server", (Object)true).forGetter(AddBiEntityVelocityConfiguration::server), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.BOOL, (String)"set", (Object)false).forGetter(AddBiEntityVelocityConfiguration::set)).apply((Applicative)instance, AddBiEntityVelocityConfiguration::new));
}

