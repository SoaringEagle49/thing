/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.core.Holder
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 */
package io.github.edwinmindcraft.apoli.common.action.entity;

import io.github.edwinmindcraft.apoli.api.component.IPowerContainer;
import io.github.edwinmindcraft.apoli.api.configuration.PowerReference;
import io.github.edwinmindcraft.apoli.api.power.ICooldownPower;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public class TriggerCooldownAction
extends EntityAction<PowerReference> {
    public TriggerCooldownAction() {
        super(PowerReference.codec("power"));
    }

    @Override
    public void execute(PowerReference configuration, Entity entity) {
        Object f;
        LivingEntity living;
        ConfiguredPower power;
        if (entity instanceof LivingEntity && (power = (ConfiguredPower)IPowerContainer.get((Entity)(living = (LivingEntity)entity)).resolve().map(x -> x.getPower(configuration.power())).map(Holder::m_203334_).orElse(null)) != null && (f = power.getFactory()) instanceof ICooldownPower) {
            ICooldownPower cp = (ICooldownPower)f;
            cp.use(power, (Entity)living);
        }
    }
}

