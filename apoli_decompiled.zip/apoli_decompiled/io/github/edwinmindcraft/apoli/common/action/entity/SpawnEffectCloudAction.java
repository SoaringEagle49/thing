/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.effect.MobEffectInstance
 *  net.minecraft.world.entity.AreaEffectCloud
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.item.alchemy.PotionUtils
 */
package io.github.edwinmindcraft.apoli.common.action.entity;

import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import io.github.edwinmindcraft.apoli.common.action.configuration.SpawnEffectCloudConfiguration;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.AreaEffectCloud;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.alchemy.PotionUtils;

public class SpawnEffectCloudAction
extends EntityAction<SpawnEffectCloudConfiguration> {
    public SpawnEffectCloudAction() {
        super(SpawnEffectCloudConfiguration.CODEC);
    }

    @Override
    public void execute(SpawnEffectCloudConfiguration configuration, Entity entity) {
        AreaEffectCloud areaEffectCloudEntity = new AreaEffectCloud(entity.m_9236_(), entity.m_20185_(), entity.m_20186_(), entity.m_20189_());
        if (entity instanceof LivingEntity) {
            areaEffectCloudEntity.m_19718_((LivingEntity)entity);
        }
        areaEffectCloudEntity.m_19712_(configuration.radius());
        areaEffectCloudEntity.m_19732_(configuration.radiusOnUse());
        areaEffectCloudEntity.m_19740_(configuration.waitTime());
        areaEffectCloudEntity.m_19738_(-areaEffectCloudEntity.m_19743_() / (float)areaEffectCloudEntity.m_19748_());
        List<MobEffectInstance> effects = configuration.effects().getContent().stream().map(MobEffectInstance::new).collect(Collectors.toList());
        areaEffectCloudEntity.m_19714_(PotionUtils.m_43564_(effects));
        effects.forEach(arg_0 -> ((AreaEffectCloud)areaEffectCloudEntity).m_19716_(arg_0));
        entity.m_9236_().m_7967_((Entity)areaEffectCloudEntity);
    }
}

