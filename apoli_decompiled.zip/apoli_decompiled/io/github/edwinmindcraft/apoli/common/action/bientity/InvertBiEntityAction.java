/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 */
package io.github.edwinmindcraft.apoli.common.action.bientity;

import io.github.edwinmindcraft.apoli.api.configuration.HolderConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiEntityAction;
import io.github.edwinmindcraft.apoli.api.power.factory.BiEntityAction;
import net.minecraft.world.entity.Entity;

public class InvertBiEntityAction
extends BiEntityAction<HolderConfiguration<ConfiguredBiEntityAction<?, ?>>> {
    public InvertBiEntityAction() {
        super(HolderConfiguration.required(ConfiguredBiEntityAction.required("action")));
    }

    @Override
    public void execute(HolderConfiguration<ConfiguredBiEntityAction<?, ?>> configuration, Entity actor, Entity target) {
        ((ConfiguredBiEntityAction)configuration.holder().m_203334_()).execute(target, actor);
    }
}

