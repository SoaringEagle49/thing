/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.item.ItemEntity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.ItemStack
 *  org.apache.commons.lang3.mutable.Mutable
 *  org.apache.commons.lang3.mutable.MutableObject
 */
package io.github.edwinmindcraft.apoli.common.action.entity;

import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredItemAction;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import io.github.edwinmindcraft.apoli.common.action.configuration.GiveConfiguration;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.apache.commons.lang3.mutable.Mutable;
import org.apache.commons.lang3.mutable.MutableObject;

public class GiveAction
extends EntityAction<GiveConfiguration> {
    public GiveAction() {
        super(GiveConfiguration.CODEC);
    }

    @Override
    public void execute(GiveConfiguration configuration, Entity entity) {
        if (!entity.m_9236_().m_5776_()) {
            if (configuration.stack().m_41619_()) {
                return;
            }
            MutableObject stack = new MutableObject((Object)configuration.stack().m_41777_());
            ConfiguredItemAction.execute(configuration.action(), entity.m_9236_(), (Mutable<ItemStack>)stack);
            if (configuration.slot() != null && entity instanceof LivingEntity) {
                LivingEntity living = (LivingEntity)entity;
                ItemStack stackInSlot = living.m_6844_(configuration.slot());
                if (stackInSlot.m_41619_()) {
                    living.m_8061_(configuration.slot(), (ItemStack)stack.getValue());
                    return;
                }
                if (ItemStack.m_41656_((ItemStack)stackInSlot, (ItemStack)((ItemStack)stack.getValue())) && stackInSlot.m_41613_() < stackInSlot.m_41741_()) {
                    int fit = Math.min(stackInSlot.m_41741_() - stackInSlot.m_41613_(), ((ItemStack)stack.getValue()).m_41613_());
                    stackInSlot.m_41769_(fit);
                    ((ItemStack)stack.getValue()).m_41774_(fit);
                    if (((ItemStack)stack.getValue()).m_41619_()) {
                        return;
                    }
                }
            }
            if (entity instanceof Player) {
                Player player = (Player)entity;
                player.m_150109_().m_150079_((ItemStack)stack.getValue());
            } else {
                entity.m_9236_().m_7967_((Entity)new ItemEntity(entity.m_9236_(), entity.m_20185_(), entity.m_20186_(), entity.m_20189_(), (ItemStack)stack.getValue()));
            }
        }
    }
}

