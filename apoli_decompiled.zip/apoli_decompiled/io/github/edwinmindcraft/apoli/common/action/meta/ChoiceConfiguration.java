/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.ImmutableList$Builder
 *  com.mojang.serialization.Codec
 *  io.github.apace100.calio.FilterableWeightedList
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  io.github.edwinmindcraft.calio.api.network.CodecSet
 *  net.minecraft.core.Holder
 */
package io.github.edwinmindcraft.apoli.common.action.meta;

import com.google.common.collect.ImmutableList;
import com.mojang.serialization.Codec;
import io.github.apace100.calio.FilterableWeightedList;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.configuration.IStreamConfiguration;
import io.github.edwinmindcraft.apoli.common.action.meta.IDelegatedActionConfiguration;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import io.github.edwinmindcraft.calio.api.network.CodecSet;
import java.util.List;
import java.util.Random;
import java.util.function.BiConsumer;
import net.minecraft.core.Holder;

public record ChoiceConfiguration<T, V>(FilterableWeightedList<Holder<T>> list, BiConsumer<T, V> executor) implements IDelegatedActionConfiguration<V>,
IStreamConfiguration<Holder<T>>
{
    public static <T, V> Codec<ChoiceConfiguration<T, V>> codec(CodecSet<T> codec, BiConsumer<T, V> executor) {
        return CalioCodecHelper.weightedListOf((Codec)codec.holder()).fieldOf("actions").xmap(x -> new ChoiceConfiguration(x, executor), ChoiceConfiguration::list).codec();
    }

    @Override
    public void execute(V parameters) {
        Holder holder = (Holder)this.list.pickRandom(new Random());
        if (holder.m_203633_()) {
            this.executor().accept(holder.m_203334_(), parameters);
        }
    }

    @Override
    public List<String> getUnbound() {
        ImmutableList.Builder builder = ImmutableList.builder();
        this.list().m_147932_().forEach(holder -> {
            if (!holder.m_203633_()) {
                builder.add((Object)IDynamicFeatureConfiguration.holderAsString("actions[?]/element", holder));
            }
        });
        return builder.build();
    }

    @Override
    public List<Holder<T>> entries() {
        return this.list().m_147932_().toList();
    }
}

