/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  net.minecraft.core.Holder
 */
package io.github.edwinmindcraft.apoli.common.action.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredModifier;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import net.minecraft.core.Holder;

public record ModifyResourceConfiguration(Holder<ConfiguredPower<?, ?>> resource, Holder<ConfiguredModifier<?>> modifier) implements IDynamicFeatureConfiguration
{
    public static final Codec<ModifyResourceConfiguration> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)ConfiguredPower.CODEC_SET.holderRef().fieldOf("resource").forGetter(ModifyResourceConfiguration::resource), (App)ConfiguredModifier.required("modifier").forGetter(ModifyResourceConfiguration::modifier)).apply((Applicative)instance, ModifyResourceConfiguration::new));
}

