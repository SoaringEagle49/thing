/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.apace100.calio.util.TagLike
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.entity.EntityType
 *  org.jetbrains.annotations.NotNull
 */
package io.github.edwinmindcraft.apoli.common.global;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.apace100.calio.util.TagLike;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.apoli.api.registry.ApoliDynamicRegistries;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import java.util.List;
import java.util.Optional;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import org.jetbrains.annotations.NotNull;

public record GlobalPowerSet(int order, Optional<TagLike<EntityType<?>>> entityTypes, List<ResourceKey<ConfiguredPower<?, ?>>> powers) implements Comparable<GlobalPowerSet>
{
    public static final Codec<GlobalPowerSet> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.INT, (String)"order", (Object)0).forGetter(GlobalPowerSet::order), (App)CalioCodecHelper.optionalField((Codec)SerializableDataTypes.ENTITY_TYPE_TAG_LIKE, (String)"entity_types").forGetter(GlobalPowerSet::entityTypes), (App)CalioCodecHelper.listOf((Codec)ResourceKey.m_195966_(ApoliDynamicRegistries.CONFIGURED_POWER_KEY)).fieldOf("powers").forGetter(GlobalPowerSet::powers)).apply((Applicative)instance, GlobalPowerSet::new));

    public boolean doesApply(EntityType<?> entityType) {
        return this.entityTypes.isEmpty() || this.entityTypes.get().contains(entityType);
    }

    public boolean doesApply(Entity entity) {
        return this.doesApply(entity.m_6095_());
    }

    @Override
    public int compareTo(@NotNull GlobalPowerSet o) {
        return Integer.compare(this.order, o.order);
    }
}

