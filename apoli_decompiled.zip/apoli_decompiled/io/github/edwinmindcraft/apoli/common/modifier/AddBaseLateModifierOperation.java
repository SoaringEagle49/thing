/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.data.models.blockstates.PropertyDispatch$TriFunction
 */
package io.github.edwinmindcraft.apoli.common.modifier;

import io.github.edwinmindcraft.apoli.api.power.factory.ModifierOperation;
import java.util.Iterator;
import java.util.List;
import net.minecraft.data.models.blockstates.PropertyDispatch;

public class AddBaseLateModifierOperation
extends ModifierOperation {
    public AddBaseLateModifierOperation() {
        super(ModifierOperation.Phase.BASE, 300, (PropertyDispatch.TriFunction<List<Double>, Double, Double, Double>)((PropertyDispatch.TriFunction)(values, base, current) -> {
            double value = current;
            Iterator iterator = values.iterator();
            while (iterator.hasNext()) {
                double v = (Double)iterator.next();
                value += v;
            }
            return value;
        }));
    }
}

