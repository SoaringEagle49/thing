/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.data.models.blockstates.PropertyDispatch$TriFunction
 */
package io.github.edwinmindcraft.apoli.common.modifier;

import io.github.edwinmindcraft.apoli.api.power.factory.ModifierOperation;
import java.util.Iterator;
import java.util.List;
import net.minecraft.data.models.blockstates.PropertyDispatch;

public class AddTotalLateModifierOperation
extends ModifierOperation {
    public AddTotalLateModifierOperation() {
        super(ModifierOperation.Phase.TOTAL, 200, (PropertyDispatch.TriFunction<List<Double>, Double, Double, Double>)((PropertyDispatch.TriFunction)(values, base, current) -> {
            double value = current;
            Iterator iterator = values.iterator();
            while (iterator.hasNext()) {
                double v;
                value = v = ((Double)iterator.next()).doubleValue();
            }
            return value;
        }));
    }
}

