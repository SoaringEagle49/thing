/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.data.models.blockstates.PropertyDispatch$TriFunction
 */
package io.github.edwinmindcraft.apoli.common.modifier;

import io.github.edwinmindcraft.apoli.api.power.factory.ModifierOperation;
import java.util.List;
import net.minecraft.data.models.blockstates.PropertyDispatch;

public class AddBaseEarlyModifierOperation
extends ModifierOperation {
    public AddBaseEarlyModifierOperation() {
        super(ModifierOperation.Phase.BASE, 0, (PropertyDispatch.TriFunction<List<Double>, Double, Double, Double>)((PropertyDispatch.TriFunction)(values, base, current) -> base + values.stream().reduce(0.0, Double::sum)));
    }
}

