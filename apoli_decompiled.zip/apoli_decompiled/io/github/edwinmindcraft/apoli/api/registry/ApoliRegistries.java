/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.util.Pair
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.DataResult
 *  com.mojang.serialization.DynamicOps
 *  net.minecraft.core.Registry
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraftforge.registries.ForgeRegistry
 *  net.minecraftforge.registries.IForgeRegistry
 */
package io.github.edwinmindcraft.apoli.api.registry;

import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.DynamicOps;
import io.github.apace100.apoli.util.NamespaceAlias;
import io.github.edwinmindcraft.apoli.api.ApoliAPI;
import io.github.edwinmindcraft.apoli.api.power.factory.BiEntityAction;
import io.github.edwinmindcraft.apoli.api.power.factory.BiEntityCondition;
import io.github.edwinmindcraft.apoli.api.power.factory.BiomeCondition;
import io.github.edwinmindcraft.apoli.api.power.factory.BlockAction;
import io.github.edwinmindcraft.apoli.api.power.factory.BlockCondition;
import io.github.edwinmindcraft.apoli.api.power.factory.DamageCondition;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityCondition;
import io.github.edwinmindcraft.apoli.api.power.factory.FluidCondition;
import io.github.edwinmindcraft.apoli.api.power.factory.ItemAction;
import io.github.edwinmindcraft.apoli.api.power.factory.ItemCondition;
import io.github.edwinmindcraft.apoli.api.power.factory.ModifierOperation;
import io.github.edwinmindcraft.apoli.api.power.factory.PowerFactory;
import java.util.function.Supplier;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.registries.ForgeRegistry;
import net.minecraftforge.registries.IForgeRegistry;

public class ApoliRegistries {
    public static final ResourceKey<Registry<PowerFactory<?>>> POWER_FACTORY_KEY = ResourceKey.m_135788_((ResourceLocation)ApoliAPI.identifier("power_factory"));
    public static final ResourceKey<Registry<EntityCondition<?>>> ENTITY_CONDITION_KEY = ResourceKey.m_135788_((ResourceLocation)ApoliAPI.identifier("entity_condition"));
    public static final ResourceKey<Registry<ItemCondition<?>>> ITEM_CONDITION_KEY = ResourceKey.m_135788_((ResourceLocation)ApoliAPI.identifier("item_condition"));
    public static final ResourceKey<Registry<BlockCondition<?>>> BLOCK_CONDITION_KEY = ResourceKey.m_135788_((ResourceLocation)ApoliAPI.identifier("block_condition"));
    public static final ResourceKey<Registry<DamageCondition<?>>> DAMAGE_CONDITION_KEY = ResourceKey.m_135788_((ResourceLocation)ApoliAPI.identifier("damage_condition"));
    public static final ResourceKey<Registry<FluidCondition<?>>> FLUID_CONDITION_KEY = ResourceKey.m_135788_((ResourceLocation)ApoliAPI.identifier("fluid_condition"));
    public static final ResourceKey<Registry<BiomeCondition<?>>> BIOME_CONDITION_KEY = ResourceKey.m_135788_((ResourceLocation)ApoliAPI.identifier("biome_condition"));
    public static final ResourceKey<Registry<EntityAction<?>>> ENTITY_ACTION_KEY = ResourceKey.m_135788_((ResourceLocation)ApoliAPI.identifier("entity_action"));
    public static final ResourceKey<Registry<ItemAction<?>>> ITEM_ACTION_KEY = ResourceKey.m_135788_((ResourceLocation)ApoliAPI.identifier("item_action"));
    public static final ResourceKey<Registry<BlockAction<?>>> BLOCK_ACTION_KEY = ResourceKey.m_135788_((ResourceLocation)ApoliAPI.identifier("block_action"));
    public static Supplier<IForgeRegistry<PowerFactory<?>>> POWER_FACTORY;
    public static Supplier<IForgeRegistry<EntityCondition<?>>> ENTITY_CONDITION;
    public static Supplier<IForgeRegistry<ItemCondition<?>>> ITEM_CONDITION;
    public static Supplier<IForgeRegistry<BlockCondition<?>>> BLOCK_CONDITION;
    public static Supplier<IForgeRegistry<DamageCondition<?>>> DAMAGE_CONDITION;
    public static Supplier<IForgeRegistry<FluidCondition<?>>> FLUID_CONDITION;
    public static Supplier<IForgeRegistry<BiomeCondition<?>>> BIOME_CONDITION;
    public static Supplier<IForgeRegistry<EntityAction<?>>> ENTITY_ACTION;
    public static Supplier<IForgeRegistry<ItemAction<?>>> ITEM_ACTION;
    public static Supplier<IForgeRegistry<BlockAction<?>>> BLOCK_ACTION;
    public static final ResourceKey<Registry<BiEntityCondition<?>>> BIENTITY_CONDITION_KEY;
    public static final ResourceKey<Registry<BiEntityAction<?>>> BIENTITY_ACTION_KEY;
    public static Supplier<IForgeRegistry<BiEntityCondition<?>>> BIENTITY_CONDITION;
    public static Supplier<IForgeRegistry<BiEntityAction<?>>> BIENTITY_ACTION;
    public static final ResourceKey<Registry<ModifierOperation>> MODIFIER_OPERATION_KEY;
    public static Supplier<IForgeRegistry<ModifierOperation>> MODIFIER_OPERATION;

    public static <T> Codec<T> codec(Supplier<IForgeRegistry<T>> registry) {
        final Supplier<ForgeRegistry> supplier = () -> (ForgeRegistry)registry.get();
        return new Codec<T>(){

            public <U> DataResult<Pair<T, U>> decode(DynamicOps<U> dynamicOps, U input) {
                return dynamicOps.compressMaps() ? dynamicOps.getNumberValue(input).flatMap(arg_0 -> 1.lambda$decode$1((Supplier)supplier, arg_0)).map(obj -> Pair.of((Object)obj, (Object)dynamicOps.empty())) : ResourceLocation.f_135803_.decode(dynamicOps, input).flatMap(arg_0 -> 1.lambda$decode$4((Supplier)supplier, arg_0));
            }

            public <T1> DataResult<T1> encode(T input, DynamicOps<T1> ops, T1 prefix) {
                ResourceLocation identifier = ((ForgeRegistry)supplier.get()).getKey(input);
                if (identifier == null) {
                    return DataResult.error(() -> "Unknown registry element " + input);
                }
                return ops.compressMaps() ? ops.mergeToPrimitive(prefix, ops.createInt(((ForgeRegistry)supplier.get()).getID(input))) : ops.mergeToPrimitive(prefix, ops.createString(identifier.toString()));
            }

            private static /* synthetic */ DataResult lambda$decode$4(Supplier supplier2, Pair pair) {
                Object object = ((ForgeRegistry)supplier2.get()).getValue((ResourceLocation)pair.getFirst());
                if (object == null && NamespaceAlias.hasAlias((ResourceLocation)pair.getFirst())) {
                    object = ((ForgeRegistry)supplier2.get()).getValue(NamespaceAlias.resolveAlias((ResourceLocation)pair.getFirst()));
                }
                return object == null ? DataResult.error(() -> "Unknown registry key: " + pair.getFirst()) : DataResult.success((Object)Pair.of((Object)object, (Object)pair.getSecond()));
            }

            private static /* synthetic */ DataResult lambda$decode$1(Supplier supplier2, Number number) {
                Object object = ((ForgeRegistry)supplier2.get()).getValue(number.intValue());
                return object == null ? DataResult.error(() -> "Unknown registry id: " + number) : DataResult.success((Object)object);
            }
        };
    }

    static {
        BIENTITY_CONDITION_KEY = ResourceKey.m_135788_((ResourceLocation)ApoliAPI.identifier("bientity_condition"));
        BIENTITY_ACTION_KEY = ResourceKey.m_135788_((ResourceLocation)ApoliAPI.identifier("bientity_action"));
        MODIFIER_OPERATION_KEY = ResourceKey.m_135788_((ResourceLocation)ApoliAPI.identifier("modifier"));
    }
}

