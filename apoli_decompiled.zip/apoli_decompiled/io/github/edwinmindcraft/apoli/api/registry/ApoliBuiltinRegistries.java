/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.github.apace100.calio.ClassUtil
 *  net.minecraftforge.registries.IForgeRegistry
 */
package io.github.edwinmindcraft.apoli.api.registry;

import io.github.apace100.calio.ClassUtil;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiEntityAction;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiEntityCondition;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiomeCondition;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBlockAction;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBlockCondition;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredDamageCondition;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredEntityAction;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredEntityCondition;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredFluidCondition;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredItemAction;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredItemCondition;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredModifier;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.apoli.common.global.GlobalPowerSet;
import java.util.function.Supplier;
import net.minecraftforge.registries.IForgeRegistry;

public class ApoliBuiltinRegistries {
    public static final Class<ConfiguredPower<?, ?>> CONFIGURED_POWER_CLASS = ClassUtil.get((Object[])new ConfiguredPower[0]);
    public static Supplier<IForgeRegistry<ConfiguredPower<?, ?>>> CONFIGURED_POWERS;
    public static Supplier<IForgeRegistry<GlobalPowerSet>> GLOBAL_POWER_SET;
    public static Supplier<IForgeRegistry<ConfiguredBiEntityAction<?, ?>>> CONFIGURED_BIENTITY_ACTIONS;
    public static Supplier<IForgeRegistry<ConfiguredBlockAction<?, ?>>> CONFIGURED_BLOCK_ACTIONS;
    public static Supplier<IForgeRegistry<ConfiguredEntityAction<?, ?>>> CONFIGURED_ENTITY_ACTIONS;
    public static Supplier<IForgeRegistry<ConfiguredItemAction<?, ?>>> CONFIGURED_ITEM_ACTIONS;
    public static Supplier<IForgeRegistry<ConfiguredBiEntityCondition<?, ?>>> CONFIGURED_BIENTITY_CONDITIONS;
    public static Supplier<IForgeRegistry<ConfiguredBiomeCondition<?, ?>>> CONFIGURED_BIOME_CONDITIONS;
    public static Supplier<IForgeRegistry<ConfiguredBlockCondition<?, ?>>> CONFIGURED_BLOCK_CONDITIONS;
    public static Supplier<IForgeRegistry<ConfiguredDamageCondition<?, ?>>> CONFIGURED_DAMAGE_CONDITIONS;
    public static Supplier<IForgeRegistry<ConfiguredEntityCondition<?, ?>>> CONFIGURED_ENTITY_CONDITIONS;
    public static Supplier<IForgeRegistry<ConfiguredFluidCondition<?, ?>>> CONFIGURED_FLUID_CONDITIONS;
    public static Supplier<IForgeRegistry<ConfiguredItemCondition<?, ?>>> CONFIGURED_ITEM_CONDITIONS;
    public static Supplier<IForgeRegistry<ConfiguredModifier<?>>> CONFIGURED_MODIFIERS;
}

