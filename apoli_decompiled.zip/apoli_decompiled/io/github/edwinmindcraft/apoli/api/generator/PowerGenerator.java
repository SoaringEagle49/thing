/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.mojang.serialization.DynamicOps
 *  com.mojang.serialization.JsonOps
 *  io.github.apace100.calio.data.JsonDataProvider
 *  net.minecraft.data.DataGenerator
 *  net.minecraft.server.packs.PackType
 *  net.minecraftforge.common.data.ExistingFileHelper
 *  org.jetbrains.annotations.NotNull
 */
package io.github.edwinmindcraft.apoli.api.generator;

import com.google.gson.JsonElement;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import io.github.apace100.calio.data.JsonDataProvider;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import net.minecraft.data.DataGenerator;
import net.minecraft.server.packs.PackType;
import net.minecraftforge.common.data.ExistingFileHelper;
import org.jetbrains.annotations.NotNull;

public abstract class PowerGenerator
extends JsonDataProvider<ConfiguredPower<?, ?>> {
    protected PowerGenerator(DataGenerator generator, String modid, ExistingFileHelper existingFileHelper) {
        super(generator, modid, existingFileHelper, "powers", PackType.SERVER_DATA);
    }

    protected JsonElement asJson(ConfiguredPower<?, ?> input) {
        return (JsonElement)ConfiguredPower.CODEC.encodeStart((DynamicOps)JsonOps.INSTANCE, input).getOrThrow(true, s -> {});
    }

    @NotNull
    public String m_6055_() {
        return "Power Generator: " + this.modid;
    }
}

