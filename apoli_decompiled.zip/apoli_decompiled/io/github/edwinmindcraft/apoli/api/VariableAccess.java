/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.entity.EquipmentSlot
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.SlotAccess
 *  net.minecraft.world.inventory.Slot
 *  net.minecraft.world.item.ItemStack
 *  org.apache.commons.lang3.mutable.Mutable
 */
package io.github.edwinmindcraft.apoli.api;

import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.SlotAccess;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import org.apache.commons.lang3.mutable.Mutable;

public record VariableAccess<T>(Supplier<T> reader, Consumer<T> writer) implements Mutable<T>
{
    public static Mutable<ItemStack> hand(LivingEntity living, InteractionHand hand) {
        return new VariableAccess<ItemStack>(() -> living.m_21120_(hand), stack -> living.m_21008_(hand, stack));
    }

    public static Mutable<ItemStack> slot(LivingEntity living, EquipmentSlot slot) {
        return new VariableAccess<ItemStack>(() -> living.m_6844_(slot), x -> living.m_8061_(slot, x));
    }

    public static Mutable<ItemStack> slot(Slot slot) {
        return new VariableAccess<ItemStack>(() -> ((Slot)slot).m_7993_(), arg_0 -> ((Slot)slot).m_5852_(arg_0));
    }

    public static Mutable<ItemStack> slot(SlotAccess slot) {
        return new VariableAccess<ItemStack>(() -> ((SlotAccess)slot).m_142196_(), arg_0 -> ((SlotAccess)slot).m_142104_(arg_0));
    }

    public T getValue() {
        return this.reader().get();
    }

    public void setValue(T value) {
        this.writer().accept(value);
    }
}

