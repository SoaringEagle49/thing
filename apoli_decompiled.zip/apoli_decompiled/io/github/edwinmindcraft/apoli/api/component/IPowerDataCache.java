/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraftforge.common.util.LazyOptional
 */
package io.github.edwinmindcraft.apoli.api.component;

import io.github.apace100.apoli.Apoli;
import io.github.edwinmindcraft.apoli.common.registry.ApoliCapabilities;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.common.util.LazyOptional;

public interface IPowerDataCache {
    public static final ResourceLocation KEY = Apoli.identifier("power_data");

    public static LazyOptional<IPowerDataCache> get(LivingEntity entity) {
        return entity.getCapability(ApoliCapabilities.POWER_DATA_CACHE);
    }

    public void setDamage(float var1);

    public float getDamage();

    public void setShouldExecuteActions(boolean var1);

    public boolean shouldExecuteActions();
}

