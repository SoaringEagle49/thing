/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 */
package io.github.edwinmindcraft.apoli.api.configuration;

import com.mojang.serialization.Codec;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;

public record NoConfiguration() implements IDynamicFeatureConfiguration
{
    public static final NoConfiguration INSTANCE = new NoConfiguration();
    public static final Codec<NoConfiguration> CODEC = Codec.unit((Object)new NoConfiguration());
}

