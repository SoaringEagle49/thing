/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.MapCodec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 */
package io.github.edwinmindcraft.apoli.api.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.util.Comparison;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import java.util.Optional;

public record IntegerComparisonConfiguration(Comparison comparison, int compareTo) implements IDynamicFeatureConfiguration
{
    public static final MapCodec<IntegerComparisonConfiguration> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group((App)ApoliDataTypes.COMPARISON.fieldOf("comparison").forGetter(IntegerComparisonConfiguration::comparison), (App)CalioCodecHelper.INT.fieldOf("compare_to").forGetter(IntegerComparisonConfiguration::compareTo)).apply((Applicative)instance, IntegerComparisonConfiguration::new));
    public static final MapCodec<Optional<IntegerComparisonConfiguration>> OPTIONAL_MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group((App)CalioCodecHelper.optionalField(ApoliDataTypes.COMPARISON, (String)"comparison").forGetter(x -> x.map(IntegerComparisonConfiguration::comparison)), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.INT, (String)"compare_to").forGetter(x -> x.map(IntegerComparisonConfiguration::compareTo))).apply((Applicative)instance, (t1, t2) -> t1.flatMap(x1 -> t2.map(x2 -> new IntegerComparisonConfiguration((Comparison)((Object)((Object)((Object)x1))), (int)x2)))));
    public static final Codec<IntegerComparisonConfiguration> CODEC = MAP_CODEC.codec();

    public static MapCodec<IntegerComparisonConfiguration> withDefaults(Comparison comparison, int value) {
        return RecordCodecBuilder.mapCodec(instance -> instance.group((App)CalioCodecHelper.optionalField(ApoliDataTypes.COMPARISON, (String)"comparison", (Object)((Object)comparison)).forGetter(IntegerComparisonConfiguration::comparison), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.INT, (String)"compare_to", (Object)value).forGetter(IntegerComparisonConfiguration::compareTo)).apply((Applicative)instance, IntegerComparisonConfiguration::new));
    }

    public boolean check(int value) {
        return this.comparison().compare(value, this.compareTo());
    }

    public int getOptimalStoppingPoint() {
        return this.comparison().getOptimalStoppingIndex(this.compareTo());
    }

    public IntegerComparisonConfiguration inverse() {
        return new IntegerComparisonConfiguration(this.comparison().inverse(), this.compareTo());
    }
}

