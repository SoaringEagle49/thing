/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.MapCodec
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.edwinmindcraft.calio.api.registry.ICalioDynamicRegistryManager
 *  net.minecraft.resources.ResourceLocation
 *  org.jetbrains.annotations.NotNull
 */
package io.github.edwinmindcraft.apoli.api.configuration;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.calio.api.registry.ICalioDynamicRegistryManager;
import java.util.List;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.NotNull;

public record PowerReference(ResourceLocation power) implements IDynamicFeatureConfiguration
{
    public static Codec<PowerReference> codec(String fieldName) {
        return PowerReference.mapCodec(fieldName).codec();
    }

    public static MapCodec<PowerReference> mapCodec(String fieldName) {
        return SerializableDataTypes.IDENTIFIER.fieldOf(fieldName).xmap(PowerReference::new, PowerReference::power);
    }

    @Override
    @NotNull
    public List<String> getErrors(@NotNull ICalioDynamicRegistryManager server) {
        return this.checkPower(server, this.power).stream().map(x -> "PowerReference/Missing Power: " + x.toString()).toList();
    }
}

