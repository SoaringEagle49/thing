/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.MapCodec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 */
package io.github.edwinmindcraft.apoli.api.configuration;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.apoli.data.ApoliDataTypes;
import io.github.apace100.apoli.util.Comparison;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;

public record DoubleComparisonConfiguration(Comparison comparison, double compareTo) implements IDynamicFeatureConfiguration
{
    public static final MapCodec<DoubleComparisonConfiguration> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group((App)ApoliDataTypes.COMPARISON.fieldOf("comparison").forGetter(DoubleComparisonConfiguration::comparison), (App)CalioCodecHelper.DOUBLE.fieldOf("compare_to").forGetter(DoubleComparisonConfiguration::compareTo)).apply((Applicative)instance, DoubleComparisonConfiguration::new));
    public static final Codec<DoubleComparisonConfiguration> CODEC = MAP_CODEC.codec();

    public boolean check(double value) {
        return this.comparison().compare(value, this.compareTo());
    }
}

