/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableMap
 *  com.google.common.collect.ImmutableMap$Builder
 *  org.jetbrains.annotations.NotNull
 */
package io.github.edwinmindcraft.apoli.api.configuration;

import com.google.common.collect.ImmutableMap;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import java.util.List;
import java.util.Map;
import org.jetbrains.annotations.NotNull;

public interface IStreamConfiguration<T>
extends IDynamicFeatureConfiguration {
    public List<T> entries();

    @Override
    @NotNull
    default public Map<String, IDynamicFeatureConfiguration> getChildrenComponent() {
        ImmutableMap.Builder components = ImmutableMap.builder();
        int i = 0;
        for (T entry : this.entries()) {
            if (entry instanceof IDynamicFeatureConfiguration) {
                IDynamicFeatureConfiguration config = (IDynamicFeatureConfiguration)entry;
                components.put((Object)Integer.toString(i), (Object)config);
            }
            ++i;
        }
        return components.build();
    }
}

