/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  net.minecraft.world.entity.Entity
 */
package io.github.edwinmindcraft.apoli.api.power.factory;

import com.mojang.serialization.Codec;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.ConditionData;
import io.github.edwinmindcraft.apoli.api.power.IConditionFactory;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiEntityCondition;
import io.github.edwinmindcraft.apoli.api.registry.ApoliRegistries;
import net.minecraft.world.entity.Entity;

public abstract class BiEntityCondition<T extends IDynamicFeatureConfiguration>
implements IConditionFactory<T, ConfiguredBiEntityCondition<T, ?>, BiEntityCondition<T>> {
    public static final Codec<BiEntityCondition<?>> CODEC = ApoliRegistries.codec(() -> ApoliRegistries.BIENTITY_CONDITION.get());
    private final Codec<ConfiguredBiEntityCondition<T, ?>> codec;

    protected BiEntityCondition(Codec<T> codec) {
        this.codec = IConditionFactory.conditionCodec(codec, this);
    }

    @Override
    public Codec<ConfiguredBiEntityCondition<T, ?>> getConditionCodec() {
        return this.codec;
    }

    @Override
    public final ConfiguredBiEntityCondition<T, ?> configure(T input, ConditionData data) {
        return new ConfiguredBiEntityCondition<T, BiEntityCondition>(() -> this, input, data);
    }

    protected abstract boolean check(T var1, Entity var2, Entity var3);

    public boolean check(T configuration, ConditionData data, Entity actor, Entity target) {
        return data.inverted() ^ this.check(configuration, actor, target);
    }
}

