/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  net.minecraft.world.entity.Entity
 */
package io.github.edwinmindcraft.apoli.api.power.factory;

import com.mojang.serialization.Codec;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.ConfiguredFactory;
import io.github.edwinmindcraft.apoli.api.power.IFactory;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBiEntityAction;
import io.github.edwinmindcraft.apoli.api.registry.ApoliRegistries;
import net.minecraft.world.entity.Entity;

public abstract class BiEntityAction<T extends IDynamicFeatureConfiguration>
implements IFactory<T, ConfiguredBiEntityAction<T, ?>, BiEntityAction<T>> {
    public static final Codec<BiEntityAction<?>> CODEC = ApoliRegistries.codec(() -> ApoliRegistries.BIENTITY_ACTION.get());
    private final Codec<ConfiguredBiEntityAction<T, ?>> codec;

    protected BiEntityAction(Codec<T> codec) {
        this.codec = IFactory.singleCodec(IFactory.asMap(codec), iDynamicFeatureConfiguration -> this.configure((IDynamicFeatureConfiguration)iDynamicFeatureConfiguration), ConfiguredFactory::getConfiguration);
    }

    public Codec<ConfiguredBiEntityAction<T, ?>> getCodec() {
        return this.codec;
    }

    @Override
    public final ConfiguredBiEntityAction<T, ?> configure(T input) {
        return new ConfiguredBiEntityAction<T, BiEntityAction>(() -> this, input);
    }

    public abstract void execute(T var1, Entity var2, Entity var3);
}

