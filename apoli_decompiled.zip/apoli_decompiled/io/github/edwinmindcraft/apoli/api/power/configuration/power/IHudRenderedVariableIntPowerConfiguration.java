/*
 * Decompiled with CFR 0.152.
 */
package io.github.edwinmindcraft.apoli.api.power.configuration.power;

import io.github.apace100.apoli.util.HudRender;
import io.github.edwinmindcraft.apoli.api.power.configuration.power.IVariableIntPowerConfiguration;

public interface IHudRenderedVariableIntPowerConfiguration
extends IVariableIntPowerConfiguration {
    public HudRender hudRender();
}

