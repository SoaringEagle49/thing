/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.MapCodec
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  io.github.edwinmindcraft.calio.api.network.CodecSet
 *  net.minecraft.core.Holder
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 *  org.apache.commons.lang3.mutable.Mutable
 */
package io.github.edwinmindcraft.apoli.api.power.configuration;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.ConfiguredFactory;
import io.github.edwinmindcraft.apoli.api.power.factory.ItemAction;
import io.github.edwinmindcraft.apoli.api.registry.ApoliBuiltinRegistries;
import io.github.edwinmindcraft.apoli.api.registry.ApoliDynamicRegistries;
import io.github.edwinmindcraft.apoli.api.registry.ApoliRegistries;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import io.github.edwinmindcraft.calio.api.network.CodecSet;
import java.util.function.Supplier;
import net.minecraft.core.Holder;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.apache.commons.lang3.mutable.Mutable;

public final class ConfiguredItemAction<C extends IDynamicFeatureConfiguration, F extends ItemAction<C>>
extends ConfiguredFactory<C, F, ConfiguredItemAction<?, ?>> {
    public static final Codec<ConfiguredItemAction<?, ?>> CODEC = ItemAction.CODEC.dispatch(ConfiguredFactory::getFactory, ItemAction::getCodec);
    public static final CodecSet<ConfiguredItemAction<?, ?>> CODEC_SET = CalioCodecHelper.forDynamicRegistry(ApoliDynamicRegistries.CONFIGURED_ITEM_ACTION_KEY, (Codec)SerializableDataTypes.IDENTIFIER, CODEC);
    public static final Codec<Holder<ConfiguredItemAction<?, ?>>> HOLDER = CODEC_SET.holder();

    public static MapCodec<Holder<ConfiguredItemAction<?, ?>>> required(String name) {
        return HOLDER.fieldOf(name);
    }

    public static MapCodec<Holder<ConfiguredItemAction<?, ?>>> optional(String name) {
        return CalioCodecHelper.registryDefaultedField(HOLDER, (String)name, ApoliDynamicRegistries.CONFIGURED_ITEM_ACTION_KEY, ApoliBuiltinRegistries.CONFIGURED_ITEM_ACTIONS);
    }

    public static void execute(Holder<ConfiguredItemAction<?, ?>> action, Level level, Mutable<ItemStack> stack) {
        if (action.m_203633_()) {
            ((ConfiguredItemAction)action.m_203334_()).execute(level, stack);
        }
    }

    public ConfiguredItemAction(Supplier<F> factory, C configuration) {
        super(factory, configuration);
    }

    public void execute(Level level, Mutable<ItemStack> stack) {
        ((ItemAction)this.getFactory()).execute(this.getConfiguration(), level, stack);
    }

    public String toString() {
        return "CIA:" + ApoliRegistries.ITEM_ACTION.get().getKey((Object)((ItemAction)this.getFactory())) + "-" + this.getConfiguration();
    }
}

