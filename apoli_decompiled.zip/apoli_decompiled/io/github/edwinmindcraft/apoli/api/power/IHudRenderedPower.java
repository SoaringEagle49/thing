/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 */
package io.github.edwinmindcraft.apoli.api.power;

import io.github.apace100.apoli.util.HudRender;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import net.minecraft.world.entity.Entity;

public interface IHudRenderedPower<T extends IDynamicFeatureConfiguration> {
    public HudRender getRenderSettings(ConfiguredPower<T, ?> var1, Entity var2);

    public float getFill(ConfiguredPower<T, ?> var1, Entity var2);

    public boolean shouldRender(ConfiguredPower<T, ?> var1, Entity var2);
}

