/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.MapCodec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.core.Holder
 */
package io.github.edwinmindcraft.apoli.api.power;

import com.google.common.collect.ImmutableList;
import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredModifier;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import java.util.List;
import java.util.Optional;
import net.minecraft.core.Holder;

public record ModifierData(double value, Optional<Holder<ConfiguredPower<?, ?>>> resource, List<ConfiguredModifier<?>> modifiers) implements IDynamicFeatureConfiguration
{
    public static final ModifierData DEFAULT = new ModifierData(0.0, Optional.empty(), (List<ConfiguredModifier<?>>)ImmutableList.of());
    public static final MapCodec<ModifierData> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group((App)CalioCodecHelper.DOUBLE.fieldOf("value").forGetter(ModifierData::value), (App)CalioCodecHelper.optionalField((Codec)ConfiguredPower.CODEC_SET.holderRef(), (String)"resource").forGetter(ModifierData::resource), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.listOf(ConfiguredModifier.CODEC), (String)"modifier", (Object)ImmutableList.of()).forGetter(ModifierData::modifiers)).apply((Applicative)instance, ModifierData::new));
}

