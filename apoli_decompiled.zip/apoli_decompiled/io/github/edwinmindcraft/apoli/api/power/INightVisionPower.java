/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 *  net.minecraft.core.Holder
 *  net.minecraft.world.entity.Entity
 */
package io.github.edwinmindcraft.apoli.api.power;

import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.component.IPowerContainer;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.apoli.api.power.factory.PowerFactory;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;
import javax.annotation.Nullable;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.Entity;

public interface INightVisionPower<T extends IDynamicFeatureConfiguration> {
    public static Optional<Float> getNightVisionStrength(@Nullable Entity player) {
        return IPowerContainer.get(player).map(x -> x.getPowers().stream()).orElseGet(() -> Stream.of(new Holder[0])).filter(x -> ((ConfiguredPower)x.m_203334_()).isActive(Objects.requireNonNull(player)) && ((ConfiguredPower)x.m_203334_()).getFactory() instanceof INightVisionPower).map(x -> Float.valueOf(INightVisionPower.getValue((ConfiguredPower)x.m_203334_(), player))).max(Float::compareTo);
    }

    private static <T extends IDynamicFeatureConfiguration, F extends PowerFactory<T>> float getValue(ConfiguredPower<T, F> configuration, Entity player) {
        return ((INightVisionPower)configuration.getFactory()).getStrength(configuration, player);
    }

    public float getStrength(ConfiguredPower<T, ?> var1, Entity var2);
}

