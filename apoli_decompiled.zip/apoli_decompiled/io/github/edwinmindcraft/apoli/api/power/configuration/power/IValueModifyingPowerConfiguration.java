/*
 * Decompiled with CFR 0.152.
 */
package io.github.edwinmindcraft.apoli.api.power.configuration.power;

import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.configuration.ListConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredModifier;

public interface IValueModifyingPowerConfiguration
extends IDynamicFeatureConfiguration {
    public ListConfiguration<ConfiguredModifier<?>> modifiers();
}

