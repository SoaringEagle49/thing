/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.MapCodec
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  io.github.edwinmindcraft.calio.api.network.CodecSet
 *  io.github.edwinmindcraft.calio.api.network.PropagatingDefaultedOptionalFieldCodec
 *  io.github.edwinmindcraft.calio.api.network.PropagatingOptionalFieldCodec
 *  net.minecraft.core.Holder
 *  net.minecraft.world.entity.Entity
 *  net.minecraftforge.common.util.Lazy
 */
package io.github.edwinmindcraft.apoli.api.power.configuration;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.power.ModifierData;
import io.github.edwinmindcraft.apoli.api.power.factory.ModifierOperation;
import io.github.edwinmindcraft.apoli.api.registry.ApoliDynamicRegistries;
import io.github.edwinmindcraft.apoli.api.registry.ApoliRegistries;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import io.github.edwinmindcraft.calio.api.network.CodecSet;
import io.github.edwinmindcraft.calio.api.network.PropagatingDefaultedOptionalFieldCodec;
import io.github.edwinmindcraft.calio.api.network.PropagatingOptionalFieldCodec;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.common.util.Lazy;

public final class ConfiguredModifier<F extends ModifierOperation> {
    public static final Codec<ConfiguredModifier<?>> CODEC = ModifierOperation.CODEC.dispatch("operation", ConfiguredModifier::getFactory, ModifierOperation::getCodec);
    public static final CodecSet<ConfiguredModifier<?>> CODEC_SET = CalioCodecHelper.forDynamicRegistry(ApoliDynamicRegistries.CONFIGURED_MODIFIER_KEY, (Codec)SerializableDataTypes.IDENTIFIER, CODEC);
    public static final Codec<Holder<ConfiguredModifier<?>>> HOLDER = CODEC_SET.holder();
    private final Lazy<F> factory;
    private final ModifierData data;

    public static MapCodec<Holder<ConfiguredModifier<?>>> required(String name) {
        return HOLDER.fieldOf(name);
    }

    public static PropagatingOptionalFieldCodec<Holder<ConfiguredModifier<?>>> optional(String name) {
        return CalioCodecHelper.optionalField(HOLDER, (String)name);
    }

    public static PropagatingDefaultedOptionalFieldCodec<Holder<ConfiguredModifier<?>>> optional(String name, Holder<ConfiguredModifier<?>> key) {
        return CalioCodecHelper.optionalField(HOLDER, (String)name, key);
    }

    public static double apply(Holder<ConfiguredModifier<?>> modifier, Entity entity, double value) {
        if (!modifier.m_203633_()) {
            return value;
        }
        return ((ConfiguredModifier)modifier.m_203334_()).apply(entity, value, value);
    }

    public ConfiguredModifier(Supplier<F> factory, ModifierData data) {
        this.factory = Lazy.of(factory);
        this.data = data;
    }

    public F getFactory() {
        return (F)((ModifierOperation)this.factory.get());
    }

    public ModifierData getData() {
        return this.data;
    }

    public double apply(Entity entity, double base, double current) {
        return ((ModifierOperation)this.getFactory()).apply(List.of(this), entity, base, current);
    }

    public String toString() {
        return "CM:" + ApoliRegistries.MODIFIER_OPERATION.get().getKey(this.getFactory()) + "-" + this.getData();
    }
}

