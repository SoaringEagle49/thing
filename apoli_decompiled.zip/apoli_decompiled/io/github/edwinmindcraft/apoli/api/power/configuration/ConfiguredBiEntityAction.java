/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.MapCodec
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  io.github.edwinmindcraft.calio.api.network.CodecSet
 *  net.minecraft.core.Holder
 *  net.minecraft.world.entity.Entity
 */
package io.github.edwinmindcraft.apoli.api.power.configuration;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.ConfiguredFactory;
import io.github.edwinmindcraft.apoli.api.power.factory.BiEntityAction;
import io.github.edwinmindcraft.apoli.api.registry.ApoliBuiltinRegistries;
import io.github.edwinmindcraft.apoli.api.registry.ApoliDynamicRegistries;
import io.github.edwinmindcraft.apoli.api.registry.ApoliRegistries;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import io.github.edwinmindcraft.calio.api.network.CodecSet;
import java.util.function.Supplier;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.Entity;

public final class ConfiguredBiEntityAction<C extends IDynamicFeatureConfiguration, F extends BiEntityAction<C>>
extends ConfiguredFactory<C, F, ConfiguredBiEntityAction<?, ?>> {
    public static final Codec<ConfiguredBiEntityAction<?, ?>> CODEC = BiEntityAction.CODEC.dispatch(ConfiguredFactory::getFactory, BiEntityAction::getCodec);
    public static final CodecSet<ConfiguredBiEntityAction<?, ?>> CODEC_SET = CalioCodecHelper.forDynamicRegistry(ApoliDynamicRegistries.CONFIGURED_BIENTITY_ACTION_KEY, (Codec)SerializableDataTypes.IDENTIFIER, CODEC);
    public static final Codec<Holder<ConfiguredBiEntityAction<?, ?>>> HOLDER = CODEC_SET.holder();

    public static MapCodec<Holder<ConfiguredBiEntityAction<?, ?>>> required(String name) {
        return HOLDER.fieldOf(name);
    }

    public static MapCodec<Holder<ConfiguredBiEntityAction<?, ?>>> optional(String name) {
        return CalioCodecHelper.registryDefaultedField(HOLDER, (String)name, ApoliDynamicRegistries.CONFIGURED_BIENTITY_ACTION_KEY, ApoliBuiltinRegistries.CONFIGURED_BIENTITY_ACTIONS);
    }

    public static void execute(Holder<ConfiguredBiEntityAction<?, ?>> action, Entity actor, Entity target) {
        if (action.m_203633_()) {
            ((ConfiguredBiEntityAction)action.m_203334_()).execute(actor, target);
        }
    }

    public ConfiguredBiEntityAction(Supplier<F> factory, C configuration) {
        super(factory, configuration);
    }

    public void execute(Entity actor, Entity target) {
        ((BiEntityAction)this.getFactory()).execute(this.getConfiguration(), actor, target);
    }

    public String toString() {
        return "CBEA:" + ApoliRegistries.BIENTITY_ACTION.get().getKey((Object)((BiEntityAction)this.getFactory())) + "-" + this.getConfiguration();
    }
}

