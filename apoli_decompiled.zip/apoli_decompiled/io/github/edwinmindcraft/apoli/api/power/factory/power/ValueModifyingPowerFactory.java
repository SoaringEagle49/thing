/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  net.minecraft.world.entity.Entity
 */
package io.github.edwinmindcraft.apoli.api.power.factory.power;

import com.mojang.serialization.Codec;
import io.github.edwinmindcraft.apoli.api.power.IValueModifyingPower;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredModifier;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.apoli.api.power.configuration.power.IValueModifyingPowerConfiguration;
import io.github.edwinmindcraft.apoli.api.power.factory.PowerFactory;
import java.util.List;
import net.minecraft.world.entity.Entity;

public abstract class ValueModifyingPowerFactory<T extends IValueModifyingPowerConfiguration>
extends PowerFactory<T>
implements IValueModifyingPower<T> {
    protected ValueModifyingPowerFactory(Codec<T> codec) {
        super(codec);
    }

    @Override
    public List<ConfiguredModifier<?>> getModifiers(ConfiguredPower<T, ?> configuration, Entity player) {
        return ((IValueModifyingPowerConfiguration)configuration.getConfiguration()).modifiers().getContent();
    }
}

