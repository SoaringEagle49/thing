/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.Mth
 *  net.minecraft.world.entity.Entity
 */
package io.github.edwinmindcraft.apoli.api.power;

import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

public interface IVariableIntPower<T extends IDynamicFeatureConfiguration> {
    public int assign(ConfiguredPower<T, ?> var1, Entity var2, int var3);

    public int getValue(ConfiguredPower<T, ?> var1, Entity var2);

    public int getMaximum(ConfiguredPower<T, ?> var1, Entity var2);

    public int getMinimum(ConfiguredPower<T, ?> var1, Entity var2);

    default public float getProgress(ConfiguredPower<T, ?> configuration, Entity player) {
        float value = this.getValue(configuration, player);
        float min = this.getMinimum(configuration, player);
        float max = this.getMaximum(configuration, player);
        return Mth.m_14036_((float)((value - min) / (max - min)), (float)0.0f, (float)1.0f);
    }

    default public int change(ConfiguredPower<T, ?> configuration, Entity player, int amount) {
        return this.assign(configuration, player, this.getValue(configuration, player) + amount);
    }

    default public int increment(ConfiguredPower<T, ?> configuration, Entity player) {
        return this.change(configuration, player, 1);
    }

    default public int decrement(ConfiguredPower<T, ?> configuration, Entity player) {
        return this.change(configuration, player, -1);
    }
}

