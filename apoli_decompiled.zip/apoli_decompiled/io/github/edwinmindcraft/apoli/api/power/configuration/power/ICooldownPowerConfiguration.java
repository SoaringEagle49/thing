/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.MapCodec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 */
package io.github.edwinmindcraft.apoli.api.power.configuration.power;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.apoli.util.HudRender;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;

public interface ICooldownPowerConfiguration
extends IDynamicFeatureConfiguration {
    public static final MapCodec<ICooldownPowerConfiguration> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group((App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.INT, (String)"cooldown", (Object)1).forGetter(ICooldownPowerConfiguration::duration), (App)CalioCodecHelper.optionalField(HudRender.CODEC, (String)"hud_render", (Object)HudRender.DONT_RENDER).forGetter(ICooldownPowerConfiguration::hudRender)).apply((Applicative)instance, Impl::new));

    public int duration();

    public HudRender hudRender();

    public record Impl(int duration, HudRender hudRender) implements ICooldownPowerConfiguration
    {
    }
}

