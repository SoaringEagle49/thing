/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 *  org.apache.commons.lang3.mutable.Mutable
 */
package io.github.edwinmindcraft.apoli.api.power.factory;

import com.mojang.serialization.Codec;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.ConfiguredFactory;
import io.github.edwinmindcraft.apoli.api.power.IFactory;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredItemAction;
import io.github.edwinmindcraft.apoli.api.registry.ApoliRegistries;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.apache.commons.lang3.mutable.Mutable;

public abstract class ItemAction<T extends IDynamicFeatureConfiguration>
implements IFactory<T, ConfiguredItemAction<T, ?>, ItemAction<T>> {
    public static final Codec<ItemAction<?>> CODEC = ApoliRegistries.codec(() -> ApoliRegistries.ITEM_ACTION.get());
    private final Codec<ConfiguredItemAction<T, ?>> codec;

    protected ItemAction(Codec<T> codec) {
        this.codec = IFactory.singleCodec(IFactory.asMap(codec), iDynamicFeatureConfiguration -> this.configure((IDynamicFeatureConfiguration)iDynamicFeatureConfiguration), ConfiguredFactory::getConfiguration);
    }

    public Codec<ConfiguredItemAction<T, ?>> getCodec() {
        return this.codec;
    }

    @Override
    public final ConfiguredItemAction<T, ?> configure(T input) {
        return new ConfiguredItemAction<T, ItemAction>(() -> this, input);
    }

    public abstract void execute(T var1, Level var2, Mutable<ItemStack> var3);
}

