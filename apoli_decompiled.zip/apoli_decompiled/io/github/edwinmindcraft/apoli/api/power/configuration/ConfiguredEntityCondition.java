/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.MapCodec
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  io.github.edwinmindcraft.calio.api.network.CodecSet
 *  net.minecraft.core.Holder
 *  net.minecraft.world.entity.Entity
 */
package io.github.edwinmindcraft.apoli.api.power.configuration;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.ConditionData;
import io.github.edwinmindcraft.apoli.api.power.ConfiguredCondition;
import io.github.edwinmindcraft.apoli.api.power.ConfiguredFactory;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityCondition;
import io.github.edwinmindcraft.apoli.api.registry.ApoliBuiltinRegistries;
import io.github.edwinmindcraft.apoli.api.registry.ApoliDynamicRegistries;
import io.github.edwinmindcraft.apoli.api.registry.ApoliRegistries;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import io.github.edwinmindcraft.calio.api.network.CodecSet;
import java.util.function.Supplier;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.Entity;

public final class ConfiguredEntityCondition<C extends IDynamicFeatureConfiguration, F extends EntityCondition<C>>
extends ConfiguredCondition<C, F, ConfiguredEntityCondition<?, ?>> {
    public static final Codec<ConfiguredEntityCondition<?, ?>> CODEC = EntityCondition.CODEC.dispatch(ConfiguredFactory::getFactory, EntityCondition::getConditionCodec);
    public static final CodecSet<ConfiguredEntityCondition<?, ?>> CODEC_SET = CalioCodecHelper.forDynamicRegistry(ApoliDynamicRegistries.CONFIGURED_ENTITY_CONDITION_KEY, (Codec)SerializableDataTypes.IDENTIFIER, CODEC);
    public static final Codec<Holder<ConfiguredEntityCondition<?, ?>>> HOLDER = CODEC_SET.holder();

    public static MapCodec<Holder<ConfiguredEntityCondition<?, ?>>> required(String name) {
        return HOLDER.fieldOf(name);
    }

    public static MapCodec<Holder<ConfiguredEntityCondition<?, ?>>> optional(String name) {
        return CalioCodecHelper.registryDefaultedField(HOLDER, (String)name, ApoliDynamicRegistries.CONFIGURED_ENTITY_CONDITION_KEY, ApoliBuiltinRegistries.CONFIGURED_ENTITY_CONDITIONS);
    }

    public static boolean check(Holder<ConfiguredEntityCondition<?, ?>> condition, Entity entity) {
        return !condition.m_203633_() || ((ConfiguredEntityCondition)condition.m_203334_()).check(entity);
    }

    public ConfiguredEntityCondition(Supplier<F> factory, C configuration, ConditionData data) {
        super(factory, configuration, data);
    }

    public boolean check(Entity entity) {
        return ((EntityCondition)this.getFactory()).check(this.getConfiguration(), this.getData(), entity);
    }

    public String toString() {
        return "CEC:" + ApoliRegistries.ENTITY_CONDITION.get().getKey((Object)((EntityCondition)this.getFactory())) + "(" + this.getData() + ")-" + this.getConfiguration();
    }
}

