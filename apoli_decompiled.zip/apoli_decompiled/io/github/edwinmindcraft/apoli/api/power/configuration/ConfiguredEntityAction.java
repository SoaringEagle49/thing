/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.MapCodec
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  io.github.edwinmindcraft.calio.api.network.CodecSet
 *  net.minecraft.core.Holder
 *  net.minecraft.world.entity.Entity
 */
package io.github.edwinmindcraft.apoli.api.power.configuration;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.ConfiguredFactory;
import io.github.edwinmindcraft.apoli.api.power.factory.EntityAction;
import io.github.edwinmindcraft.apoli.api.registry.ApoliBuiltinRegistries;
import io.github.edwinmindcraft.apoli.api.registry.ApoliDynamicRegistries;
import io.github.edwinmindcraft.apoli.api.registry.ApoliRegistries;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import io.github.edwinmindcraft.calio.api.network.CodecSet;
import java.util.function.Supplier;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.Entity;

public final class ConfiguredEntityAction<C extends IDynamicFeatureConfiguration, F extends EntityAction<C>>
extends ConfiguredFactory<C, F, ConfiguredEntityAction<?, ?>> {
    public static final Codec<ConfiguredEntityAction<?, ?>> CODEC = EntityAction.CODEC.dispatch(ConfiguredFactory::getFactory, EntityAction::getCodec);
    public static final CodecSet<ConfiguredEntityAction<?, ?>> CODEC_SET = CalioCodecHelper.forDynamicRegistry(ApoliDynamicRegistries.CONFIGURED_ENTITY_ACTION_KEY, (Codec)SerializableDataTypes.IDENTIFIER, CODEC);
    public static final Codec<Holder<ConfiguredEntityAction<?, ?>>> HOLDER = CODEC_SET.holder();

    public static MapCodec<Holder<ConfiguredEntityAction<?, ?>>> required(String name) {
        return HOLDER.fieldOf(name);
    }

    public static MapCodec<Holder<ConfiguredEntityAction<?, ?>>> optional(String name) {
        return CalioCodecHelper.registryDefaultedField(HOLDER, (String)name, ApoliDynamicRegistries.CONFIGURED_ENTITY_ACTION_KEY, ApoliBuiltinRegistries.CONFIGURED_ENTITY_ACTIONS);
    }

    public static void execute(Holder<ConfiguredEntityAction<?, ?>> action, Entity entity) {
        if (action.m_203633_()) {
            ((ConfiguredEntityAction)action.m_203334_()).execute(entity);
        }
    }

    public ConfiguredEntityAction(Supplier<F> factory, C configuration) {
        super(factory, configuration);
    }

    public void execute(Entity entity) {
        ((EntityAction)this.getFactory()).execute(this.getConfiguration(), entity);
    }

    public String toString() {
        return "CEA:" + ApoliRegistries.ENTITY_ACTION.get().getKey((Object)((EntityAction)this.getFactory())) + "-" + this.getConfiguration();
    }
}

