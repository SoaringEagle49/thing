/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  net.minecraft.world.entity.Entity
 *  net.minecraftforge.common.util.Lazy
 */
package io.github.edwinmindcraft.apoli.api.power.factory;

import com.mojang.serialization.Codec;
import io.github.apace100.apoli.power.factory.action.ActionFactory;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.ConfiguredFactory;
import io.github.edwinmindcraft.apoli.api.power.IFactory;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredEntityAction;
import io.github.edwinmindcraft.apoli.api.registry.ApoliRegistries;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.common.util.Lazy;

public abstract class EntityAction<T extends IDynamicFeatureConfiguration>
implements IFactory<T, ConfiguredEntityAction<T, ?>, EntityAction<T>> {
    public static final Codec<EntityAction<?>> CODEC = ApoliRegistries.codec(() -> ApoliRegistries.ENTITY_ACTION.get());
    private final Codec<ConfiguredEntityAction<T, ?>> codec;
    private final Lazy<ActionFactory<Entity>> legacyType = Lazy.of(() -> new ActionFactory(ApoliRegistries.ENTITY_ACTION.get().getKey((Object)this), CODEC, this));

    protected EntityAction(Codec<T> codec) {
        this.codec = IFactory.singleCodec(IFactory.asMap(codec), iDynamicFeatureConfiguration -> this.configure((IDynamicFeatureConfiguration)iDynamicFeatureConfiguration), ConfiguredFactory::getConfiguration);
    }

    public Codec<ConfiguredEntityAction<T, ?>> getCodec() {
        return this.codec;
    }

    @Override
    public final ConfiguredEntityAction<T, ?> configure(T input) {
        return new ConfiguredEntityAction<T, EntityAction>(() -> this, input);
    }

    public abstract void execute(T var1, Entity var2);
}

