/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.Container
 *  net.minecraft.world.entity.Entity
 *  net.minecraft.world.inventory.MenuConstructor
 *  net.minecraft.world.item.ItemStack
 */
package io.github.edwinmindcraft.apoli.api.power;

import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import net.minecraft.world.Container;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.inventory.MenuConstructor;
import net.minecraft.world.item.ItemStack;

public interface IInventoryPower<T extends IDynamicFeatureConfiguration> {
    public boolean shouldDropOnDeath(ConfiguredPower<T, ?> var1, Entity var2, ItemStack var3);

    public boolean shouldDropOnDeath(ConfiguredPower<T, ?> var1, Entity var2);

    public Container getInventory(ConfiguredPower<T, ?> var1, Entity var2);

    public MenuConstructor getMenuCreator(ConfiguredPower<T, ?> var1, Entity var2);
}

