/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.MapCodec
 *  com.mojang.serialization.MapCodec$MapCodecCodec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 */
package io.github.edwinmindcraft.apoli.api.power;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.ConfiguredFactory;
import java.util.function.BiFunction;
import java.util.function.Function;

public interface IFactory<T extends IDynamicFeatureConfiguration, C extends ConfiguredFactory<T, ? extends F, ?>, F extends IFactory<T, C, F>> {
    public static <T> MapCodec<T> asMap(Codec<T> codec) {
        if (codec instanceof MapCodec.MapCodecCodec) {
            return ((MapCodec.MapCodecCodec)codec).codec();
        }
        return codec.fieldOf("value");
    }

    public static <T, V, R> Codec<R> unionCodec(MapCodec<T> first, MapCodec<V> second, BiFunction<T, V, R> function, Function<R, T> firstGetter, Function<R, V> secondGetter) {
        return RecordCodecBuilder.create(instance -> instance.group((App)first.forGetter(firstGetter), (App)second.forGetter(secondGetter)).apply((Applicative)instance, function));
    }

    public static <T, R> Codec<R> singleCodec(MapCodec<T> first, Function<T, R> to, Function<R, T> from) {
        return first.xmap(to, from).codec();
    }

    public C configure(T var1);
}

