/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.MapCodec
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  io.github.edwinmindcraft.calio.api.network.CodecSet
 *  net.minecraft.core.Holder
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 */
package io.github.edwinmindcraft.apoli.api.power.configuration;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.ConditionData;
import io.github.edwinmindcraft.apoli.api.power.ConfiguredCondition;
import io.github.edwinmindcraft.apoli.api.power.ConfiguredFactory;
import io.github.edwinmindcraft.apoli.api.power.factory.ItemCondition;
import io.github.edwinmindcraft.apoli.api.registry.ApoliBuiltinRegistries;
import io.github.edwinmindcraft.apoli.api.registry.ApoliDynamicRegistries;
import io.github.edwinmindcraft.apoli.api.registry.ApoliRegistries;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import io.github.edwinmindcraft.calio.api.network.CodecSet;
import java.util.function.Supplier;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public final class ConfiguredItemCondition<C extends IDynamicFeatureConfiguration, F extends ItemCondition<C>>
extends ConfiguredCondition<C, F, ConfiguredItemCondition<?, ?>> {
    public static final Codec<ConfiguredItemCondition<?, ?>> CODEC = ItemCondition.CODEC.dispatch(ConfiguredFactory::getFactory, ItemCondition::getConditionCodec);
    public static final CodecSet<ConfiguredItemCondition<?, ?>> CODEC_SET = CalioCodecHelper.forDynamicRegistry(ApoliDynamicRegistries.CONFIGURED_ITEM_CONDITION_KEY, (Codec)SerializableDataTypes.IDENTIFIER, CODEC);
    public static final Codec<Holder<ConfiguredItemCondition<?, ?>>> HOLDER = CODEC_SET.holder();

    public static MapCodec<Holder<ConfiguredItemCondition<?, ?>>> required(String name) {
        return HOLDER.fieldOf(name);
    }

    public static MapCodec<Holder<ConfiguredItemCondition<?, ?>>> optional(String name) {
        return CalioCodecHelper.registryDefaultedField(HOLDER, (String)name, ApoliDynamicRegistries.CONFIGURED_ITEM_CONDITION_KEY, ApoliBuiltinRegistries.CONFIGURED_ITEM_CONDITIONS);
    }

    public static MapCodec<Holder<ConfiguredItemCondition<?, ?>>> optional(String name, ResourceKey<ConfiguredItemCondition<?, ?>> value) {
        return CalioCodecHelper.registryField(HOLDER, (String)name, value, ApoliDynamicRegistries.CONFIGURED_ITEM_CONDITION_KEY, ApoliBuiltinRegistries.CONFIGURED_ITEM_CONDITIONS);
    }

    public static MapCodec<Holder<ConfiguredItemCondition<?, ?>>> optional(String name, ResourceLocation key) {
        return CalioCodecHelper.registryField(HOLDER, (String)name, (ResourceKey)ResourceKey.m_135785_(ApoliDynamicRegistries.CONFIGURED_ITEM_CONDITION_KEY, (ResourceLocation)key), ApoliDynamicRegistries.CONFIGURED_ITEM_CONDITION_KEY, ApoliBuiltinRegistries.CONFIGURED_ITEM_CONDITIONS);
    }

    public static boolean check(Holder<ConfiguredItemCondition<?, ?>> condition, Level level, ItemStack stack) {
        return !condition.m_203633_() || ((ConfiguredItemCondition)condition.m_203334_()).check(level, stack);
    }

    public ConfiguredItemCondition(Supplier<F> factory, C configuration, ConditionData data) {
        super(factory, configuration, data);
    }

    public boolean check(Level level, ItemStack stack) {
        return ((ItemCondition)this.getFactory()).check(this.getConfiguration(), this.getData(), level, stack);
    }

    public String toString() {
        return "CIC:" + ApoliRegistries.ITEM_CONDITION.get().getKey((Object)((ItemCondition)this.getFactory())) + "(" + this.getData() + ")-" + this.getConfiguration();
    }
}

