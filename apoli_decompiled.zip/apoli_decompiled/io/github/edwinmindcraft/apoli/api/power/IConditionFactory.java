/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 */
package io.github.edwinmindcraft.apoli.api.power;

import com.mojang.serialization.Codec;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.ConditionData;
import io.github.edwinmindcraft.apoli.api.power.ConfiguredCondition;
import io.github.edwinmindcraft.apoli.api.power.ConfiguredFactory;
import io.github.edwinmindcraft.apoli.api.power.IFactory;

public interface IConditionFactory<T extends IDynamicFeatureConfiguration, C extends ConfiguredCondition<T, ? extends F, ?>, F extends IConditionFactory<T, C, F>>
extends IFactory<T, C, F> {
    public static <T extends IDynamicFeatureConfiguration, C extends ConfiguredCondition<T, ? extends F, ?>, F extends IConditionFactory<T, C, F>> Codec<C> conditionCodec(Codec<T> codec, F factory) {
        return IFactory.unionCodec(IFactory.asMap(codec), ConditionData.CODEC, factory::configure, ConfiguredFactory::getConfiguration, ConfiguredCondition::getData);
    }

    public Codec<C> getConditionCodec();

    @Override
    default public C configure(T input) {
        return this.configure(input, ConditionData.DEFAULT);
    }

    public C configure(T var1, ConditionData var2);
}

