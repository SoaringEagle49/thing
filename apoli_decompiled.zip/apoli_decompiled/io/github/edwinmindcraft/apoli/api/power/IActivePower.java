/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.datafixers.util.Either
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.world.entity.Entity
 *  org.jetbrains.annotations.Nullable
 */
package io.github.edwinmindcraft.apoli.api.power;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import java.util.Objects;
import java.util.function.Function;
import net.minecraft.world.entity.Entity;
import org.jetbrains.annotations.Nullable;

public interface IActivePower<T extends IDynamicFeatureConfiguration> {
    public void activate(ConfiguredPower<T, ?> var1, Entity var2);

    public Key getKey(ConfiguredPower<T, ?> var1, @Nullable Entity var2);

    public record Key(String key, boolean continuous) {
        public static final Key PRIMARY = new Key("key.origins.primary_active", false);
        public static final Key SECONDARY = new Key("key.origins.secondary_active", false);
        public static final Codec<Key> CODEC = RecordCodecBuilder.create(instance -> instance.group((App)Codec.STRING.fieldOf("key").forGetter(Key::key), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.BOOL, (String)"continuous", (Object)false).forGetter(Key::continuous)).apply((Applicative)instance, Key::new));
        public static final Codec<Key> BACKWARD_COMPATIBLE_CODEC = Codec.either(CODEC, (Codec)Codec.STRING).xmap(x -> (Key)x.map(Function.identity(), string -> switch (string) {
            case "secondary" -> SECONDARY;
            case "primary" -> PRIMARY;
            default -> new Key((String)string, false);
        }), Either::left);

        @Override
        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof Key)) {
                return false;
            }
            Key otherKey = (Key)obj;
            return otherKey.key.equals(this.key) && otherKey.continuous == this.continuous;
        }

        @Override
        public int hashCode() {
            return Objects.hash(this.key, this.continuous);
        }
    }
}

