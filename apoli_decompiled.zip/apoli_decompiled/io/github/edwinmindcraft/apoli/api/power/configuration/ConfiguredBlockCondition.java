/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.MapCodec
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  io.github.edwinmindcraft.calio.api.network.CodecSet
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Holder
 *  net.minecraft.resources.ResourceKey
 *  net.minecraft.resources.ResourceLocation
 *  net.minecraft.world.level.LevelReader
 *  net.minecraft.world.level.block.state.BlockState
 *  net.minecraftforge.common.util.NonNullSupplier
 */
package io.github.edwinmindcraft.apoli.api.power.configuration;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.ConditionData;
import io.github.edwinmindcraft.apoli.api.power.ConfiguredCondition;
import io.github.edwinmindcraft.apoli.api.power.ConfiguredFactory;
import io.github.edwinmindcraft.apoli.api.power.factory.BlockCondition;
import io.github.edwinmindcraft.apoli.api.registry.ApoliBuiltinRegistries;
import io.github.edwinmindcraft.apoli.api.registry.ApoliDynamicRegistries;
import io.github.edwinmindcraft.apoli.api.registry.ApoliRegistries;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import io.github.edwinmindcraft.calio.api.network.CodecSet;
import java.util.Optional;
import java.util.function.Supplier;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.util.NonNullSupplier;

public final class ConfiguredBlockCondition<T extends IDynamicFeatureConfiguration, F extends BlockCondition<T>>
extends ConfiguredCondition<T, F, ConfiguredBlockCondition<?, ?>> {
    public static final Codec<ConfiguredBlockCondition<?, ?>> CODEC = BlockCondition.CODEC.dispatch(ConfiguredFactory::getFactory, BlockCondition::getConditionCodec);
    public static final MapCodec<Optional<ConfiguredBlockCondition<?, ?>>> OPTIONAL_FIELD = CalioCodecHelper.optionalField(CODEC, (String)"block_condition");
    public static final CodecSet<ConfiguredBlockCondition<?, ?>> CODEC_SET = CalioCodecHelper.forDynamicRegistry(ApoliDynamicRegistries.CONFIGURED_BLOCK_CONDITION_KEY, (Codec)SerializableDataTypes.IDENTIFIER, CODEC);
    public static final Codec<Holder<ConfiguredBlockCondition<?, ?>>> HOLDER = CODEC_SET.holder();

    public static MapCodec<Holder<ConfiguredBlockCondition<?, ?>>> required(String name) {
        return HOLDER.fieldOf(name);
    }

    public static MapCodec<Holder<ConfiguredBlockCondition<?, ?>>> optional(String name) {
        return CalioCodecHelper.registryDefaultedField(HOLDER, (String)name, ApoliDynamicRegistries.CONFIGURED_BLOCK_CONDITION_KEY, ApoliBuiltinRegistries.CONFIGURED_BLOCK_CONDITIONS);
    }

    public static MapCodec<Holder<ConfiguredBlockCondition<?, ?>>> optional(String name, ResourceKey<ConfiguredBlockCondition<?, ?>> key) {
        return CalioCodecHelper.registryField(HOLDER, (String)name, key, ApoliDynamicRegistries.CONFIGURED_BLOCK_CONDITION_KEY, ApoliBuiltinRegistries.CONFIGURED_BLOCK_CONDITIONS);
    }

    public static MapCodec<Holder<ConfiguredBlockCondition<?, ?>>> optional(String name, ResourceLocation key) {
        return CalioCodecHelper.registryField(HOLDER, (String)name, (ResourceKey)ResourceKey.m_135785_(ApoliDynamicRegistries.CONFIGURED_BLOCK_CONDITION_KEY, (ResourceLocation)key), ApoliDynamicRegistries.CONFIGURED_BLOCK_CONDITION_KEY, ApoliBuiltinRegistries.CONFIGURED_BLOCK_CONDITIONS);
    }

    public static boolean check(Holder<ConfiguredBlockCondition<?, ?>> condition, LevelReader reader, BlockPos position, NonNullSupplier<BlockState> state) {
        return !condition.m_203633_() || ((ConfiguredBlockCondition)condition.m_203334_()).check(reader, position, state);
    }

    public static boolean check(Holder<ConfiguredBlockCondition<?, ?>> condition, LevelReader reader, BlockPos position) {
        return ConfiguredBlockCondition.check(condition, reader, position, (NonNullSupplier<BlockState>)((NonNullSupplier)() -> reader.m_8055_(position)));
    }

    public ConfiguredBlockCondition(Supplier<F> factory, T configuration, ConditionData data) {
        super(factory, configuration, data);
    }

    public boolean check(LevelReader reader, BlockPos position, NonNullSupplier<BlockState> state) {
        return ((BlockCondition)this.getFactory()).check(this, reader, position, state);
    }

    public String toString() {
        return "CBC:" + ApoliRegistries.BLOCK_CONDITION.get().getKey((Object)((BlockCondition)this.getFactory())) + "(" + this.getData() + ")-" + this.getConfiguration();
    }
}

