/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  net.minecraft.core.BlockPos
 *  net.minecraft.core.Direction
 *  net.minecraft.world.level.Level
 */
package io.github.edwinmindcraft.apoli.api.power.factory;

import com.mojang.serialization.Codec;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.ConfiguredFactory;
import io.github.edwinmindcraft.apoli.api.power.IFactory;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredBlockAction;
import io.github.edwinmindcraft.apoli.api.registry.ApoliRegistries;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;

public abstract class BlockAction<T extends IDynamicFeatureConfiguration>
implements IFactory<T, ConfiguredBlockAction<T, ?>, BlockAction<T>> {
    public static final Codec<BlockAction<?>> CODEC = ApoliRegistries.codec(() -> ApoliRegistries.BLOCK_ACTION.get());
    private final Codec<ConfiguredBlockAction<T, ?>> codec;

    protected BlockAction(Codec<T> codec) {
        this.codec = IFactory.singleCodec(IFactory.asMap(codec), iDynamicFeatureConfiguration -> this.configure((IDynamicFeatureConfiguration)iDynamicFeatureConfiguration), ConfiguredFactory::getConfiguration);
    }

    public Codec<ConfiguredBlockAction<T, ?>> getCodec() {
        return this.codec;
    }

    @Override
    public final ConfiguredBlockAction<T, ?> configure(T input) {
        return new ConfiguredBlockAction<T, BlockAction>(() -> this, input);
    }

    public abstract void execute(T var1, Level var2, BlockPos var3, Direction var4);
}

