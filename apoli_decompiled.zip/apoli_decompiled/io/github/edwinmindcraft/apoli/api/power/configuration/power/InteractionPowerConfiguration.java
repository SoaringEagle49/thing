/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.MapCodec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.apace100.calio.data.SerializableDataTypes
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 *  net.minecraft.core.Holder
 *  net.minecraft.world.InteractionHand
 *  net.minecraft.world.InteractionResult
 *  net.minecraft.world.entity.LivingEntity
 *  net.minecraft.world.entity.player.Player
 *  net.minecraft.world.item.ItemStack
 *  net.minecraft.world.level.Level
 *  org.apache.commons.lang3.mutable.Mutable
 *  org.apache.commons.lang3.mutable.MutableObject
 *  org.jetbrains.annotations.Nullable
 */
package io.github.edwinmindcraft.apoli.api.power.configuration.power;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.apace100.calio.data.SerializableDataTypes;
import io.github.edwinmindcraft.apoli.api.VariableAccess;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredItemAction;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredItemCondition;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;
import java.util.EnumSet;
import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.apache.commons.lang3.mutable.Mutable;
import org.apache.commons.lang3.mutable.MutableObject;
import org.jetbrains.annotations.Nullable;

public record InteractionPowerConfiguration(EnumSet<InteractionHand> hands, InteractionResult actionResult, Holder<ConfiguredItemCondition<?, ?>> itemCondition, Holder<ConfiguredItemAction<?, ?>> heldItemAction, @Nullable ItemStack itemResult, Holder<ConfiguredItemAction<?, ?>> resultItemAction) {
    public static final MapCodec<InteractionPowerConfiguration> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group((App)CalioCodecHelper.optionalField((Codec)SerializableDataTypes.HAND_SET, (String)"hands", () -> EnumSet.allOf(InteractionHand.class)).forGetter(InteractionPowerConfiguration::hands), (App)CalioCodecHelper.optionalField((Codec)SerializableDataTypes.ACTION_RESULT, (String)"action_result", (Object)InteractionResult.SUCCESS).forGetter(InteractionPowerConfiguration::actionResult), (App)ConfiguredItemCondition.optional("item_condition").forGetter(InteractionPowerConfiguration::itemCondition), (App)ConfiguredItemAction.optional("held_item_action").forGetter(InteractionPowerConfiguration::heldItemAction), (App)CalioCodecHelper.optionalField((Codec)SerializableDataTypes.ITEM_STACK, (String)"result_stack").forGetter(x -> Optional.ofNullable(x.itemResult())), (App)ConfiguredItemAction.optional("result_item_action").forGetter(InteractionPowerConfiguration::resultItemAction)).apply((Applicative)instance, (t1, t2, t3, t4, t5, t6) -> new InteractionPowerConfiguration((EnumSet<InteractionHand>)t1, (InteractionResult)t2, (Holder<ConfiguredItemCondition<?, ?>>)t3, (Holder<ConfiguredItemAction<?, ?>>)t4, t5.orElse(null), (Holder<ConfiguredItemAction<?, ?>>)t6)));
    public static final MapCodec<InteractionPowerConfiguration> PREVENTING_MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group((App)CalioCodecHelper.optionalField((Codec)SerializableDataTypes.HAND_SET, (String)"hands", () -> EnumSet.allOf(InteractionHand.class)).forGetter(InteractionPowerConfiguration::hands), (App)ConfiguredItemCondition.optional("item_condition").forGetter(InteractionPowerConfiguration::itemCondition), (App)ConfiguredItemAction.optional("held_item_action").forGetter(InteractionPowerConfiguration::heldItemAction), (App)CalioCodecHelper.optionalField((Codec)SerializableDataTypes.ITEM_STACK, (String)"result_stack").forGetter(x -> Optional.ofNullable(x.itemResult())), (App)ConfiguredItemAction.optional("result_item_action").forGetter(InteractionPowerConfiguration::resultItemAction)).apply((Applicative)instance, (t1, t3, t4, t5, t6) -> new InteractionPowerConfiguration((EnumSet<InteractionHand>)t1, InteractionResult.FAIL, (Holder<ConfiguredItemCondition<?, ?>>)t3, (Holder<ConfiguredItemAction<?, ?>>)t4, t5.orElse(null), (Holder<ConfiguredItemAction<?, ?>>)t6)));

    public static InteractionResult reduce(InteractionResult first, InteractionResult second) {
        return second.m_19077_() && !first.m_19077_() || second.m_19080_() && !first.m_19080_() ? second : first;
    }

    public boolean appliesTo(Level level, InteractionHand hand, ItemStack stack) {
        return this.appliesTo(hand) && this.appliesTo(level, stack);
    }

    public boolean appliesTo(InteractionHand hand) {
        return this.hands().contains(hand);
    }

    public boolean appliesTo(Level level, ItemStack stack) {
        return ConfiguredItemCondition.check(this.itemCondition(), level, stack);
    }

    public void performActorItemStuff(LivingEntity actor, InteractionHand hand) {
        boolean modified;
        MutableObject heldStack = VariableAccess.hand(actor, hand);
        ConfiguredItemAction.execute(this.heldItemAction(), actor.m_9236_(), heldStack);
        MutableObject resultingStack = this.itemResult() == null ? heldStack : new MutableObject((Object)this.itemResult().m_41777_());
        boolean bl = modified = this.itemResult() != null;
        if (this.resultItemAction().m_203633_()) {
            ConfiguredItemAction.execute(this.resultItemAction(), actor.m_9236_(), (Mutable<ItemStack>)resultingStack);
        }
        if (modified) {
            if (((ItemStack)resultingStack.getValue()).m_41619_()) {
                actor.m_21008_(hand, (ItemStack)resultingStack.getValue());
            } else if (actor instanceof Player) {
                Player player = (Player)actor;
                player.m_150109_().m_150079_((ItemStack)resultingStack.getValue());
            }
        }
    }
}

