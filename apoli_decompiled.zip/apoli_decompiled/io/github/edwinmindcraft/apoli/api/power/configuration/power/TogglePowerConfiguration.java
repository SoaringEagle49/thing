/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.MapCodec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  io.github.edwinmindcraft.calio.api.network.CalioCodecHelper
 */
package io.github.edwinmindcraft.apoli.api.power.configuration.power;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.IActivePower;
import io.github.edwinmindcraft.calio.api.network.CalioCodecHelper;

public interface TogglePowerConfiguration
extends IDynamicFeatureConfiguration {
    public static final MapCodec<TogglePowerConfiguration> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group((App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.BOOL, (String)"active_by_default", (Object)true).forGetter(TogglePowerConfiguration::defaultState), (App)CalioCodecHelper.optionalField(IActivePower.Key.BACKWARD_COMPATIBLE_CODEC, (String)"key", (Object)IActivePower.Key.PRIMARY).forGetter(TogglePowerConfiguration::key), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.BOOL, (String)"retain_state", (Object)true).forGetter(TogglePowerConfiguration::retainState)).apply((Applicative)instance, Impl::new));
    public static final MapCodec<TogglePowerConfiguration> INACTIVE_MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group((App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.BOOL, (String)"active_by_default", (Object)false).forGetter(TogglePowerConfiguration::defaultState), (App)CalioCodecHelper.optionalField(IActivePower.Key.BACKWARD_COMPATIBLE_CODEC, (String)"key", (Object)IActivePower.Key.PRIMARY).forGetter(TogglePowerConfiguration::key), (App)CalioCodecHelper.optionalField((Codec)CalioCodecHelper.BOOL, (String)"retain_state", (Object)true).forGetter(TogglePowerConfiguration::retainState)).apply((Applicative)instance, Impl::new));
    public static final Codec<TogglePowerConfiguration> CODEC = MAP_CODEC.codec();
    public static final Codec<TogglePowerConfiguration> INACTIVE_CODEC = INACTIVE_MAP_CODEC.codec();

    public boolean defaultState();

    public IActivePower.Key key();

    public boolean retainState();

    public static interface Wrapper
    extends TogglePowerConfiguration {
        public TogglePowerConfiguration wrapped();

        @Override
        default public boolean defaultState() {
            return this.wrapped().defaultState();
        }

        @Override
        default public IActivePower.Key key() {
            return this.wrapped().key();
        }

        @Override
        default public boolean retainState() {
            return this.wrapped().retainState();
        }
    }

    public record Impl(boolean defaultState, IActivePower.Key key, boolean retainState) implements TogglePowerConfiguration
    {
    }
}

