/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.world.entity.Entity
 */
package io.github.edwinmindcraft.apoli.api.power;

import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;
import io.github.edwinmindcraft.apoli.api.power.IVariableIntPower;
import io.github.edwinmindcraft.apoli.api.power.configuration.ConfiguredPower;
import net.minecraft.world.entity.Entity;

public interface ICooldownPower<T extends IDynamicFeatureConfiguration>
extends IVariableIntPower<T> {
    public void use(ConfiguredPower<T, ?> var1, Entity var2);

    public boolean canUse(ConfiguredPower<T, ?> var1, Entity var2);
}

