/*
 * Decompiled with CFR 0.152.
 */
package io.github.edwinmindcraft.apoli.api.power.configuration.power;

import io.github.edwinmindcraft.apoli.api.IDynamicFeatureConfiguration;

public interface IVariableIntPowerConfiguration
extends IDynamicFeatureConfiguration {
    public int min();

    public int max();

    public int initialValue();
}

