/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.client.event.RegisterGuiOverlaysEvent
 *  net.minecraftforge.client.gui.overlay.IGuiOverlay
 *  net.minecraftforge.client.gui.overlay.VanillaGuiOverlay
 */
package io.github.edwinmindcraft.apoli.client.screen;

import io.github.edwinmindcraft.apoli.client.screen.ApoliOverlay;
import io.github.edwinmindcraft.apoli.client.screen.ApoliPowerOverlay;
import io.github.edwinmindcraft.apoli.common.power.configuration.OverlayConfiguration;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;

public class ApoliOverlays {
    public static void bootstrap() {
    }

    public static void registerOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "overlay", (IGuiOverlay)ApoliOverlay.INSTANCE);
        event.registerBelowAll("bottom_overlay", (IGuiOverlay)new ApoliPowerOverlay(configuration -> configuration.phase() == OverlayConfiguration.DrawPhase.BELOW_HUD));
        event.registerAboveAll("above_overlay", (IGuiOverlay)new ApoliPowerOverlay(configuration -> configuration.phase() == OverlayConfiguration.DrawPhase.ABOVE_HUD));
    }
}

