/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.GuiGraphics
 *  net.minecraftforge.client.gui.overlay.ForgeGui
 *  net.minecraftforge.client.gui.overlay.IGuiOverlay
 */
package io.github.edwinmindcraft.apoli.client.screen;

import io.github.apace100.apoli.screen.GameHudRender;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

public enum ApoliOverlay implements IGuiOverlay
{
    INSTANCE;


    public void render(ForgeGui gui, GuiGraphics graphics, float partialTicks, int width, int height) {
        if (!Minecraft.m_91087_().f_91066_.f_92062_) {
            for (GameHudRender hudRender : GameHudRender.HUD_RENDERS) {
                hudRender.render(graphics, partialTicks);
            }
        }
    }
}

